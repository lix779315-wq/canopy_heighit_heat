
# -*- coding: utf-8 -*-


from pathlib import Path

import numpy as np
import pandas as pd
from scipy.linalg import qr
from scipy.stats import chi2, t



INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_structure_ses.csv"
)
OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\ses_fixed_effects_submission"
)

OUTCOMES = ("Cover", "Hmean", "HSD", "HP90")
WEIGHTINGS = ("grid_equal", "city_equal")
N_BOOTSTRAP = 2000
RANDOM_SEED = 20261023
COVER_KNOTS = (0.25, 0.50, 0.75)

CONTRAST = np.array([
    [-1.0, 1.0, 0.0, 0.0],
    [-1.0, 0.0, 1.0, 0.0],
    [-1.0, 0.0, 0.0, 1.0],
])


def prepare_data():
    df = pd.read_csv(
        INPUT_CSV,
        dtype={"grid_id": str, "city_id": str}
    )

    required = [
        "grid_id", "city_id", "grdi", "population",
        "built_density", "built_height",
        "distance_to_center_km", "climate", *OUTCOMES
    ]

    missing = set(required) - set(df.columns)
    if missing:
        raise ValueError(f"缺少字段：{sorted(missing)}")

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError("grid_id或city_id缺失、重复")

    for name in required[2:]:
        df[name] = pd.to_numeric(
            df[name], errors="coerce"
        )

    if not np.isfinite(
        df[required[2:]].to_numpy(dtype=float)
    ).all():
        raise ValueError("输入样本有缺失值或非有限值")

    if not (
        df.grdi.between(0, 100).all()
        and df.population.ge(0).all()
        and df.built_density.between(0, 1).all()
        and df.built_height.ge(0).all()
        and df.distance_to_center_km.ge(0).all()
        and df.Cover.between(0, 100).all()
        and df.Hmean.gt(2).all()
        and df.HSD.ge(0).all()
        and df.HP90.gt(2).all()
    ):
        raise ValueError("存在超出合理取值范围的记录")

    df = df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)

    df["affluence"] = 100 - df["grdi"]

    df["log_population"] = np.log1p(
        df["population"]
    )
    df["log_building_height"] = np.log1p(
        df["built_height"]
    )

    names = {
        "affluence": "ses_z",
        "log_population": "population_z",
        "built_density": "density_z",
        "log_building_height": "building_z",
        "distance_to_center_km": "distance_z",
        **{v: f"{v}_z" for v in OUTCOMES},
    }

    for source, target in names.items():
        grouped = df.groupby("city_id")[source]
        mean = grouped.transform("mean")
        sd = grouped.transform(
            lambda x: x.std(ddof=0)
        )

        df[target] = (
            (df[source] - mean)
            / sd.where(sd > 0)
        ).fillna(0.0)

    df["ses_quintile"] = pd.Series(
        pd.NA,
        index=df.index,
        dtype="Int64"
    )

    for _, city in df.groupby("city_id"):
        if (
            len(city) < 5
            or city.affluence.nunique() < 5
        ):
            continue

        groups = pd.qcut(
            city.affluence,
            5,
            labels=False,
            duplicates="drop"
        )

        if groups.nunique() == 5:
            df.loc[
                city.index, "ses_quintile"
            ] = (groups + 1).astype("Int64")

    climate = df.climate.astype(int)
    reference = climate.value_counts().idxmax()

    dummy = pd.get_dummies(
        climate,
        prefix="climate",
        dtype=float
    )

    dummy = dummy.drop(
        columns=f"climate_{reference}"
    )

    df = pd.concat([df, dummy], axis=1)

    knots = np.quantile(
        df.Cover_z, COVER_KNOTS
    )

    hinges = []

    for label, knot in zip(
        ("25", "50", "75"), knots
    ):
        col = f"cover_hinge_{label}"

        df[col] = np.maximum(
            df.Cover_z - knot, 0
        )

        hinges.append(col)

    controls = [
        "population_z",
        "density_z",
        "building_z",
        "distance_z",
        *dummy.columns
    ]

    cover_terms = [
        "Cover_z", *hinges
    ]

    return df, controls, cover_terms



def fit_fe(df, terms, outcomes, weighting):
    codes, cities = pd.factorize(
        df.city_id, sort=True
    )

    g, n = len(cities), len(df)

    if g < 3:
        raise ValueError("城市聚类数量不足")

    counts = np.bincount(
        codes, minlength=g
    )

    x = df[terms].to_numpy(dtype=float)
    y = df[outcomes].to_numpy(dtype=float)

    x -= pd.DataFrame(x).groupby(
        codes
    ).transform("mean").to_numpy()

    y -= pd.DataFrame(y).groupby(
        codes
    ).transform("mean").to_numpy()

    weight = (
        np.ones(n)
        if weighting == "grid_equal"
        else 1.0 / counts[codes]
    )

    _, r, pivots = qr(
        x * np.sqrt(weight[:, None]),
        mode="economic",
        pivoting=True
    )

    diagonal = np.abs(np.diag(r))

    tol = (
        max(x.shape)
        * np.finfo(float).eps
        * diagonal.max(initial=0)
    )

    rank = int(
        np.count_nonzero(diagonal > tol)
    )

    if rank == 0:
        raise ValueError("模型没有可识别的解释变量")

    selected = np.sort(pivots[:rank])
    kept = [terms[i] for i in selected]

    x = x[:, selected]
    p, k = x.shape[1], y.shape[1]

    a = np.empty((g, p, p))
    b = np.empty((g, p, k))

    for i in range(g):
        mask = codes == i

        xi = x[mask]
        yi = y[mask]
        wi = weight[mask]

        a[i] = xi.T @ (
            xi * wi[:, None]
        )

        b[i] = xi.T @ (
            yi * wi[:, None]
        )

    a_all = a.sum(axis=0)

    beta = np.linalg.solve(
        a_all,
        b.sum(axis=0)
    )

    bread = np.linalg.inv(a_all)

    scores = b - np.einsum(
        "gij,jk->gik", a, beta
    )

    influence = np.einsum(
        "ij,gjk->gik",
        bread,
        scores
    )

    if n - g - p <= 0:
        raise ValueError("模型残差自由度不足")

    correction = (
        g / (g - 1)
        * (n - 1) / (n - g - p)
    )

    se = np.sqrt(
        correction
        * np.sum(influence ** 2, axis=0)
    )

    return dict(
        beta=beta,
        se=se,
        a=a,
        b=b,
        kept=kept,
        influence=influence,
        correction=correction,
        counts=counts,
        n=n,
        g=g,
        p=p,
        outcomes=outcomes
    )


def add_coefficients(
    rows, fit, model, weighting, terms
):
    critical = t.ppf(
        0.975, fit["g"] - 1
    )

    for term in terms:
        if term not in fit["kept"]:
            raise ValueError(
                f"无法识别关注变量：{term}"
            )

        i = fit["kept"].index(term)

        for j, outcome in enumerate(
            fit["outcomes"]
        ):
            coef = fit["beta"][i, j]
            se = fit["se"][i, j]

            pval = (
                2 * t.sf(
                    abs(coef / se),
                    fit["g"] - 1
                )
                if se > 0 else np.nan
            )

            rows.append({
                "model": model,
                "weighting": weighting,
                "outcome": outcome.removesuffix("_z"),
                "term": term,
                "estimate": coef,
                "se": se,
                "ci95_low": coef - critical * se,
                "ci95_high": coef + critical * se,
                "p_value": pval,
                "n_grids": fit["n"],
                "n_cities": fit["g"]
            })



def gradient_contrasts(fit, weighting, rng):
    i = fit["kept"].index("ses_z")

    theta = (
        CONTRAST @ fit["beta"][i, :]
    )

    influence = (
        fit["influence"][:, i, :]
        @ CONTRAST.T
    )

    cov = (
        fit["correction"]
        * (influence.T @ influence)
    )

    se = np.sqrt(np.diag(cov))

    if (
        np.any(se <= 0)
        or np.linalg.matrix_rank(cov) < 3
    ):
        raise ValueError(
            "SES梯度对比协方差矩阵无法识别"
        )

    wald = float(
        theta @ np.linalg.solve(
            cov, theta
        )
    )

    wald_p = float(
        chi2.sf(wald, 3)
    )

    a = fit["a"]
    b = np.einsum(
        "gpk,dk->gpd",
        fit["b"],
        CONTRAST
    )

    g, p = fit["g"], fit["p"]

    estimates = []
    errors = []
    attempts = 0

    while (
        len(estimates) < N_BOOTSTRAP
        and attempts < N_BOOTSTRAP * 3
    ):
        attempts += 1

        sampled = np.bincount(
            rng.integers(g, size=g),
            minlength=g
        )

        aa = np.einsum(
            "g,gij->ij",
            sampled, a
        )

        if np.linalg.matrix_rank(aa) < p:
            continue

        n_boot = int(
            sampled @ fit["counts"]
        )

        if n_boot <= g + p:
            continue

        bb = np.einsum(
            "g,gpd->pd",
            sampled, b
        )

        beta = np.linalg.solve(
            aa, bb
        )

        scores = b - np.einsum(
            "gij,jd->gid",
            a, beta
        )

        ses_influence = np.einsum(
            "p,gpd->gd",
            np.linalg.inv(aa)[i],
            scores
        )

        correction = (
            g / (g - 1)
            * (n_boot - 1)
            / (n_boot - g - p)
        )

        variances = correction * np.einsum(
            "g,gd,gd->d",
            sampled,
            ses_influence,
            ses_influence
        )

        boot_se = np.sqrt(
            np.maximum(variances, 0)
        )

        if (
            np.all(np.isfinite(beta[i]))
            and np.all(boot_se > 0)
        ):
            estimates.append(beta[i])
            errors.append(boot_se)

    if len(estimates) != N_BOOTSTRAP:
        raise RuntimeError(
            "城市Bootstrap有效重复次数不足"
        )

    draws = np.asarray(estimates)
    boot_se = np.asarray(errors)

    max_t = np.max(
        np.abs(
            (draws - theta) / boot_se
        ),
        axis=1
    )

    critical = np.quantile(
        max_t, 0.95
    )

    names = (
        "Hmean_minus_Cover",
        "HSD_minus_Cover",
        "HP90_minus_Cover"
    )

    rows = []

    for j, name in enumerate(names):
        rows.append({
            "weighting": weighting,
            "contrast": name,
            "estimate": theta[j],
            "se": se[j],
            "ci95_low": (
                theta[j] - critical * se[j]
            ),
            "ci95_high": (
                theta[j] + critical * se[j]
            ),
            "p_max_t": (
                1 + np.sum(
                    max_t >= abs(theta[j] / se[j])
                )
            ) / (N_BOOTSTRAP + 1),
            "joint_wald_chi2": wald,
            "joint_wald_df": 3,
            "joint_wald_p": wald_p,
            "n_grids": fit["n"],
            "n_cities": g
        })

    return rows



def main():
    df, controls, cover_terms = prepare_data()

    qdata = df.dropna(
        subset=["ses_quintile"]
    ).copy()

    if qdata.empty:
        raise ValueError(
            "没有城市可划分为5个SES组"
        )

    quintile_terms = []

    for q in range(2, 6):
        col = f"SES_Q{q}_vs_Q1"

        qdata[col] = (
            qdata.ses_quintile == q
        ).astype(float)

        quintile_terms.append(col)

    model_rows = []
    contrast_rows = []

    seeds = np.random.SeedSequence(
        RANDOM_SEED
    ).spawn(len(WEIGHTINGS))

    for k, weighting in enumerate(WEIGHTINGS):

        for outcome in OUTCOMES:
            terms = [
                "ses_z", *controls
            ]

            if outcome != "Cover":
                terms += cover_terms

            fit = fit_fe(
                df,
                terms,
                [f"{outcome}_z"],
                weighting
            )

            add_coefficients(
                model_rows,
                fit,
                "outcome_specific_continuous",
                weighting,
                ["ses_z"]
            )

            terms_q = [
                *quintile_terms,
                *controls
            ]

            if outcome != "Cover":
                terms_q += cover_terms

            fit_q = fit_fe(
                qdata,
                terms_q,
                [f"{outcome}_z"],
                weighting
            )

            add_coefficients(
                model_rows,
                fit_q,
                "outcome_specific_quintile",
                weighting,
                quintile_terms
            )

        common = fit_fe(
            df,
            ["ses_z", *controls],
            [f"{v}_z" for v in OUTCOMES],
            weighting
        )

        add_coefficients(
            model_rows,
            common,
            "common_specification",
            weighting,
            ["ses_z"]
        )

        contrast_rows.extend(
            gradient_contrasts(
                common,
                weighting,
                np.random.default_rng(seeds[k])
            )
        )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    pd.DataFrame(model_rows).to_csv(
        OUTPUT_DIR / "ses_model_results.csv",
        index=False,
        encoding="utf-8-sig"
    )

    pd.DataFrame(contrast_rows).to_csv(
        OUTPUT_DIR / "ses_gradient_contrasts.csv",
        index=False,
        encoding="utf-8-sig"
    )


if __name__ == "__main__":
    main()
