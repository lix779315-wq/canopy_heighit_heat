
# -*- coding: utf-8 -*-


from pathlib import Path

import numpy as np
import pandas as pd
from scipy.linalg import qr
from scipy.optimize import minimize_scalar
from scipy.stats import chi2, norm, t



INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_structure_ses.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\cover_adjusted_height_index"
)

HEIGHT_METRICS = ("Hmean", "HSD", "HP90")
WEIGHTINGS = ("grid_equal", "city_equal")
COVER_STRATA = ("All", "0-10%", "10-20%", "20-30%", ">30%")

N_BOOTSTRAP = 2000
RANDOM_SEED = 42


def prepare_data():
    df = pd.read_csv(
        INPUT_CSV,
        dtype={"grid_id": str, "city_id": str}
    )

    required = [
        "grid_id", "city_id", "Cover", *HEIGHT_METRICS,
        "ses_affluence", "ses_quintile", "population",
        "built_density", "built_height",
        "distance_to_center_km", "climate"
    ]

    missing = set(required) - set(df)
    if missing:
        raise ValueError(f"缺少字段：{sorted(missing)}")

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df["grid_id"].duplicated().any()
    ):
        raise ValueError("grid_id或city_id缺失、重复")

    numeric = [
        x for x in required
        if x not in ("grid_id", "city_id")
    ]

    df[numeric] = df[numeric].apply(
        pd.to_numeric, errors="coerce"
    )

    checked = [
        x for x in numeric if x != "ses_quintile"
    ]

    if not np.isfinite(
        df[checked].to_numpy(float)
    ).all():
        raise ValueError("输入样本包含缺失或非有限值")

    if not (
        df["Cover"].between(0, 100).all()
        and df["Hmean"].gt(2).all()
        and df["HSD"].ge(0).all()
        and df["HP90"].gt(2).all()
        and df["population"].ge(0).all()
        and df["built_density"].between(0, 1).all()
        and df["built_height"].ge(0).all()
        and df["distance_to_center_km"].ge(0).all()
    ):
        raise ValueError("部分变量超出有效范围")

    if not df["ses_quintile"].dropna().isin(
        [1, 2, 3, 4, 5]
    ).all():
        raise ValueError("SES五分位应为1–5或缺失")

    df = df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)

    df["ses_quintile"] = df["ses_quintile"].astype("Int64")
    df["log_population"] = np.log1p(df["population"])
    df["log_building_height"] = np.log1p(df["built_height"])

    columns = {
        "Cover": "Cover_z",
        "Hmean": "Hmean_z",
        "HSD": "HSD_z",
        "HP90": "HP90_z",
        "ses_affluence": "ses_z",
        "log_population": "population_z",
        "built_density": "density_z",
        "log_building_height": "building_z",
        "distance_to_center_km": "distance_z"
    }

    for source, target in columns.items():
        group = df.groupby("city_id")[source]
        mean = group.transform("mean")
        sd = group.transform(
            lambda x: x.std(ddof=0)
        )

        df[target] = (
            (df[source] - mean) / sd.where(sd > 0)
        ).fillna(0.0)

    df["RawHeightIndex"] = df[
        [f"{x}_z" for x in HEIGHT_METRICS]
    ].mean(axis=1)


    knots = np.quantile(
        df["Cover_z"], [0.25, 0.50, 0.75]
    )

    cover_terms = ["Cover_z"]

    for name, knot in zip(("25", "50", "75"), knots):
        column = f"cover_hinge_{name}"
        df[column] = np.maximum(
            df["Cover_z"] - knot, 0.0
        )
        cover_terms.append(column)

    climate = df["climate"].astype(int)
    reference = climate.value_counts().idxmax()

    dummies = pd.get_dummies(
        climate, prefix="climate", dtype=float
    ).drop(columns=f"climate_{reference}")

    df = pd.concat([df, dummies], axis=1)

    df["Cover_stratum"] = pd.cut(
        df["Cover"],
        [0, 10, 20, 30, 100],
        labels=COVER_STRATA[1:],
        right=True,
        include_lowest=True
    )

    terms = cover_terms + [
        "population_z",
        "density_z",
        "building_z",
        "distance_z",
        *dummies.columns
    ]

    return df, terms



def fit_index(df, terms):
    codes, cities = pd.factorize(
        df["city_id"], sort=True
    )

    counts = np.bincount(codes)
    n_cities = len(cities)

    x = df[terms].to_numpy(float)

    y = df[
        [f"{v}_z" for v in HEIGHT_METRICS]
    ].to_numpy(float)

    for city in range(n_cities):
        mask = codes == city
        x[mask] -= x[mask].mean(axis=0)
        y[mask] -= y[mask].mean(axis=0)

    # 排除共线性变量
    _, r, pivots = qr(
        x, mode="economic", pivoting=True
    )

    diag = np.abs(np.diag(r))
    tol = (
        max(x.shape)
        * np.finfo(float).eps
        * diag.max(initial=0)
    )

    chosen = np.sort(
        pivots[:int(np.sum(diag > tol))]
    )

    if not len(chosen):
        raise ValueError("调整模型没有可识别的解释变量")

    x = x[:, chosen]

    beta = np.linalg.lstsq(
        x, y, rcond=None
    )[0]

    residuals = y - x @ beta

    for j, metric in enumerate(HEIGHT_METRICS):
        df[f"{metric}_residual_z"] = residuals[:, j]

    df["CoverAdjustedHeightIndex"] = (
        residuals.mean(axis=1)
    )

    a = np.empty((
        n_cities, x.shape[1], x.shape[1]
    ))
    b = np.empty((n_cities, x.shape[1]))

    raw = df["RawHeightIndex"].to_numpy(float)

    for city in range(n_cities):
        mask = codes == city
        xx = x[mask]

        a[city] = xx.T @ xx
        b[city] = xx.T @ raw[mask]

    return (
        df, codes, cities, counts,
        x, a, b, beta.mean(axis=1)
    )



def q5q1(df, codes, cities, city_counts,
         x, a, b, beta):

    n_cities, n_terms = a.shape[:2]

    denominators = np.zeros((2, 5, 2, n_cities))
    raw_sums = np.zeros_like(denominators)

    x_sums = np.zeros((
        *denominators.shape, n_terms
    ))

    group_sizes = np.zeros_like(
        denominators, dtype=int
    )

    raw = df["RawHeightIndex"].to_numpy(float)

    q = df["ses_quintile"].to_numpy(
        dtype=float, na_value=np.nan
    )

    strata = df["Cover_stratum"].astype(
        "string"
    ).to_numpy()

    for w, weighting in enumerate(WEIGHTINGS):
        weights = (
            np.ones(len(df))
            if weighting == "grid_equal"
            else 1 / city_counts[codes]
        )

        for s, stratum in enumerate(COVER_STRATA):
            mask = (
                np.ones(len(df), dtype=bool)
                if stratum == "All"
                else strata == stratum
            )

            for qi, value in enumerate((1, 5)):
                selected = mask & (q == value)
                ids = codes[selected]

                np.add.at(
                    denominators[w, s, qi],
                    ids, weights[selected]
                )

                np.add.at(
                    raw_sums[w, s, qi],
                    ids,
                    weights[selected] * raw[selected]
                )

                np.add.at(
                    x_sums[w, s, qi],
                    ids,
                    x[selected] * weights[selected, None]
                )

                np.add.at(
                    group_sizes[w, s, qi],
                    ids, 1
                )

    def contrasts(multiplicity, fit_beta):
        denominator = np.einsum(
            "g,wsqg->wsq",
            multiplicity, denominators
        )

        means_raw = np.einsum(
            "g,wsqg->wsq",
            multiplicity, raw_sums
        )

        means_x = np.einsum(
            "g,wsqgp->wsqp",
            multiplicity, x_sums
        )

        with np.errstate(
            divide="ignore", invalid="ignore"
        ):
            r = means_raw / denominator

            adjusted = (
                means_raw
                - np.einsum(
                    "wsqp,p->wsq",
                    means_x, fit_beta
                )
            ) / denominator

        return np.stack((
            r[:, :, 1] - r[:, :, 0],
            adjusted[:, :, 1] - adjusted[:, :, 0]
        ), axis=-1)

    observed = contrasts(
        np.ones(n_cities), beta
    )

    draws = np.full(
        (N_BOOTSTRAP, 2, 5, 2),
        np.nan
    )

    rng = np.random.default_rng(RANDOM_SEED)

    for iteration in range(N_BOOTSTRAP):
        multiplicity = rng.multinomial(
            n_cities,
            np.full(n_cities, 1 / n_cities)
        )

        aa = np.einsum(
            "g,gij->ij",
            multiplicity, a
        )

        bb = np.einsum(
            "g,gi->i",
            multiplicity, b
        )

        boot_beta = np.linalg.lstsq(
            aa, bb, rcond=None
        )[0]

        draws[iteration] = contrasts(
            multiplicity, boot_beta
        )

    rows = []

    for w, weighting in enumerate(WEIGHTINGS):
        for s, stratum in enumerate(COVER_STRATA):
            for j, index in enumerate((
                "RawHeightIndex",
                "CoverAdjustedHeightIndex"
            )):
                samples = draws[:, w, s, j]
                samples = samples[np.isfinite(samples)]

                ci = (
                    np.percentile(
                        samples, [2.5, 97.5]
                    )
                    if len(samples)
                    else [np.nan, np.nan]
                )

                rows.append({
                    "weighting": weighting,
                    "Cover_stratum": stratum,
                    "index": index,
                    "Q5_minus_Q1": observed[w, s, j],
                    "ci95_low": ci[0],
                    "ci95_high": ci[1],
                    "n_Q1_grids": int(
                        group_sizes[w, s, 0].sum()
                    ),
                    "n_Q5_grids": int(
                        group_sizes[w, s, 1].sum()
                    ),
                    "n_cities_with_both": int(
                        np.sum(
                            (group_sizes[w, s, 0] > 0)
                            & (group_sizes[w, s, 1] > 0)
                        )
                    ),
                    "n_valid_bootstrap": len(samples)
                })

    return pd.DataFrame(rows)


def city_slopes(df):
    outcomes = [
        "Cover_z",
        "RawHeightIndex",
        "Hmean_residual_z",
        "HSD_residual_z",
        "HP90_residual_z",
        "CoverAdjustedHeightIndex"
    ]

    rows = []

    for city_id, city in df.groupby("city_id"):
        xx = city["ses_z"].to_numpy(float)

        if len(xx) < 5 or np.unique(xx).size < 2:
            continue

        X = np.column_stack([
            np.ones(len(xx)), xx
        ])

        inv = np.linalg.inv(X.T @ X)

        leverage = np.einsum(
            "ij,jk,ik->i",
            X, inv, X
        )

        if np.any(1 - leverage <= 1e-10):
            continue

        for outcome in outcomes:
            yy = city[outcome].to_numpy(float)

            slope = np.linalg.lstsq(
                X, yy, rcond=None
            )[0]

            resid = yy - X @ slope
            scaled = resid / (1 - leverage)

            # HC3稳健协方差
            cov = inv @ (
                X.T @ (X * scaled[:, None] ** 2)
            ) @ inv

            variance = float(cov[1, 1])

            if (
                not np.isfinite(variance)
                or variance <= 0
            ):
                continue

            se = np.sqrt(variance)
            crit = t.ppf(0.975, len(xx) - 2)

            rows.append({
                "city_id": city_id,
                "outcome": outcome,
                "n_grids": len(xx),
                "slope": slope[1],
                "se_HC3": se,
                "variance": variance,
                "ci95_low": slope[1] - crit * se,
                "ci95_high": slope[1] + crit * se
            })

    return pd.DataFrame(rows)


def reml_tau2(y, var):
    scale = max(
        float(np.var(y, ddof=1)),
        float(np.mean(var)),
        1e-12
    )

    def objective(u):
        v = var + u * scale
        w = 1 / v
        mean = np.sum(w * y) / w.sum()

        return 0.5 * (
            np.log(v).sum()
            + np.log(w.sum())
            + np.sum(w * (y - mean) ** 2)
        )

    upper = 10.0

    for _ in range(8):
        fit = minimize_scalar(
            objective,
            bounds=(0, upper),
            method="bounded",
            options={"xatol": 1e-10}
        )

        if not fit.success:
            raise RuntimeError("REML优化失败")

        if fit.x < upper * 0.95:
            break

        upper *= 10

    candidates = (0.0, fit.x)

    return float(
        min(candidates, key=objective) * scale
    )


def meta_analysis(slopes):
    rows = []

    for outcome, group in slopes.groupby("outcome"):
        y = group["slope"].to_numpy(float)
        var = group["variance"].to_numpy(float)
        k = len(y)

        if k < 3:
            continue

        fixed_w = 1 / var
        fixed_mean = np.sum(
            fixed_w * y
        ) / fixed_w.sum()

        Q = float(
            np.sum(
                fixed_w * (y - fixed_mean) ** 2
            )
        )

        i2 = (
            max(0.0, (Q - (k - 1)) / Q) * 100
            if Q > 0 else 0.0
        )

        tau2 = reml_tau2(y, var)
        weights = 1 / (var + tau2)

        estimate = float(
            np.sum(weights * y) / weights.sum()
        )

        se = np.sqrt(1 / weights.sum())

        hk_se = np.sqrt(
            max(
                1.0,
                np.sum(
                    weights * (y - estimate) ** 2
                ) / (k - 1)
            ) / weights.sum()
        )

        hk_t = t.ppf(0.975, k - 1)

        rows.append({
            "outcome": outcome,
            "n_cities": k,
            "pooled_slope": estimate,
            "ci95_low": estimate - hk_t * hk_se,
            "ci95_high": estimate + hk_t * hk_se,
            "p_value": 2 * t.sf(
                abs(estimate / hk_se), k - 1
            ),
            "tau2_REML": tau2,
            "I2_pct": i2,
            "Cochran_Q": Q,
            "Q_p": chi2.sf(Q, k - 1),
            "normal_ci95_low": (
                estimate - norm.ppf(0.975) * se
            ),
            "normal_ci95_high": (
                estimate + norm.ppf(0.975) * se
            )
        })

    return pd.DataFrame(rows)


def main():
    df, terms = prepare_data()

    (
        df, codes, cities, counts,
        x, a, b, beta
    ) = fit_index(df, terms)

    contrasts = q5q1(
        df, codes, cities, counts,
        x, a, b, beta
    )

    slopes = city_slopes(df)
    summary = meta_analysis(slopes)

    OUTPUT_DIR.mkdir(
        parents=True, exist_ok=True
    )

    df[[
        "grid_id",
        "city_id",
        "Cover",
        "ses_quintile",
        "Cover_stratum",
        "RawHeightIndex",
        "CoverAdjustedHeightIndex",
        "Hmean_residual_z",
        "HSD_residual_z",
        "HP90_residual_z"
    ]].to_csv(
        OUTPUT_DIR / "grid_height_indices.csv",
        index=False,
        encoding="utf-8-sig"
    )

    contrasts.to_csv(
        OUTPUT_DIR / "q5_q1_cover_strata.csv",
        index=False,
        encoding="utf-8-sig"
    )

    slopes.to_csv(
        OUTPUT_DIR / "city_ses_slopes.csv",
        index=False,
        encoding="utf-8-sig"
    )

    summary.to_csv(
        OUTPUT_DIR / "random_effects_meta_summary.csv",
        index=False,
        encoding="utf-8-sig"
    )


if __name__ == "__main__":
    main()
