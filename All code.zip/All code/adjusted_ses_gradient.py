
# -*- coding: utf-8 -*-


from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
from scipy.linalg import qr



INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_structure_ses.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\cover_adjusted_height_index"
)



N_BOOTSTRAP = 2000
RANDOM_SEED = 20261023
DPI = 600

OUTPUT_NAME = "adjusted_ses_gradient"

SERIES = (
    ("Cover", "CC", "#4C78A8", -0.12),
    ("Hmean", r"$H_{\mathrm{mean}}$", "#2A7F62", -0.04),
    ("HSD", r"$H_{\mathrm{SD}}$", "#D65244", 0.04),
    ("HP90", r"$H_{\mathrm{P90}}$", "#E49B20", 0.12),
)

Q_TERMS = [
    f"SES_Q{q}_vs_Q1"
    for q in range(2, 6)
]

AX_W_MM = 80.439
AX_H_MM = 62.226

FIG_W_MM = 125.0
FIG_H_MM = 112.0

AX_LEFT_MM = 31.0
AX_BOTTOM_MM = 16.0


def prepare_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(INPUT_CSV)

    fields = [
        "grid_id",
        "city_id",
        "grdi",
        "population",
        "built_density",
        "built_height",
        "distance_to_center_km",
        "climate",
        "Cover",
        "Hmean",
        "HSD",
        "HP90",
    ]

    df = pd.read_csv(
        INPUT_CSV,
        dtype={
            "grid_id": str,
            "city_id": str,
        },
        encoding="utf-8-sig",
    )

    missing = set(fields) - set(df.columns)

    if missing:
        raise ValueError(
            f"输入CSV缺少字段：{sorted(missing)}"
        )

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError(
            "grid_id/city_id缺失或grid_id重复"
        )


    numeric = fields[2:]

    df[numeric] = df[numeric].apply(
        pd.to_numeric,
        errors="coerce"
    )

    if not np.isfinite(
        df[numeric].to_numpy(float)
    ).all():
        raise ValueError(
            "输入数据存在缺失或非有限值"
        )

    valid = (
        df.grdi.between(0, 100).all()
        and df.population.ge(0).all()
        and df.built_density.between(0, 1).all()
        and df.built_height.ge(0).all()
        and df.distance_to_center_km.ge(0).all()
        and df.Cover.between(0, 100).all()
        and df.Hmean.gt(2).all()
        and df.HSD.ge(0).all()
        and df.HP90.gt(2).all()
    )

    if not valid:
        raise ValueError(
            "样本中存在超出有效范围的值"
        )

    df = df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)


    df["affluence"] = 100 - df.grdi

    df["log_population"] = np.log1p(
        df.population
    )

    df["log_building_height"] = np.log1p(
        df.built_height
    )


    to_standardize = {
        "affluence": "ses_z",
        "log_population": "population_z",
        "built_density": "density_z",
        "log_building_height": "building_z",
        "distance_to_center_km": "distance_z",
        **{
            name: f"{name}_z"
            for name, *_ in SERIES
        },
    }

    for raw, target in to_standardize.items():

        group = df.groupby("city_id")[raw]

        mean = group.transform("mean")

        sd = group.transform(
            lambda values: values.std(ddof=0)
        )

        df[target] = (
            (df[raw] - mean)
            / sd.where(sd > 0)
        ).fillna(0.0)


    df["ses_quintile"] = pd.Series(
        pd.NA,
        index=df.index,
        dtype="Int64"
    )

    for _, city in df.groupby("city_id"):

        if (
            len(city) < 5
            or city.affluence.nunique() < 5
        ):
            continue

        quintiles = pd.qcut(
            city.affluence,
            5,
            labels=False,
            duplicates="drop"
        )

        if quintiles.nunique() == 5:

            df.loc[
                city.index,
                "ses_quintile"
            ] = (
                quintiles + 1
            ).astype("Int64")


    climate = df.climate.astype(int)

    reference = (
        climate.value_counts().idxmax()
    )

    dummies = pd.get_dummies(
        climate,
        prefix="climate",
        dtype=float
    )

    dummies = dummies.drop(
        columns=f"climate_{reference}"
    )

    df = pd.concat(
        [df, dummies],
        axis=1
    )


    knots = np.quantile(
        df.Cover_z,
        (0.25, 0.50, 0.75)
    )

    cover_terms = ["Cover_z"]

    for label, knot in zip(
        ("25", "50", "75"),
        knots
    ):

        col = f"cover_hinge_{label}"

        df[col] = np.maximum(
            df.Cover_z - knot,
            0
        )

        cover_terms.append(col)


    controls = [
        "population_z",
        "density_z",
        "building_z",
        "distance_z",
        *dummies.columns,
    ]

    df = df.dropna(
        subset=["ses_quintile"]
    ).copy()

    if df.empty:
        raise ValueError(
            "没有可划分为五个SES组的城市"
        )

    for q, term in enumerate(
        Q_TERMS,
        start=2
    ):

        df[term] = (
            df.ses_quintile == q
        ).astype(float)

    return df, controls, cover_terms



def fit_fe(df, predictors, outcomes):

    codes, cities = pd.factorize(
        df.city_id,
        sort=True
    )

    n = len(df)
    g = len(cities)

    if g < 3:
        raise ValueError(
            "至少需要3座有效城市"
        )

    counts = np.bincount(
        codes,
        minlength=g
    )

    x = df[predictors].to_numpy(
        float
    ).copy()

    y = df[outcomes].to_numpy(
        float
    ).copy()


    x -= (
        pd.DataFrame(x)
        .groupby(codes)
        .transform("mean")
        .to_numpy()
    )

    y -= (
        pd.DataFrame(y)
        .groupby(codes)
        .transform("mean")
        .to_numpy()
    )


    _, r, pivots = qr(
        x,
        mode="economic",
        pivoting=True
    )

    diagonal = np.abs(
        np.diag(r)
    )

    tolerance = (
        max(x.shape)
        * np.finfo(float).eps
        * diagonal.max(initial=0)
    )

    rank = int(
        np.count_nonzero(
            diagonal > tolerance
        )
    )

    if rank == 0:
        raise ValueError(
            "模型设计矩阵没有可识别变量"
        )

    chosen = np.sort(
        pivots[:rank]
    )

    kept = [
        predictors[i]
        for i in chosen
    ]

    if not set(Q_TERMS).issubset(kept):
        raise ValueError(
            "SES五分位系数不可独立识别"
        )

    x = x[:, chosen]

    p = x.shape[1]

    if n - g - p <= 0:
        raise ValueError(
            "固定效应模型自由度不足"
        )


    a = np.empty(
        (g, p, p)
    )

    b = np.empty(
        (g, p, len(outcomes))
    )

    boundaries = np.r_[
        0,
        np.cumsum(counts)
    ]

    for k in range(g):

        lo, hi = boundaries[
            k:k + 2
        ]

        xx = x[lo:hi]
        yy = y[lo:hi]

        a[k] = xx.T @ xx
        b[k] = xx.T @ yy

    beta = np.linalg.solve(
        a.sum(axis=0),
        b.sum(axis=0)
    )

    indices = [
        kept.index(term)
        for term in Q_TERMS
    ]

    return {
        "a": a,
        "b": b,
        "beta": beta,
        "indices": indices,
        "counts": counts,
        "cities": cities,
        "g": g,
        "n": n,
    }



def estimate_and_bootstrap(
    df,
    controls,
    cover_terms
):

    cover_fit = fit_fe(
        df,
        [
            *Q_TERMS,
            *controls
        ],
        ["Cover_z"]
    )

    # 高度模型：额外调整Cover
    height_fit = fit_fe(
        df,
        [
            *Q_TERMS,
            *controls,
            *cover_terms
        ],
        [
            "Hmean_z",
            "HSD_z",
            "HP90_z"
        ]
    )

    if not np.array_equal(
        cover_fit["cities"],
        height_fit["cities"]
    ):
        raise ValueError(
            "Cover模型和高度模型城市样本不一致"
        )

    point = np.vstack([
        cover_fit["beta"][
            cover_fit["indices"], 0
        ],
        height_fit["beta"][
            height_fit["indices"], :
        ].T
    ])


    rng = np.random.default_rng(
        RANDOM_SEED
    )

    draws = np.empty(
        (N_BOOTSTRAP, 4, 4),
        dtype=float
    )

    g = cover_fit["g"]

    accepted = 0
    attempts = 0

    while (
        accepted < N_BOOTSTRAP
        and attempts < 5 * N_BOOTSTRAP
    ):

        attempts += 1

        multiplicity = rng.multinomial(
            g,
            np.full(g, 1 / g)
        )

        samples = []

        for fit in (
            cover_fit,
            height_fit
        ):

            a = np.einsum(
                "g,gij->ij",
                multiplicity,
                fit["a"]
            )

            b = np.einsum(
                "g,gik->ik",
                multiplicity,
                fit["b"]
            )

            if np.linalg.matrix_rank(a) < len(a):
                break

            beta = np.linalg.solve(
                a,
                b
            )

            samples.append(
                beta[fit["indices"], :].T
            )

        if len(samples) == 2:

            draws[accepted] = np.concatenate(
                samples,
                axis=0
            )

            accepted += 1

    if accepted < N_BOOTSTRAP:
        raise RuntimeError(
            "有效城市Bootstrap次数不足，"
            "请检查样本和共线性"
        )


    se = draws.std(
        axis=0,
        ddof=1
    )

    ci = np.quantile(
        draws,
        (0.025, 0.975),
        axis=0
    )

    records = []

    for j, (
        outcome,
        _,
        _,
        offset
    ) in enumerate(SERIES):

        for q in range(1, 6):

            if q == 1:

                est = 0.0
                err = 0.0
                low = 0.0
                high = 0.0

            else:

                k = q - 2

                est = float(
                    point[j, k]
                )

                err = float(
                    se[j, k]
                )

                low = float(
                    ci[0, j, k]
                )

                high = float(
                    ci[1, j, k]
                )

            records.append({
                "outcome": outcome,
                "quintile": q,
                "estimate_relative_to_Q1": est,
                "bootstrap_se": err,
                "se_low": est - err,
                "se_high": est + err,
                "ci95_low": low,
                "ci95_high": high,
                "plot_x": (
                    q + offset
                    if q > 1
                    else q
                ),
                "n_grids": cover_fit["n"],
                "n_cities": g,
                "n_bootstrap": N_BOOTSTRAP,
            })

    return pd.DataFrame(records)



def draw_figure(source):

    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],
        "font.size": 11,
        "axes.labelsize": 11,
        "xtick.labelsize": 11,
        "ytick.labelsize": 11,
        "legend.fontsize": 11,
        "axes.linewidth": 0.7,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "figure.facecolor": "white",
        "savefig.facecolor": "white",
    })


    fig = plt.figure(
        figsize=(
            FIG_W_MM / 25.4,
            FIG_H_MM / 25.4
        )
    )

    ax = fig.add_axes([
        AX_LEFT_MM / FIG_W_MM,
        AX_BOTTOM_MM / FIG_H_MM,
        AX_W_MM / FIG_W_MM,
        AX_H_MM / FIG_H_MM
    ])


    ax.axhline(
        0,
        color="#BABABA",
        linewidth=0.7,
        linestyle=(0, (3, 3)),
        zorder=1
    )


    handles = []

    for outcome, label, color, _ in SERIES:

        sub = source.loc[
            source.outcome.eq(outcome)
        ].sort_values("quintile")

        x = sub.plot_x.to_numpy(float)

        y = (
            sub.estimate_relative_to_Q1
            .to_numpy(float)
        )

        err = (
            sub.bootstrap_se
            .to_numpy(float)
        )


        ax.plot(
            x,
            y,
            color=color,
            linewidth=1.1,
            zorder=3
        )

        ax.errorbar(
            x[1:],
            y[1:],
            yerr=err[1:],
            fmt="o",
            linestyle="none",
            color=color,
            ecolor=color,
            elinewidth=0.9,
            capsize=3,
            capthick=0.9,
            markersize=5,
            markeredgecolor=color,
            markeredgewidth=0.4,
            zorder=5
        )

        handles.append(
            Line2D(
                [0],
                [0],
                color=color,
                linewidth=1.1,
                marker="o",
                markersize=5,
                label=label
            )
        )

    ax.scatter(
        [1],
        [0],
        s=28,
        facecolor="#92989A",
        edgecolor="white",
        linewidth=0.7,
        zorder=10
    )


    ax.set_xlim(
        0.72,
        5.28
    )

    ax.set_ylim(
        min(
            -0.25,
            float(source.se_low.min()) - 0.025
        ),
        max(
            0.18,
            float(source.se_high.max()) + 0.025
        )
    )

    ax.set_xticks(
        [1, 2, 3, 4, 5],
        ["Q1", "Q2", "Q3", "Q4", "Q5"]
    )

    ax.set_ylabel(
        "Difference from Q1 (SD)",
        labelpad=8
    )

    ax.tick_params(
        axis="both",
        direction="out",
        length=3,
        width=0.7,
        color="#303030",
        pad=4
    )

    for spine in ax.spines.values():

        spine.set_visible(True)
        spine.set_color("#606060")
        spine.set_linewidth(0.7)


    ax.legend(
        handles=handles,
        loc="lower left",
        bbox_to_anchor=(0.02, 0.03),
        ncol=1,
        frameon=False,
        fontsize=11,
        handlelength=1.55,
        handletextpad=0.45,
        labelspacing=0.22,
        borderaxespad=0
    )

    return fig



def main():

    df, controls, cover_terms = prepare_data()

    source = estimate_and_bootstrap(
        df,
        controls,
        cover_terms
    )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    source.to_csv(
        OUTPUT_DIR / f"{OUTPUT_NAME}_source_data.csv",
        index=False,
        encoding="utf-8-sig"
    )

    fig = draw_figure(source)

    try:

        for extension in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none"
            }

            if extension in ("png", "tiff"):
                options["dpi"] = DPI

            if extension == "tiff":
                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR / f"{OUTPUT_NAME}.{extension}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
