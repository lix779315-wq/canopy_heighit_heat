
# -*- coding: utf-8 -*-

from pathlib import Path

import numpy as np
import pandas as pd


SCREENING_CSV = Path(
    r"E:\李鑫论文\result summary\high_heat_screening_submission\grid_screening_details.csv"
)

CANOPY_CSV = Path(
    r"E:\李鑫论文\result summary\canopy_metrics_1m\grid_canopy_metrics_1m.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\canopy_counterfactual_submission"
)

COVER_TARGET_Q = 0.75
NEIGHBOR_FRACTION = 0.10
MIN_NEIGHBORS = 20
MIN_CITY_GRIDS = 20

SUPPORT_Q = (0.025, 0.975)
SPLINE_Q = (0, 0.25, 0.50, 0.75, 1)

N_BOOTSTRAP = 2000
RANDOM_SEED = 42

SCENARIOS = ("Height_only", "Cover_only", "Joint")



def prepare_data():
    df = pd.read_csv(
        SCREENING_CSV,
        dtype={"grid_id": str, "city_id": str},
        encoding="utf-8-sig"
    )

    canopy = pd.read_csv(
        CANOPY_CSV,
        usecols=["grid_id", "city_id", "Cover", "TallShare12"],
        dtype={"grid_id": str, "city_id": str},
        encoding="utf-8-sig"
    )

    needed = [
        "grid_id", "city_id", "newly_identified",
        "lst", "Cover", "Hmean", "grdi",
        "population", "built_density", "built_height",
        "distance_to_center_km", "climate"
    ]

    missing = set(needed) - set(df.columns)

    if missing:
        raise ValueError(f"高热筛查文件缺少字段：{sorted(missing)}")

    for data in (df, canopy):
        if (
            data[["grid_id", "city_id"]].isna().any().any()
            or data.grid_id.duplicated().any()
        ):
            raise ValueError("grid_id或city_id缺失、重复")

    flag = (
        df["newly_identified"]
        .astype(str).str.strip().str.lower()
    )

    if not flag.isin([
        "true", "false", "1", "0", "1.0", "0.0"
    ]).all():
        raise ValueError("newly_identified不是有效布尔值")

    df["newly_identified"] = flag.isin([
        "true", "1", "1.0"
    ])

    df = df.drop(
        columns=["TallShare12"],
        errors="ignore"
    )

    df = df.merge(
        canopy,
        on="grid_id",
        how="left",
        validate="one_to_one",
        suffixes=("", "_canopy"),
        indicator=True
    )

    if not df["_merge"].eq("both").all():
        raise ValueError("部分网格缺少树高指标")

    if not df.city_id.eq(df.city_id_canopy).all():
        raise ValueError("城市ID不一致")

    if not np.allclose(
        df.Cover.astype(float),
        df.Cover_canopy.astype(float),
        rtol=1e-8,
        atol=1e-8
    ):
        raise ValueError("两个文件的Cover不一致")

    df = df.drop(columns=[
        "city_id_canopy", "Cover_canopy", "_merge"
    ])

    numeric = [
        "lst", "Cover", "TallShare12", "Hmean",
        "grdi", "population", "built_density",
        "built_height", "distance_to_center_km", "climate"
    ]

    df[numeric] = df[numeric].apply(
        pd.to_numeric,
        errors="coerce"
    )

    if not np.isfinite(
        df[numeric].to_numpy(float)
    ).all():
        raise ValueError("样本包含缺失或非有限值")

    valid = (
        df.lst.between(-50, 90)
        & df.Cover.gt(0)
        & df.Cover.le(100)
        & df.TallShare12.between(0, 100)
        & df.Hmean.gt(2)
        & df.grdi.between(0, 100)
        & df.population.ge(0)
        & df.built_density.between(0, 1)
        & df.built_height.ge(0)
        & df.distance_to_center_km.ge(0)
        & df.climate.isin(range(1, 31))
    )

    if not valid.all():
        raise ValueError("样本存在超出有效范围的变量")

    df = df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)

    df["LST_anomaly_C"] = (
        df.lst
        - df.groupby("city_id").lst.transform("mean")
    )

    df["ses"] = 100 - df.grdi
    df["log_population"] = np.log1p(df.population)
    df["log_building"] = np.log1p(df.built_height)

    columns = {
        "ses": "ses_z",
        "log_population": "population_z",
        "built_density": "density_z",
        "log_building": "building_z",
        "distance_to_center_km": "distance_z"
    }

    for source, result in columns.items():
        group = df.groupby("city_id")[source]

        mean = group.transform("mean")
        sd = group.transform(
            lambda x: x.std(ddof=0)
        )

        df[result] = (
            (df[source] - mean)
            / sd.where(sd > 0)
        ).fillna(0)

    climate = df.climate.astype(int)
    counts = climate.value_counts()

    reference = min(
        counts[counts.eq(counts.max())].index
    )

    dummies = pd.get_dummies(
        climate,
        prefix="climate",
        dtype=float
    )

    dummies = dummies.drop(
        columns=f"climate_{reference}"
    )

    df = pd.concat([df, dummies], axis=1)

    controls = [
        "ses_z",
        "population_z",
        "density_z",
        "building_z",
        "distance_z",
        *dummies.columns
    ]

    return df, controls



def cover_spline(cover, knots):
    k = np.asarray(knots, dtype=float)

    if len(k) != 5 or np.any(np.diff(k) <= 0):
        raise ValueError("Cover样条的5个节点必须严格递增")

    x = np.asarray(cover, dtype=float)

    penultimate, last = k[-2:]
    cols = [x]

    for knot in k[:-2]:
        cols.append((
            np.maximum(x - knot, 0) ** 3
            - (last - knot) / (last - penultimate)
            * np.maximum(x - penultimate, 0) ** 3
            + (penultimate - knot) / (last - penultimate)
            * np.maximum(x - last, 0) ** 3
        ) / (last - k[0]) ** 2)

    return np.column_stack(cols)


def independent_columns(x):
    selected, basis = [], []

    for j in range(x.shape[1]):
        v = x[:, j].copy()
        original = np.linalg.norm(v)

        if original <= 1e-10:
            continue

        for _ in range(2):
            for q in basis:
                v -= q * np.dot(q, v)

        remaining = np.linalg.norm(v)

        if remaining > 1e-10 * original:
            selected.append(j)
            basis.append(v / remaining)

    return selected


def conditional_stats(cover, tall, query, n_neighbors):
    if (
        query < cover.min() - 1e-8
        or query > cover.max() + 1e-8
    ):
        return np.nan, np.nan, np.nan

    distance = np.abs(cover - query)

    radius = np.partition(
        distance, n_neighbors - 1
    )[n_neighbors - 1]

    neighborhood = tall[
        distance <= radius + 1e-8
    ]

    return np.quantile(
        neighborhood,
        [0.5, *SUPPORT_Q]
    )


def construct_scenarios(df):
    targets = df.loc[
        df.newly_identified,
        [
            "grid_id", "city_id", "population",
            "Cover", "TallShare12"
        ]
    ].copy()

    if targets.empty:
        raise ValueError("没有newly_identified网格")

    targets = targets.rename(columns={
        "Cover": "Cover_observed",
        "TallShare12": "TallShare12_observed"
    })

    for col in (
        "target_P75",
        "median_observed",
        "median_counterfactual",
        "lower_observed",
        "upper_observed",
        "lower_counterfactual",
        "upper_counterfactual"
    ):
        targets[col] = np.nan

    for city_id, city in df.groupby("city_id"):
        ix = targets.index[
            targets.city_id.eq(city_id)
        ]

        if not len(ix):
            continue

        cover = city.Cover.to_numpy(float)
        tall = city.TallShare12.to_numpy(float)

        if (
            len(cover) < MIN_CITY_GRIDS
            or np.unique(cover).size < 3
        ):
            continue

        neighbors = min(
            len(city),
            max(
                MIN_NEIGHBORS,
                int(np.ceil(
                    NEIGHBOR_FRACTION * len(city)
                ))
            )
        )

        target_cover = float(
            np.quantile(cover, COVER_TARGET_Q)
        )

        observed = targets.loc[
            ix, "Cover_observed"
        ].to_numpy(float)

        counterfactual = np.maximum(
            observed, target_cover
        )

        queries = np.unique(
            np.r_[observed, counterfactual]
        )

        lookup = np.array([
            conditional_stats(
                cover, tall, q, neighbors
            )
            for q in queries
        ])

        obs = lookup[
            np.searchsorted(queries, observed)
        ]

        cf = lookup[
            np.searchsorted(queries, counterfactual)
        ]

        targets.loc[ix, "target_P75"] = target_cover

        targets.loc[
            ix,
            [
                "median_observed",
                "lower_observed",
                "upper_observed"
            ]
        ] = obs

        targets.loc[
            ix,
            [
                "median_counterfactual",
                "lower_counterfactual",
                "upper_counterfactual"
            ]
        ] = cf

    targets["Height_only_Cover"] = (
        targets.Cover_observed
    )

    targets["Height_only_TallShare12"] = np.maximum(
        targets.TallShare12_observed,
        targets.median_observed
    )

    targets["Cover_only_Cover"] = np.maximum(
        targets.Cover_observed,
        targets.target_P75
    )

    targets["Cover_only_TallShare12"] = (
        targets.TallShare12_observed
    )

    targets["Joint_Cover"] = (
        targets.Cover_only_Cover
    )

    targets["Joint_TallShare12"] = np.maximum(
        targets.TallShare12_observed,
        targets.median_counterfactual
    )

    def supported(values, lower, upper):
        return (
            values.ge(lower - 1e-8)
            & values.le(upper + 1e-8)
            & lower.notna()
            & upper.notna()
        )

    support = [
        supported(
            targets.TallShare12_observed,
            targets.lower_observed,
            targets.upper_observed
        ),
        supported(
            targets.Height_only_TallShare12,
            targets.lower_observed,
            targets.upper_observed
        ),
        supported(
            targets.Cover_only_TallShare12,
            targets.lower_counterfactual,
            targets.upper_counterfactual
        ),
        supported(
            targets.Joint_TallShare12,
            targets.lower_counterfactual,
            targets.upper_counterfactual
        )
    ]

    targets["common_support"] = (
        np.logical_and.reduce(support)
    )

    return targets


def fit_model(df, controls):
    knots = np.quantile(
        df.Cover, SPLINE_Q
    )

    cover_terms = [
        "Cover_linear",
        "Cover_rcs1",
        "Cover_rcs2",
        "Cover_rcs3"
    ]

    terms = [
        *controls,
        "Hmean",
        *cover_terms,
        "TallShare12"
    ]

    x0 = np.column_stack([
        df[controls].to_numpy(float),
        df.Hmean.to_numpy(float),
        cover_spline(df.Cover, knots),
        df.TallShare12.to_numpy(float)
    ])

    y0 = df.LST_anomaly_C.to_numpy(float)

    codes, cities = pd.factorize(
        df.city_id, sort=True
    )

    counts = np.bincount(codes)
    g = len(cities)

    means_x = np.zeros((
        g, x0.shape[1]
    ))

    np.add.at(
        means_x, codes, x0
    )

    means_x /= counts[:, None]

    means_y = (
        np.bincount(codes, weights=y0)
        / counts
    )

    x = x0 - means_x[codes]
    y = y0 - means_y[codes]

    keep = independent_columns(x)

    kept = [
        terms[i] for i in keep
    ]

    if not all(
        term in kept
        for term in (
            *cover_terms,
            "TallShare12",
            "Hmean"
        )
    ):
        raise ValueError(
            "必要的树冠变量无法独立估计"
        )

    x = x[:, keep]

    if (
        g < 3
        or len(df) - g - x.shape[1] <= 0
    ):
        raise ValueError(
            "城市数量或模型自由度不足"
        )

    beta = np.linalg.lstsq(
        x, y, rcond=None
    )[0]

    p = len(beta)

    a = np.empty((g, p, p))
    b = np.empty((g, p))

    boundaries = np.r_[
        0, np.cumsum(counts)
    ]

    for c in range(g):
        xx = x[
            boundaries[c]:boundaries[c + 1]
        ]

        yy = y[
            boundaries[c]:boundaries[c + 1]
        ]

        a[c] = xx.T @ xx
        b[c] = xx.T @ yy

    return {
        "beta": beta,
        "terms": kept,
        "cover_terms": cover_terms,
        "knots": knots,
        "cities": cities,
        "counts": counts,
        "a": a,
        "b": b
    }



def scenario_difference(targets, scenario, model):
    observed = cover_spline(
        targets.Cover_observed,
        model["knots"]
    )

    changed = cover_spline(
        targets[f"{scenario}_Cover"],
        model["knots"]
    )

    difference = np.zeros((
        len(targets),
        len(model["beta"])
    ))

    for j, name in enumerate(
        model["cover_terms"]
    ):
        difference[
            :, model["terms"].index(name)
        ] = (
            changed[:, j] - observed[:, j]
        )

    difference[
        :, model["terms"].index("TallShare12")
    ] = (
        targets[
            f"{scenario}_TallShare12"
        ].to_numpy(float)
        - targets.TallShare12_observed.to_numpy(float)
    )

    return difference



def evaluate(targets, model):
    supported = targets.common_support.to_numpy(bool)
    pop = targets.population.to_numpy(float)

    city_lookup = {
        name: i
        for i, name in enumerate(model["cities"])
    }

    code = targets.city_id.map(
        city_lookup
    ).to_numpy(int)

    g = len(model["cities"])
    p = len(model["beta"])

    city_pop = np.bincount(
        code[supported],
        weights=pop[supported],
        minlength=g
    )

    total_pop = city_pop.sum()

    if total_pop <= 0:
        raise ValueError("共同支持域内没有正人口")

    city_vectors = {}
    point = {}

    for scenario in SCENARIOS:
        delta_x = scenario_difference(
            targets, scenario, model
        )

        delta = delta_x @ model["beta"]

        delta[~supported] = np.nan

        targets[
            f"{scenario}_delta_LST_C"
        ] = delta

        sums = np.zeros((g, p))

        np.add.at(
            sums,
            code[supported],
            delta_x[supported]
            * pop[supported, None]
        )

        city_vectors[scenario] = sums

        point[scenario] = float(
            sums.sum(axis=0)
            @ model["beta"]
            / total_pop
        )

    point["Joint_minus_sum"] = (
        point["Joint"]
        - point["Height_only"]
        - point["Cover_only"]
    )

    rng = np.random.default_rng(RANDOM_SEED)

    draws = np.full(
        (N_BOOTSTRAP, 4),
        np.nan
    )

    for i in range(N_BOOTSTRAP):
        multiplicity = rng.multinomial(
            g,
            np.full(g, 1 / g)
        )

        denominator = float(
            multiplicity @ city_pop
        )

        if denominator <= 0:
            continue

        a = np.einsum(
            "g,gij->ij",
            multiplicity,
            model["a"]
        )

        b = np.einsum(
            "g,gi->i",
            multiplicity,
            model["b"]
        )

        beta = np.linalg.lstsq(
            a, b, rcond=None
        )[0]

        estimates = []

        for scenario in SCENARIOS:
            vec = (
                multiplicity
                @ city_vectors[scenario]
                / denominator
            )

            solution = np.linalg.lstsq(
                a, vec, rcond=None
            )[0]

            if not np.allclose(
                a @ solution,
                vec,
                rtol=1e-6,
                atol=1e-6
            ):
                break

            estimates.append(
                float(vec @ beta)
            )

        if len(estimates) == len(SCENARIOS):
            draws[i, :3] = estimates

            draws[i, 3] = (
                estimates[2]
                - estimates[0]
                - estimates[1]
            )

    rows = []

    for j, scenario in enumerate((
        *SCENARIOS,
        "Joint_minus_sum"
    )):
        valid = draws[:, j][
            np.isfinite(draws[:, j])
        ]

        if len(valid) < max(
            100, int(N_BOOTSTRAP * 0.8)
        ):
            raise RuntimeError(
                f"{scenario}有效Bootstrap次数不足"
            )

        low, high = np.percentile(
            valid, [2.5, 97.5]
        )

        rows.append({
            "scenario": scenario,
            "delta_LST_C": point[scenario],
            "ci95_low": low,
            "ci95_high": high,
            "n_supported_grids": int(
                supported.sum()
            ),
            "n_supported_cities": int(
                targets.loc[
                    supported, "city_id"
                ].nunique()
            ),
            "supported_population": float(total_pop),
            "target_population": float(
                targets.population.sum()
            ),
            "n_valid_bootstrap": len(valid)
        })

    city_rows = []

    for city_id, city in targets.groupby("city_id"):
        sub = city.loc[
            city.common_support
        ]

        denominator = float(
            sub.population.sum()
        )

        row = {
            "city_id": city_id,
            "n_target_grids": len(city),
            "n_supported_grids": len(sub),
            "target_population": float(
                city.population.sum()
            ),
            "supported_population": denominator
        }

        for scenario in SCENARIOS:
            row[
                f"{scenario}_delta_LST_C"
            ] = (
                float(np.average(
                    sub[f"{scenario}_delta_LST_C"],
                    weights=sub.population
                ))
                if denominator > 0
                else np.nan
            )

        city_rows.append(row)

    return (
        pd.DataFrame(rows),
        pd.DataFrame(city_rows)
    )



def main():
    df, controls = prepare_data()

    targets = construct_scenarios(df)
    model = fit_model(df, controls)

    summary, cities = evaluate(
        targets, model
    )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    targets.to_csv(
        OUTPUT_DIR / "grid_counterfactual.csv",
        index=False,
        encoding="utf-8-sig"
    )

    summary.to_csv(
        OUTPUT_DIR / "scenario_summary.csv",
        index=False,
        encoding="utf-8-sig"
    )

    cities.to_csv(
        OUTPUT_DIR / "city_scenario_summary.csv",
        index=False,
        encoding="utf-8-sig"
    )


if __name__ == "__main__":
    main()
