
# -*- coding: utf-8 -*-

from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.patches import Patch

import numpy as np
import pandas as pd



INPUT_CSV = Path(
    r"E:\李鑫论文\result summary\cover_height_analysis_1m\city_results.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\results\figures\regional_cover_height"
)



OUTPUT_NAME = "regional_cover_height_percentiles"

DPI = 600
RANDOM_SEED = 20260727

FIGSIZE_MM = (82.0, 55.805)

BAR_WIDTH = 0.34
OFFSET = 0.19

CONTINENTS = (
    "Africa",
    "Asia",
    "Europe",
    "Americas",
    "Oceania"
)

RECODE = {
    "Africa": "Africa",
    "Asia": "Asia",
    "Europe": "Europe",
    "North America": "Americas",
    "South America": "Americas",
    "Americas": "Americas",
    "Oceania": "Oceania"
}



COLORS = {
    "cover_fill": "#B7D8D1",
    "cover_edge": "#006B5C",
    "cover_point": "#004F44",

    "height_fill": "#E4BBC9",
    "height_edge": "#8E1B52",
    "height_point": "#6F123E"
}



def geographic_lookup(city_ids):

    import geopandas as gpd

    root = INPUT_CSV.parents[2]

    city_shp = (
        root
        / "All Cities"
        / "AllCities_with_city_id.shp"
    )

    world_shp = (
        root
        / "All Cities"
        / "10m_cultural"
        / "10m_cultural"
        / "ne_10m_admin_0_countries.shp"
    )

    for path in (city_shp, world_shp):

        if not path.is_file():
            raise FileNotFoundError(
                f"缺少空间数据：{path}\n"
                "请检查城市边界与Natural Earth国界，"
                "或在输入CSV中添加continent字段。"
            )

    cities = gpd.read_file(city_shp)
    world = gpd.read_file(world_shp)

    if cities.crs is None or world.crs is None:
        raise ValueError(
            "城市边界或世界国界缺少CRS"
        )

    if (
        "city_id" not in cities.columns
        or "CONTINENT" not in world.columns
    ):
        raise ValueError(
            "空间数据缺少city_id或CONTINENT字段"
        )

    cities = cities[
        ["city_id", "geometry"]
    ].copy()

    cities["city_id"] = (
        cities.city_id
        .astype("string")
        .str.strip()
    )

    if (
        cities.city_id.isna().any()
        or cities.city_id.duplicated().any()
    ):
        raise ValueError(
            "城市ID缺失或重复"
        )

    if (
        cities.geometry.isna().any()
        or cities.geometry.is_empty.any()
    ):
        raise ValueError(
            "城市边界存在空几何"
        )

    cities = cities.loc[
        cities.city_id.isin(city_ids)
    ].to_crs("EPSG:6933")

    if len(cities) != len(city_ids):
        raise ValueError(
            "部分城市无法匹配城市边界"
        )

    world = world.loc[
        ~world.CONTINENT.astype(str)
        .str.casefold()
        .eq("antarctica"),

        ["CONTINENT", "geometry"]
    ].to_crs("EPSG:6933")

    if (
        world.empty
        or world.geometry.isna().any()
    ):
        raise ValueError(
            "世界国界数据异常"
        )

    spatial_index = world.sindex

    records = []

    for city in cities.itertuples(index=False):

        geom = city.geometry

        candidates = list(
            spatial_index.query(
                geom,
                predicate="intersects"
            )
        )

        best = None

        if candidates:

            areas = np.array([
                geom.intersection(
                    world.geometry.iloc[j]
                ).area

                for j in candidates
            ])

            if areas.max() > 0:

                best = int(
                    candidates[np.argmax(areas)]
                )

        if best is None:

            best = int(
                np.argmin(
                    world.geometry
                    .distance(geom)
                    .to_numpy()
                )
            )

        records.append({
            "city_id": city.city_id,

            "continent": str(
                world.iloc[best]["CONTINENT"]
            )
        })

    return pd.DataFrame(records)



def load_city_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(INPUT_CSV)

    city = pd.read_csv(
        INPUT_CSV,

        dtype={
            "city_id": "string"
        },

        encoding="utf-8-sig"
    )

    required = {
        "city_id",
        "Cover",
        "Hmean",
        "n_cover"
    }

    missing = required - set(city.columns)

    if missing:
        raise ValueError(
            f"城市统计CSV缺少字段：{sorted(missing)}"
        )

    city["city_id"] = (
        city.city_id.str.strip()
    )

    if (
        city.city_id.isna().any()
        or city.city_id.eq("").any()
        or city.city_id.duplicated().any()
    ):
        raise ValueError(
            "city_id缺失或重复"
        )


    for col in (
        "Cover",
        "Hmean",
        "n_cover"
    ):

        city[col] = pd.to_numeric(
            city[col],
            errors="coerce"
        )

    numeric = city[
        ["Cover", "Hmean", "n_cover"]
    ].to_numpy(float)

    if (
        not np.isfinite(numeric).all()
        or not city.Cover.between(0, 100).all()
        or not city.Hmean.gt(2).all()
        or not city.n_cover.gt(0).all()
    ):
        raise ValueError(
            "Cover、Hmean或n_cover存在异常"
        )

    if len(city) < 2:
        raise ValueError(
            "至少需要两座城市"
        )


    if "continent" not in city.columns:

        continent = geographic_lookup(
            set(city.city_id)
        )

        city = city.merge(
            continent,

            on="city_id",
            how="left",

            validate="one_to_one"
        )

    city["continent"] = (
        city.continent
        .astype("string")
        .str.strip()
        .replace(RECODE)
    )

    if (
        city.continent.isna().any()
        or not city.continent.isin(CONTINENTS).all()
    ):
        raise ValueError(
            "存在无法识别的大洲"
        )

    if not set(CONTINENTS).issubset(
        set(city.continent)
    ):
        raise ValueError(
            "至少有一个大洲没有城市"
        )

    return city.sort_values(
        "city_id"
    ).reset_index(drop=True)



def summarize_percentiles(city):

    city = city.copy()

    n = len(city)


    for source, target in (
        ("Cover", "cover_percentile"),
        ("Hmean", "height_percentile")
    ):

        city[target] = (
            city[source].rank(
                method="average"
            ) - 1
        ) / (n - 1) * 100


    rows = []

    for continent in CONTINENTS:

        subset = city.loc[
            city.continent.eq(continent)
        ]

        record = {
            "continent": continent,
            "n_cities": len(subset)
        }

        for metric, prefix in (
            ("cover_percentile", "cover"),
            ("height_percentile", "height")
        ):

            record[f"{prefix}_median"] = (
                subset[metric].median()
            )

            record[f"{prefix}_q1"] = (
                subset[metric].quantile(0.25)
            )

            record[f"{prefix}_q3"] = (
                subset[metric].quantile(0.75)
            )

        rows.append(record)

    return city, pd.DataFrame(rows)



def draw_figure(city, summary):

    plt.rcParams.update({
        "font.family": "sans-serif",

        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],

        "font.size": 8.0,
        "axes.labelsize": 8.3,

        "xtick.labelsize": 7.2,
        "ytick.labelsize": 7.2,

        "axes.linewidth": 0.65,

        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",

        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })


    fig = plt.figure(
        figsize=(
            FIGSIZE_MM[0] / 25.4,
            FIGSIZE_MM[1] / 25.4
        )
    )

    ax = fig.add_axes([
        0.145,
        0.19,
        0.835,
        0.76
    ])

    centers = (
        np.arange(
            len(CONTINENTS),
            dtype=float
        ) * 1.10
    )

    rng_cover = np.random.default_rng(
        RANDOM_SEED
    )

    rng_height = np.random.default_rng(
        RANDOM_SEED + 1
    )


    ax.axhline(
        50,

        color="#C2C5C5",

        linewidth=0.5,

        linestyle=(0, (3, 2.5)),

        zorder=0
    )


    for metric, prefix, positions, rng in (

        (
            "cover_percentile",
            "cover",
            centers - OFFSET,
            rng_cover
        ),

        (
            "height_percentile",
            "height",
            centers + OFFSET,
            rng_height
        )

    ):

        median = summary[
            f"{prefix}_median"
        ].to_numpy(float)

        q1 = summary[
            f"{prefix}_q1"
        ].to_numpy(float)

        q3 = summary[
            f"{prefix}_q3"
        ].to_numpy(float)


        ax.bar(
            positions,

            median,

            width=BAR_WIDTH,

            facecolor=COLORS[
                f"{prefix}_fill"
            ],

            edgecolor=COLORS[
                f"{prefix}_edge"
            ],

            linewidth=0.55,

            alpha=0.94,

            zorder=2
        )

        ax.errorbar(
            positions,

            median,

            yerr=np.vstack([
                median - q1,
                q3 - median
            ]),

            fmt="none",

            ecolor="#4F5557",

            elinewidth=0.75,

            capsize=2.2,

            capthick=0.75,

            zorder=5
        )


        for i, region in enumerate(CONTINENTS):

            values = city.loc[
                city.continent.eq(region),
                metric
            ].to_numpy(float)

            jitter = rng.uniform(
                -0.05,
                0.05,
                size=len(values)
            )

            ax.scatter(
                positions[i] + jitter,

                values,

                s=5.5,

                color=COLORS[
                    f"{prefix}_point"
                ],

                alpha=0.48,

                linewidths=0,

                zorder=4
            )


    ax.set_xlim(
        centers[0] - 0.60,
        centers[-1] + 0.60
    )

    ax.set_ylim(
        0,
        105
    )

    ax.set_yticks([
        0,
        25,
        50,
        75,
        100
    ])

    ax.set_ylabel(
        "City percentile",
        labelpad=4
    )

    ax.set_xticks(
        centers,
        CONTINENTS
    )

    ax.set_xlabel(
        "Region",
        labelpad=3
    )

    ax.tick_params(
        axis="both",

        width=0.65,

        length=2.6,

        direction="out",

        colors="#303435",

        pad=2.5
    )

    for spine in ax.spines.values():

        spine.set_visible(True)

        spine.set_color("#606060")

        spine.set_linewidth(0.65)

    ax.grid(False)


    ax.legend(
        handles=[

            Patch(
                facecolor=COLORS["cover_fill"],
                edgecolor=COLORS["cover_edge"],
                linewidth=0.55,
                label="Canopy cover"
            ),

            Patch(
                facecolor=COLORS["height_fill"],
                edgecolor=COLORS["height_edge"],
                linewidth=0.55,
                label="Mean height"
            )

        ],

        loc="upper left",

        bbox_to_anchor=(0.01, 0.995),

        ncol=1,

        frameon=False,

        fontsize=6.8,

        handlelength=0.85,

        handletextpad=0.35,

        labelspacing=0.16,

        borderaxespad=0
    )

    return fig



def main():

    city = load_city_data()

    city, summary = summarize_percentiles(
        city
    )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )


    city.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_city_percentiles.csv",

        index=False,

        encoding="utf-8-sig"
    )


    summary.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_continent_summary.csv",

        index=False,

        encoding="utf-8-sig"
    )


    fig = draw_figure(
        city,
        summary
    )

    try:

        for extension in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none"
            }

            if extension in (
                "png",
                "tiff"
            ):
                options["dpi"] = DPI

            if extension == "tiff":

                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{extension}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
