
# -*- coding: utf-8 -*-


import csv
import math
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

import fiona
import numpy as np
import rasterio
from pyproj import CRS, Transformer
from rasterio.features import geometry_mask, geometry_window
from shapely.geometry import mapping, shape
from shapely.ops import transform



GRID_SHP = Path(
    r"E:\李鑫论文\All Cities\AllCities_1km_grid_cityid.shp"
)

HEIGHT_DIR = Path(
    r"E:\李鑫论文\canopy height\1m"
)

OUTPUT_CSV = Path(
    r"E:\李鑫论文\result summary\canopy_metrics_1m\grid_canopy_metrics_1m.csv"
)

CANOPY_HEIGHT_M = 2.0
THRESHOLDS_M = range(6, 26)
SOURCE_NODATA = None



def load_tiles():
    paths = sorted(
        (
            p.resolve()
            for p in HEIGHT_DIR.rglob("*")
            if p.is_file() and p.suffix.lower() in (".tif", ".tiff")
        )
    )

    if not paths:
        raise FileNotFoundError(f"树高目录中没有TIF：{HEIGHT_DIR}")

    tiles = []

    for path in paths:
        with rasterio.open(path) as src:
            if src.count != 1 or src.crs is None:
                raise ValueError(f"影像必须为带坐标系的单波段TIF：{path}")

            tr = src.transform

            if (
                tr.a <= 0 or tr.e >= 0
                or abs(tr.b) > 1e-12
                or abs(tr.d) > 1e-12
            ):
                raise ValueError(f"影像方向或旋转参数异常：{path}")

            crs = CRS.from_user_input(src.crs)

            if crs.is_projected:
                axes = crs.axis_info

                if (
                    len(axes) < 2
                    or abs(tr.a * axes[0].unit_conversion_factor - 1) > 0.01
                    or abs(tr.e * axes[1].unit_conversion_factor + 1) > 0.01
                ):
                    raise ValueError(f"影像像元大小不是1 m：{path}")

            elif not crs.is_geographic:
                raise ValueError(f"不支持的坐标系：{path}")

            scale = float(src.scales[0])
            offset = float(src.offsets[0])

            tiles.append({
                "path": path,
                "transform": tr,
                "crs": crs,
                "width": src.width,
                "height": src.height,
                "dtype": src.dtypes[0],
                "block": src.block_shapes[0],
                "nodata": (
                    SOURCE_NODATA
                    if SOURCE_NODATA is not None
                    else src.nodata
                ),
                "scale": scale,
                "offset": offset
            })

    first = tiles[0]

    for tile in tiles[1:]:
        a = first["transform"]
        b = tile["transform"]

        if not tile["crs"].equals(first["crs"]):
            raise ValueError("树高瓦片坐标系不一致")

        if not (
            math.isclose(a.a, b.a, rel_tol=1e-9)
            and math.isclose(a.e, b.e, rel_tol=1e-9)
        ):
            raise ValueError("树高瓦片分辨率不一致")

        dx = (b.c - a.c) / a.a
        dy = (b.f - a.f) / a.e

        if (
            abs(dx - round(dx)) > 1e-4
            or abs(dy - round(dy)) > 1e-4
        ):
            raise ValueError("树高瓦片像元未对齐")

    return tiles


def create_vrt(tiles, path):
    first = tiles[0]

    xres = first["transform"].a
    yres = -first["transform"].e

    xmin = min(t["transform"].c for t in tiles)
    ymax = max(t["transform"].f for t in tiles)

    width = max(
        round((t["transform"].c - xmin) / xres) + t["width"]
        for t in tiles
    )

    height = max(
        round((ymax - t["transform"].f) / yres) + t["height"]
        for t in tiles
    )

    if width >= 2**31 or height >= 2**31:
        raise ValueError("VRT范围过大，请分区域处理")

    root = ET.Element(
        "VRTDataset",
        rasterXSize=str(width),
        rasterYSize=str(height)
    )

    ET.SubElement(root, "SRS").text = first["crs"].to_wkt()

    ET.SubElement(root, "GeoTransform").text = (
        f"{xmin:.17g}, {xres:.17g}, 0, "
        f"{ymax:.17g}, 0, {-yres:.17g}"
    )

    band = ET.SubElement(
        root,
        "VRTRasterBand",
        dataType="Float64",
        band="1"
    )

    ET.SubElement(band, "NoDataValue").text = "nan"

    dtype_map = {
        "uint8": "Byte",
        "int8": "Int8",
        "uint16": "UInt16",
        "int16": "Int16",
        "uint32": "UInt32",
        "int32": "Int32",
        "float32": "Float32",
        "float64": "Float64",
        "uint64": "UInt64",
        "int64": "Int64"
    }

    for tile in tiles:
        source = ET.SubElement(band, "ComplexSource")

        ET.SubElement(
            source,
            "SourceFilename",
            relativeToVRT="0"
        ).text = str(tile["path"])

        ET.SubElement(source, "SourceBand").text = "1"

        by, bx = tile["block"]

        ET.SubElement(
            source,
            "SourceProperties",
            RasterXSize=str(tile["width"]),
            RasterYSize=str(tile["height"]),
            DataType=dtype_map[tile["dtype"]],
            BlockXSize=str(bx),
            BlockYSize=str(by)
        )

        ET.SubElement(
            source,
            "SrcRect",
            xOff="0",
            yOff="0",
            xSize=str(tile["width"]),
            ySize=str(tile["height"])
        )

        ET.SubElement(
            source,
            "DstRect",
            xOff=str(round((tile["transform"].c - xmin) / xres)),
            yOff=str(round((ymax - tile["transform"].f) / yres)),
            xSize=str(tile["width"]),
            ySize=str(tile["height"])
        )

        if tile["nodata"] is not None:
            ET.SubElement(
                source,
                "NODATA"
            ).text = str(tile["nodata"])

        ET.SubElement(source, "UseMaskBand").text = "true"

        ET.SubElement(
            source,
            "ScaleRatio"
        ).text = str(tile["scale"])

        ET.SubElement(
            source,
            "ScaleOffset"
        ).text = str(tile["offset"])

    ET.ElementTree(root).write(
        path,
        encoding="utf-8",
        xml_declaration=True
    )


def canopy_metrics(heights, total_pixels):
    n = len(heights)

    canopy = heights[heights > CANOPY_HEIGHT_M]
    m = len(canopy)

    result = {
        "grid_pixels": total_pixels,
        "valid_pixels": n,
        "valid_fraction": (
            n / total_pixels if total_pixels else 0.0
        ),
        "canopy_pixels": m,
        "Cover": 100 * m / n if n else np.nan,
        "Hmean": float(np.mean(canopy)) if m else np.nan,
        "HSD": float(np.std(canopy, ddof=0)) if m else np.nan,
        "HP90": float(np.percentile(canopy, 90)) if m else np.nan
    }

    sorted_canopy = np.sort(canopy)

    for t in THRESHOLDS_M:
        upper = int(
            m - np.searchsorted(
                sorted_canopy,
                t,
                side="right"
            )
        )

        result[f"UpperPixels{t}"] = upper

        result[f"UpperCover{t}"] = (
            100 * upper / n if n else np.nan
        )

        result[f"TallShare{t}"] = (
            100 * upper / m if m else np.nan
        )

        result[f"LowerCover{t}"] = (
            100 * (m - upper) / n if n else np.nan
        )

    return result



def get_grid_heights(src, geom, transform_coords):
    projected = transform(transform_coords, geom)
    geo = mapping(projected)

    window = geometry_window(
        src,
        [geo],
        boundless=True
    )

    if window.width * window.height > 30_000_000:
        raise MemoryError("单网格像元数量异常")

    inside = geometry_mask(
        [geo],
        out_shape=(
            int(window.height),
            int(window.width)
        ),
        transform=src.window_transform(window),
        invert=True,
        all_touched=False
    )

    total = int(inside.sum())

    if total == 0:
        return np.empty(0), 0

    data = src.read(
        1,
        window=window,
        boundless=True,
        masked=True,
        out_dtype="float64",
        fill_value=np.nan
    )

    valid = (
        inside
        & ~np.ma.getmaskarray(data)
        & np.isfinite(data.data)
        & (data.data >= 0)
    )

    return data.data[valid], total



def main():
    if not GRID_SHP.is_file():
        raise FileNotFoundError(GRID_SHP)

    tiles = load_tiles()

    OUTPUT_CSV.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    with tempfile.TemporaryDirectory() as tmp:
        vrt_file = Path(tmp) / "height.vrt"

        create_vrt(tiles, vrt_file)

        with (
            fiona.open(GRID_SHP) as grids,
            rasterio.open(vrt_file) as heights,
            OUTPUT_CSV.open(
                "w",
                newline="",
                encoding="utf-8-sig"
            ) as out
        ):
            if not grids.crs:
                raise ValueError("网格文件缺少坐标系")

            for field in ("grid_id", "city_id"):
                if field not in grids.schema["properties"]:
                    raise ValueError(f"网格缺少字段：{field}")

            to_height = Transformer.from_crs(
                grids.crs,
                heights.crs,
                always_xy=True
            ).transform

            names = [
                "grid_id",
                "city_id",
                *canopy_metrics(np.empty(0), 0)
            ]

            writer = csv.DictWriter(
                out,
                fieldnames=names
            )
            writer.writeheader()

            used_ids = set()

            for feature in grids:
                attrs = feature["properties"]

                grid_id = attrs["grid_id"]
                city_id = attrs["city_id"]

                if (
                    grid_id is None
                    or city_id is None
                    or str(grid_id) in used_ids
                ):
                    raise ValueError("网格ID或城市ID无效、重复")

                used_ids.add(str(grid_id))

                if not feature["geometry"]:
                    raise ValueError(
                        f"网格缺少几何：{grid_id}"
                    )

                geom = shape(feature["geometry"])

                if not geom.is_valid or geom.is_empty:
                    raise ValueError(
                        f"网格几何无效：{grid_id}"
                    )

                pixels, total = get_grid_heights(
                    heights,
                    geom,
                    to_height
                )

                row = {
                    "grid_id": str(grid_id),
                    "city_id": str(city_id),
                    **canopy_metrics(pixels, total)
                }

                writer.writerow({
                    k: (
                        ""
                        if isinstance(v, (float, np.floating))
                        and not np.isfinite(v)
                        else v
                    )
                    for k, v in row.items()
                })


if __name__ == "__main__":
    main()
