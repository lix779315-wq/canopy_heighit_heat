
# -*- coding: utf-8 -*-


from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.colors import (
    LinearSegmentedColormap,
    TwoSlopeNorm
)
from matplotlib.ticker import (
    FixedLocator,
    FuncFormatter,
    NullLocator
)

import numpy as np
import pandas as pd
from scipy.stats import norm



INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_thermal.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\upper_canopy_models_submission"
)



OUTPUT_NAME = "city_upper_canopy_LST_heterogeneity"

MIN_CITY_GRIDS = 30
MIN_RESIDUAL_DF = 10

RANDOM_SEED = 20260917
DPI = 600

FIG_W_MM = 89.0
FIG_H_MM = 64.0

AX_W_MM = 71.645
AX_H_MM = 47.950

AX_LEFT_MM = 14.0
AX_BOTTOM_MM = 11.3

LINEAR_THRESHOLD = 0.6
LINEAR_SCALE = 2.2

JITTER_HALF_WIDTH = 0.035
DENSITY_HALF_HEIGHT = 0.22

POINT_CENTRE_Y = 0.50
POOLED_Y = -0.17



COLOR_NODES = (
    "#BC453B",
    "#E38D72",
    "#EFBBA6",
    "#F2F2F0",
    "#C9DDEC",
    "#9BC6E5",
    "#2D6DA6"
)



def prepare_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(
            f"找不到输入CSV：{INPUT_CSV}"
        )

    df = pd.read_csv(
        INPUT_CSV,
        dtype={
            "grid_id": "string",
            "city_id": "string"
        },
        encoding="utf-8-sig"
    )

    required = {
        "grid_id",
        "city_id",
        "lst",
        "Cover",
        "UpperCover12",
        "grdi",
        "population",
        "built_density",
        "built_height",
        "distance_to_center_km"
    }

    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            f"输入CSV缺少字段：{sorted(missing)}"
        )

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError(
            "grid_id/city_id不能为空，且grid_id不能重复"
        )

    numeric = sorted(
        required - {"grid_id", "city_id"}
    )

    if "smod" in df.columns:
        numeric.append("smod")

    df[numeric] = df[numeric].apply(
        pd.to_numeric,
        errors="coerce"
    )

    if not np.isfinite(
        df[numeric].to_numpy(float)
    ).all():
        raise ValueError(
            "存在缺失或非有限数值"
        )

    valid = (
        df.lst.between(-50, 90)
        & df.Cover.between(0, 100)
        & df.UpperCover12.between(0, 100)
        & df.UpperCover12.le(df.Cover + 1e-6)
        & df.grdi.between(0, 100)
        & df.population.ge(0)
        & df.built_density.between(0, 1)
        & df.built_height.ge(0)
        & df.distance_to_center_km.ge(0)
    )

    if not valid.all():
        raise ValueError(
            "样本变量超出规定范围，请检查03预处理结果"
        )

    df = df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)

    df["ses_affluence"] = 100.0 - df.grdi

    df["log_population"] = np.log1p(
        df.population
    )

    df["log_built_height"] = np.log1p(
        df.built_height
    )


    controls = []

    standardize = (
        ("ses_affluence", "ses_z"),
        ("log_population", "population_z"),
        ("built_density", "density_z"),
        ("log_built_height", "building_z"),
        ("distance_to_center_km", "distance_z")
    )

    for source, target in standardize:

        group = df.groupby("city_id")[source]

        mean = group.transform("mean")

        sd = group.transform(
            lambda col: col.std(ddof=0)
        )

        df[target] = (
            (df[source] - mean)
            / sd.where(sd > 0)
        ).fillna(0.0)

        controls.append(target)

    # 存在SMOD时纳入城市中心控制变量
    has_smod = "smod" in df.columns

    if has_smod:

        df["urban_centre"] = (
            df.smod.eq(30).astype(float)
        )

        controls.append("urban_centre")

    return df, controls, has_smod



def independent_columns(x):

    selected = []
    basis = []

    for j in range(x.shape[1]):

        v = x[:, j].astype(float).copy()

        original_norm = np.linalg.norm(v)

        if original_norm <= 1e-10:
            continue

        for _ in range(2):

            for q in basis:
                v -= (q @ v) * q

        remaining_norm = np.linalg.norm(v)

        if remaining_norm > 1e-10 * original_norm:

            selected.append(j)

            basis.append(
                v / remaining_norm
            )

    return selected



def city_coefficients(df, controls):

    records = []

    terms = [
        *controls,
        "Cover",
        "UpperCover12"
    ]

    for city_id, city in df.groupby(
        "city_id",
        sort=True
    ):

        n = len(city)

        row = {
            "city_id": city_id,
            "n_grids": n,
            "eligible": False,
            "estimate": np.nan,
            "se_HC1": np.nan,
            "variance": np.nan,
            "residual_df": np.nan,
            "ci95_low": np.nan,
            "ci95_high": np.nan
        }

        if "city_name" in df.columns:

            row["city_name"] = str(
                city.city_name.iloc[0]
            )


        if (
            n < MIN_CITY_GRIDS
            or city.Cover.nunique() < 3
            or city.UpperCover12.nunique() < 3
        ):
            records.append(row)
            continue


        design = np.column_stack([
            np.ones(n),
            city[terms].to_numpy(float)
        ])

        names = [
            "intercept",
            *terms
        ]

        keep = independent_columns(
            design
        )

        kept = [
            names[i]
            for i in keep
        ]

        if (
            "UpperCover12" not in kept
            or n - len(keep) < MIN_RESIDUAL_DF
        ):
            records.append(row)
            continue

        x = design[:, keep]

        y = city.lst.to_numpy(float)


        try:

            _, r = np.linalg.qr(
                x,
                mode="reduced"
            )

            inverse_r = np.linalg.solve(
                r,
                np.eye(len(keep))
            )

            beta = np.linalg.lstsq(
                x,
                y,
                rcond=None
            )[0]

        except np.linalg.LinAlgError:

            records.append(row)
            continue

        residual = y - x @ beta


        bread = (
            inverse_r @ inverse_r.T
        )

        meat = (
            x.T @ (
                x * residual[:, None] ** 2
            )
        )

        covariance = (
            (n / (n - len(keep)))
            * bread
            @ meat
            @ bread
        )

        j = kept.index("UpperCover12")

        variance = float(
            covariance[j, j]
        )

        if (
            not np.isfinite(variance)
            or variance <= 0
        ):
            records.append(row)
            continue

        estimate = float(beta[j])

        se = float(
            np.sqrt(variance)
        )

        critical = norm.ppf(0.975)

        row.update({
            "eligible": True,
            "estimate": estimate,
            "se_HC1": se,
            "variance": variance,
            "ci95_low": estimate - critical * se,
            "ci95_high": estimate + critical * se,
            "residual_df": n - len(keep)
        })

        records.append(row)

    cities = pd.DataFrame(
        records
    )

    if int(cities.eligible.sum()) < 3:
        raise ValueError(
            "可估计UpperCover12–LST关系的城市不足3座"
        )

    return cities



def random_effects_dl(cities):

    eligible = cities.loc[
        cities.eligible
    ]

    effects = (
        eligible.estimate
        .to_numpy(float)
    )

    variances = (
        eligible.variance
        .to_numpy(float)
    )

    n = len(effects)


    fixed_weights = (
        1.0 / variances
    )

    fixed_mean = (
        np.sum(fixed_weights * effects)
        / fixed_weights.sum()
    )

    q_stat = float(
        np.sum(
            fixed_weights
            * (effects - fixed_mean) ** 2
        )
    )

    df_q = n - 1

    c = float(
        fixed_weights.sum()
        - (fixed_weights ** 2).sum()
        / fixed_weights.sum()
    )

    if c <= 0:
        raise ValueError(
            "无法计算随机效应的异质性方差"
        )


    tau2 = max(
        0.0,
        (q_stat - df_q) / c
    )


    re_weights = (
        1.0 / (variances + tau2)
    )

    mean = float(
        np.sum(re_weights * effects)
        / re_weights.sum()
    )

    se = float(
        np.sqrt(
            1.0 / re_weights.sum()
        )
    )

    crit = norm.ppf(0.975)

    i2 = (
        max(
            0.0,
            (q_stat - df_q) / q_stat
        ) * 100
        if q_stat > 0
        else 0.0
    )

    return pd.DataFrame([{
        "method": "DerSimonian-Laird",
        "city_se_method": "HC1",
        "n_cities": n,
        "n_original_cities": len(cities),

        "n_negative": int(
            np.count_nonzero(effects < 0)
        ),

        "n_positive": int(
            np.count_nonzero(effects > 0)
        ),

        "estimate": mean,
        "se": se,

        "ci95_low": mean - crit * se,
        "ci95_high": mean + crit * se,

        "I2_pct": i2,
        "tau2_DL": tau2,
        "Cochran_Q": q_stat
    }])



def gaussian_kde_silverman(values, x):

    q25, q75 = np.quantile(
        values,
        [0.25, 0.75]
    )

    sd = float(
        np.std(values, ddof=1)
    )

    scale = min(
        sd,
        (q75 - q25) / 1.349
    )

    if scale <= 0:
        scale = sd

    if (
        scale <= 0
        or not np.isfinite(scale)
    ):
        raise ValueError(
            "城市系数无足够离散度，无法绘制核密度"
        )

    bandwidth = (
        0.9
        * scale
        * len(values) ** (-0.2)
    )

    z = (
        x[:, None] - values[None, :]
    ) / bandwidth

    pdf = (
        np.exp(-0.5 * z * z).mean(axis=1)
        / (
            bandwidth
            * np.sqrt(2 * np.pi)
        )
    )

    return pdf



def draw_figure(cities, pooled):

    plt.rcParams.update({
        "font.family": "sans-serif",

        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],

        "font.size": 7,
        "axes.labelsize": 7,
        "xtick.labelsize": 6.2,
        "ytick.labelsize": 6.2,

        "axes.linewidth": 0.65,
        "axes.edgecolor": "#333333",

        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,

        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })

    subset = cities.loc[
        cities.eligible
    ].sort_values("city_id")

    effects = (
        subset.estimate
        .to_numpy(float)
    )

    mu = float(
        pooled.estimate.iloc[0]
    )

    lo = float(
        pooled.ci95_low.iloc[0]
    )

    hi = float(
        pooled.ci95_high.iloc[0]
    )


    left = min(
        -55.0,
        (
            float(effects.min()) * 1.08
            if effects.min() < 0
            else -55.0
        )
    )

    right = max(
        8.5,
        (
            float(effects.max()) * 1.08
            if effects.max() > 0
            else 8.5
        )
    )


    fig = plt.figure(
        figsize=(
            FIG_W_MM / 25.4,
            FIG_H_MM / 25.4
        )
    )

    ax = fig.add_axes([
        AX_LEFT_MM / FIG_W_MM,
        AX_BOTTOM_MM / FIG_H_MM,
        AX_W_MM / FIG_W_MM,
        AX_H_MM / FIG_H_MM
    ])


    ax.set_xscale(
        "symlog",
        base=10,
        linthresh=LINEAR_THRESHOLD,
        linscale=LINEAR_SCALE
    )

    ax.set_xlim(
        left,
        right
    )

    ax.set_ylim(
        -0.45,
        1.05
    )

    ax.set_yticks([])

    ticks = [
        -40,
        -4,
        -0.6,
        -0.4,
        -0.2,
        0,
        0.2,
        0.4,
        0.6,
        4,
        8
    ]

    ax.xaxis.set_major_locator(
        FixedLocator([
            value
            for value in ticks
            if left < value < right
        ])
    )

    ax.xaxis.set_minor_locator(
        NullLocator()
    )

    ax.xaxis.set_major_formatter(
        FuncFormatter(
            lambda value, pos:
            f"{value:g}".replace("-", "−")
        )
    )

    ax.tick_params(
        axis="x",
        direction="out",
        pad=2.5
    )

    ax.set_xlabel(
        r"$UC_{12}$–LST association (°C per 1 pp)",
        labelpad=3
    )

    transform = (
        ax.xaxis.get_transform()
    )

    transformed = np.linspace(
        float(
            transform.transform(left)
        ),
        float(
            transform.transform(right)
        ),
        16000
    )

    x = (
        transform.inverted()
        .transform(transformed)
    )

    density = gaussian_kde_silverman(
        effects,
        x
    )

    if (
        not np.isfinite(density).all()
        or density.max() <= 0
    ):
        raise ValueError(
            "核密度计算失败"
        )

    dy = (
        DENSITY_HALF_HEIGHT
        * density
        / density.max()
    )

    lower = POINT_CENTRE_Y - dy
    upper = POINT_CENTRE_Y + dy


    ax.fill_between(
        x,
        lower,
        upper,
        color="#E7EDF3",
        alpha=0.5,
        linewidth=0,
        zorder=1
    )

    ax.plot(
        x,
        lower,
        color="#AEBFD0",
        linewidth=0.65,
        zorder=2
    )

    ax.plot(
        x,
        upper,
        color="#AEBFD0",
        linewidth=0.65,
        zorder=2
    )


    ax.axvline(
        0,
        color="#BDBDBD",
        linewidth=0.65,
        linestyle=(0, (3, 2)),
        zorder=1.5
    )


    rng = np.random.default_rng(
        RANDOM_SEED
    )

    jitter = rng.uniform(
        -JITTER_HALF_WIDTH,
        JITTER_HALF_WIDTH,
        len(effects)
    )

    cmap = LinearSegmentedColormap.from_list(
        "coral_grey_blue",
        COLOR_NODES,
        N=1021
    )

    color_norm = TwoSlopeNorm(
        vmin=-0.6,
        vcenter=0,
        vmax=0.6
    )

    colors = cmap(
        color_norm(
            np.clip(
                effects,
                -0.6,
                0.6
            )
        )
    )

    ax.scatter(
        effects,
        POINT_CENTRE_Y + jitter,

        s=6,
        c=colors,
        alpha=0.70,

        edgecolors="none",
        zorder=3
    )


    ax.errorbar(
        mu,
        POOLED_Y,

        xerr=[
            [mu - lo],
            [hi - mu]
        ],

        fmt="D",

        color="#222222",
        markerfacecolor="#111111",

        markersize=4.2,
        elinewidth=1.0,

        capsize=2.1,
        capthick=0.85,

        zorder=4
    )


    ax.text(
        0.985,
        0.95,

        f"I² = {float(pooled.I2_pct.iloc[0]):.1f}%",

        transform=ax.transAxes,

        ha="right",
        va="top",

        fontsize=7,
        color="#222222"
    )


    for spine in ax.spines.values():

        spine.set_visible(True)
        spine.set_color("#333333")
        spine.set_linewidth(0.65)

    ax.grid(False)

    return fig



def main():

    df, controls, has_smod = prepare_data()

    cities = city_coefficients(
        df,
        controls
    )

    pooled = random_effects_dl(
        cities
    )

    pooled["smod_adjusted"] = has_smod

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    cities.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_city_coefficients.csv",

        index=False,
        encoding="utf-8-sig"
    )

    pooled.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_random_effects.csv",

        index=False,
        encoding="utf-8-sig"
    )

    fig = draw_figure(
        cities,
        pooled
    )

    try:

        for extension in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none",
                "bbox_inches": None
            }

            if extension in ("png", "tiff"):
                options["dpi"] = DPI

            if extension == "tiff":
                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{extension}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
