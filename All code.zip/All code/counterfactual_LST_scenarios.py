
# -*- coding: utf-8 -*-


from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.ticker import MultipleLocator, FormatStrFormatter

import numpy as np
import pandas as pd


INPUT_CSV = Path(
    r"E:\李鑫论文\result summary\canopy_counterfactual_submission"
    r"\scenario_summary.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\canopy_counterfactual_submission"
)


OUTPUT_NAME = "counterfactual_LST_scenarios"

DPI = 600

SCENARIO_ORDER = (
    "height",
    "cover",
    "joint"
)

LABELS = {
    "height": "Height-only",
    "cover": "Cover-only",
    "joint": "Joint"
}

COLORS = {
    "height": "#008C7A",
    "cover": "#E76F00",
    "joint": "#1F5AA6"
}




AX_W_MM = 84.730
AX_H_MM = 72.371


LEFT_MM = 17.5
RIGHT_MM = 4.0
BOTTOM_MM = 16.0
TOP_MM = 4.0

FIG_W_MM = (
    LEFT_MM + AX_W_MM + RIGHT_MM
)

FIG_H_MM = (
    BOTTOM_MM + AX_H_MM + TOP_MM
)



def load_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(
            f"找不到输入文件：{INPUT_CSV}"
        )

    raw = pd.read_csv(
        INPUT_CSV,
        encoding="utf-8-sig"
    )

    alternatives = {
        "scenario": (
            "scenario",
            "estimand"
        ),
        "estimate": (
            "delta_LST_C",
            "delta_lst_C"
        ),
        "low": (
            "ci95_low",
            "ci95_low_C"
        ),
        "high": (
            "ci95_high",
            "ci95_high_C"
        )
    }

    selected = {}

    for role, options in alternatives.items():

        found = next(
            (
                column
                for column in options
                if column in raw.columns
            ),
            None
        )

        if found is None:
            raise ValueError(
                f"输入文件缺少{role}字段：{options}"
            )

        selected[role] = found

    data = raw[
        [
            selected["scenario"],
            selected["estimate"],
            selected["low"],
            selected["high"]
        ]
    ].copy()

    data.columns = [
        "scenario_input",
        "estimate",
        "ci_low",
        "ci_high"
    ]


    aliases = {
        "height_only": "height",
        "height-only": "height",
        "height": "height",

        "structure_only": "height",
        "structure-only": "height",
        "structure": "height",

        "cover_only": "cover",
        "cover-only": "cover",
        "cover": "cover",

        "joint": "joint"
    }

    data["scenario"] = (
        data["scenario_input"]
        .astype(str)
        .str.strip()
        .str.lower()
        .map(aliases)
    )

    data = data.loc[
        data.scenario.notna()
    ].copy()


    if (
        len(data) != 3
        or data.scenario.duplicated().any()
        or set(data.scenario) != set(SCENARIO_ORDER)
    ):
        raise ValueError(
            "必须包含Height-only、Cover-only、Joint三个情景"
        )


    for field in (
        "estimate",
        "ci_low",
        "ci_high"
    ):
        data[field] = pd.to_numeric(
            data[field],
            errors="coerce"
        )

    numeric = data[
        [
            "estimate",
            "ci_low",
            "ci_high"
        ]
    ].to_numpy(float)

    if not np.isfinite(numeric).all():
        raise ValueError(
            "点估计或置信区间存在无效数值"
        )

    if not (
        data.ci_low < data.ci_high
    ).all():
        raise ValueError(
            "95%置信区间上下限异常"
        )


    data = (
        data.set_index("scenario")
        .loc[list(SCENARIO_ORDER)]
        .reset_index()
    )

    data["display_label"] = (
        data.scenario.map(LABELS)
    )

    data["color"] = (
        data.scenario.map(COLORS)
    )

    return data



def configure_style():

    plt.rcParams.update({
        "font.family": "sans-serif",

        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],

        "font.size": 9.0,

        "axes.labelsize": 9.0,

        "xtick.labelsize": 8.5,

        "ytick.labelsize": 8.5,

        "axes.linewidth": 0.8,

        "xtick.major.width": 0.8,

        "ytick.major.width": 0.8,

        "xtick.major.size": 3,

        "ytick.major.size": 3,

        "pdf.fonttype": 42,

        "ps.fonttype": 42,

        "svg.fonttype": "none",

        "axes.unicode_minus": True,

        "figure.facecolor": "white",

        "axes.facecolor": "white",

        "savefig.facecolor": "white"
    })



def draw_figure(data):

    configure_style()


    fig = plt.figure(
        figsize=(
            FIG_W_MM / 25.4,
            FIG_H_MM / 25.4
        ),
        facecolor="white"
    )

    ax = fig.add_axes([
        LEFT_MM / FIG_W_MM,
        BOTTOM_MM / FIG_H_MM,
        AX_W_MM / FIG_W_MM,
        AX_H_MM / FIG_H_MM
    ])


    ax.axhline(
        0,
        color="#A7A7A7",
        linewidth=0.8,
        linestyle=(0, (3, 3)),
        zorder=1
    )


    for i, row in enumerate(
        data.itertuples(index=False)
    ):

        color = row.color


        ax.vlines(
            i,
            row.ci_low,
            row.ci_high,
            color=color,
            linewidth=1.35,
            zorder=3
        )


        ax.hlines(
            [
                row.ci_low,
                row.ci_high
            ],
            i - 0.05,
            i + 0.05,
            color=color,
            linewidth=1.10,
            zorder=3
        )


        ax.scatter(
            i,
            row.estimate,
            s=41,
            facecolor=color,
            edgecolor="white",
            linewidth=0.65,
            zorder=4
        )


    ax.set_xlim(
        -0.55,
        2.55
    )

    ax.set_xticks(
        [0, 1, 2],
        [
            "Height-only",
            "Cover-only",
            "Joint"
        ]
    )


    ax.set_ylabel(
        "LST change (°C)",
        labelpad=5
    )


    y_min = min(
        -0.09,
        float(
            data[
                ["estimate", "ci_low"]
            ].min().min()
        ) - 0.005
    )

    y_max = max(
        0.015,
        float(
            data[
                ["estimate", "ci_high"]
            ].max().max()
        ) + 0.005
    )

    ax.set_ylim(
        y_min,
        y_max
    )

    ax.yaxis.set_major_locator(
        MultipleLocator(0.02)
    )

    ax.yaxis.set_major_formatter(
        FormatStrFormatter("%.2f")
    )


    ax.grid(False)

    ax.tick_params(
        axis="x",
        direction="out",
        length=3,
        width=0.8,
        pad=4
    )

    ax.tick_params(
        axis="y",
        direction="out",
        length=3,
        width=0.8,
        pad=3
    )

    for spine in ax.spines.values():

        spine.set_visible(True)

        spine.set_color("#333333")

        spine.set_linewidth(0.8)

    return fig



def main():

    data = load_data()

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    data[
        [
            "scenario",
            "display_label",
            "estimate",
            "ci_low",
            "ci_high"
        ]
    ].to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_source_data.csv",
        index=False,
        encoding="utf-8-sig"
    )

    fig = draw_figure(data)

    try:

        for extension in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none",
                "bbox_inches": None
            }

            if extension in ("png", "tiff"):
                options["dpi"] = DPI

            if extension == "tiff":
                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{extension}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
