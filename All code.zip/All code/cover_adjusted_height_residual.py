
# -*- coding: utf-8 -*-

from pathlib import Path
import re
import unicodedata

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize
import numpy as np
import pandas as pd



INPUT_CSV = Path(
    r"E:\李鑫论文\result summary\cover_height_analysis_1m\city_results.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\results\figures\cover_adjusted_height_residual"
)



OUTPUT_NAME = "cover_adjusted_height_residual"

EXPECTED_CITIES = 140
DPI = 600

FIG_WIDTH_MM = 85.072
FIG_HEIGHT_MM = 74.270

HIGHLIGHTS = {
    "vancouver": (
        "Vancouver",
        (5, 7)
    ),
    "seattle": (
        "Seattle",
        (5, 7)
    ),
    "hong kong": (
        "Hong Kong",
        (5, -13)
    ),
}



def normalize_city(value):

    value = unicodedata.normalize(
        "NFKD",
        str(value)
    )

    value = "".join(
        c for c in value
        if not unicodedata.combining(c)
    )

    value = (
        value.casefold()
        .replace("-", " ")
        .strip()
    )

    return re.sub(
        r"\s+",
        " ",
        value
    )



def load_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(INPUT_CSV)

    df = pd.read_csv(
        INPUT_CSV,
        dtype={"city_id": "string"},
        encoding="utf-8-sig"
    )

    required = {
        "city_id",
        "Cover",
        "Hmean",
        "Hmean_cover_residual_m",
        "n_cover"
    }

    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            f"城市统计CSV缺少字段：{sorted(missing)}"
        )

    df["city_id"] = df["city_id"].str.strip()

    if (
        df.city_id.isna().any()
        or df.city_id.eq("").any()
        or df.city_id.duplicated().any()
    ):
        raise ValueError(
            "city_id缺失、为空或重复"
        )


    if "city_name" not in df.columns:

        city_mapping = (
            INPUT_CSV.parents[2]
            / "All Cities"
            / "AllCities_city_id_mapping.csv"
        )

        if not city_mapping.is_file():
            raise FileNotFoundError(
                "城市统计CSV没有city_name，"
                "且找不到城市映射表："
                f"{city_mapping}"
            )

        mapping = pd.read_csv(
            city_mapping,
            dtype={"city_id": "string"},
            encoding="utf-8-sig"
        )

        if not {
            "city_id",
            "city_name"
        }.issubset(mapping.columns):

            raise ValueError(
                "城市映射表缺少city_id或city_name"
            )

        mapping = mapping[
            ["city_id", "city_name"]
        ].copy()

        mapping["city_id"] = (
            mapping.city_id.str.strip()
        )

        if (
            mapping.city_id.isna().any()
            or mapping.city_id.duplicated().any()
        ):
            raise ValueError(
                "城市映射表city_id缺失或重复"
            )

        df = df.merge(
            mapping,
            on="city_id",
            how="left",
            validate="one_to_one"
        )

    if (
        df.city_name.isna().any()
        or df.city_name.astype(str)
        .str.strip()
        .eq("")
        .any()
    ):
        raise ValueError(
            "部分城市缺少city_name"
        )


    numeric = [
        "Cover",
        "Hmean",
        "Hmean_cover_residual_m",
        "n_cover"
    ]

    df[numeric] = df[numeric].apply(
        pd.to_numeric,
        errors="coerce"
    )

    if not np.isfinite(
        df[numeric].to_numpy(dtype=float)
    ).all():

        raise ValueError(
            "城市统计字段存在缺失或非有限值"
        )

    valid = (
        df.Cover.between(0, 100).all()
        and df.Hmean.gt(2).all()
        and df.n_cover.gt(0).all()
    )

    if not valid:
        raise ValueError(
            "Cover、Hmean或n_cover存在异常值"
        )

    if len(df) != EXPECTED_CITIES:
        raise ValueError(
            f"预期{EXPECTED_CITIES}座城市，"
            f"实际{len(df)}座"
        )


    x = np.column_stack([
        np.ones(len(df)),
        df.Cover.to_numpy(float)
    ])

    y = df.Hmean.to_numpy(float)

    beta = np.linalg.lstsq(
        x,
        y,
        rcond=None
    )[0]

    residual = y - x @ beta

    if not np.allclose(
        residual,
        df.Hmean_cover_residual_m.to_numpy(float),
        atol=1e-6,
        rtol=1e-6
    ):

        raise ValueError(
            "Hmean_cover_residual_m与"
            "Cover、Hmean重新计算结果不一致"
        )


    df["name_key"] = (
        df.city_name.map(normalize_city)
    )

    df["highlight"] = ""

    for name in HIGHLIGHTS:

        exact = df.name_key.eq(name)

        if exact.any():
            selected = exact

        else:

            pattern = (
                r"(?<![a-z])"
                + re.escape(name).replace(
                    r"\ ",
                    r"\s*"
                )
                + r"(?![a-z])"
            )

            selected = (
                df.name_key.str.contains(
                    pattern,
                    regex=True,
                    na=False
                )
            )

        if selected.sum() != 1:
            raise ValueError(
                f"无法唯一识别高亮城市：{name}"
            )

        df.loc[
            selected,
            "highlight"
        ] = name

    return df.sort_values(
        "city_id"
    ).reset_index(drop=True)



def draw_figure(df):

    rcParams.update({

        "font.family": "sans-serif",

        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],

        "font.size": 8.5,
        "axes.labelsize": 8.5,

        "xtick.labelsize": 8,
        "ytick.labelsize": 8,

        "axes.linewidth": 0.65,

        "xtick.major.width": 0.65,
        "ytick.major.width": 0.65,

        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",

        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })


    values = (
        df.Hmean_cover_residual_m
        .to_numpy(float)
    )

    limit = float(
        np.max(np.abs(values))
    )

    if limit <= 0:
        raise ValueError(
            "城市高度残差无变化"
        )

    cmap = plt.get_cmap(
        "coolwarm"
    )

    norm = Normalize(
        vmin=-limit,
        vmax=limit
    )


    fig = plt.figure(
        figsize=(
            FIG_WIDTH_MM / 25.4,
            FIG_HEIGHT_MM / 25.4
        )
    )

    ax = fig.add_axes([
        0.17,
        0.17,
        0.64,
        0.76
    ])

    cax = fig.add_axes([
        0.84,
        0.17,
        0.025,
        0.76
    ])


    ax.axhline(
        0,
        color="#ACACAC",
        linestyle=(0, (3, 3)),
        linewidth=0.65,
        zorder=1
    )


    regular = df.loc[
        df.highlight.eq("")
    ]

    ax.scatter(
        regular.Cover,
        regular.Hmean_cover_residual_m,

        s=18,

        c=regular.Hmean_cover_residual_m,

        cmap=cmap,
        norm=norm,

        alpha=0.83,

        edgecolors="none",

        zorder=3
    )


    xmax = max(
        80,
        int(
            np.ceil(
                df.Cover.max() / 10
            ) * 10
        )
    )

    for row in df.loc[
        df.highlight.ne("")
    ].itertuples():

        label, offset = (
            HIGHLIGHTS[row.highlight]
        )

        ha = "left"

        if row.Cover >= 0.75 * xmax:

            offset = (
                -6,
                offset[1]
            )

            ha = "right"

        ax.scatter(
            [row.Cover],
            [row.Hmean_cover_residual_m],

            s=55,

            c=[row.Hmean_cover_residual_m],

            cmap=cmap,
            norm=norm,

            edgecolors="#4A4A4A",
            linewidths=0.7,

            zorder=5
        )

        ax.annotate(
            label,

            xy=(
                row.Cover,
                row.Hmean_cover_residual_m
            ),

            xytext=offset,
            textcoords="offset points",

            ha=ha,
            fontsize=8,

            color="#202426",
            zorder=6
        )


    mappable = ScalarMappable(
        norm=norm,
        cmap=cmap
    )

    colorbar = fig.colorbar(
        mappable,
        cax=cax
    )

    colorbar.set_label(
        "Relative canopy height (m)",
        fontsize=8,
        labelpad=3
    )

    colorbar.ax.tick_params(
        labelsize=7.5,
        width=0.6,
        length=2.5,
        pad=2
    )

    colorbar.outline.set_linewidth(
        0.6
    )


    ax.set_xlabel(
        "Canopy cover (%)",
        labelpad=4
    )

    ax.set_ylabel(
        "Height residual (m)",
        labelpad=4
    )

    ax.set_xlim(
        0,
        xmax
    )

    ylim = (
        max(
            6.0,
            float(np.ceil(limit))
        ) + 0.35
    )

    ax.set_ylim(
        -ylim,
        ylim
    )

    ytick_limit = (
        int(np.floor(ylim / 2)) * 2
    )

    ax.set_yticks(
        np.arange(
            -ytick_limit,
            ytick_limit + 1,
            2
        )
    )

    ax.tick_params(
        axis="both",
        direction="out",
        length=2.8,
        width=0.65,
        pad=2.5
    )

    for spine in ax.spines.values():

        spine.set_visible(True)

        spine.set_linewidth(0.65)

        spine.set_color("#565656")

    ax.grid(False)

    return fig


def main():

    df = load_data()

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    df[
        [
            "city_id",
            "city_name",
            "Cover",
            "Hmean",
            "Hmean_cover_residual_m",
            "n_cover",
            "highlight"
        ]
    ].to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_source_data.csv",

        index=False,

        encoding="utf-8-sig"
    )

    fig = draw_figure(df)

    try:

        for extension in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none",
                "bbox_inches": None
            }

            if extension in (
                "png",
                "tiff"
            ):
                options["dpi"] = DPI

            if extension == "tiff":
                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{extension}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
