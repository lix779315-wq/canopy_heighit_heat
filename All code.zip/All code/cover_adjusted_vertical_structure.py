
# -*- coding: utf-8 -*-


from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.linalg import qr



INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_structure_ses.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\cover_adjusted_height_index"
)



OUTPUT_NAME = "cover_adjusted_height_by_cover_stratum"

N_BOOTSTRAP = 2000
MIN_VALID_BOOTSTRAP = 1600
RANDOM_SEED = 20261023
DPI = 600

METRICS = ("Hmean", "HSD", "HP90")

WEIGHTINGS = (
    "grid_equal",
    "city_equal"
)

STRATA = (
    "0–10%",
    "10–20%",
    "20–30%",
    ">30%"
)

COLORS = {
    "grid_equal": "#2A7F62",
    "city_equal": "#D38D32"
}

# 主坐标框尺寸
AX_W_MM = 80.439
AX_H_MM = 62.226

FIG_W_MM = 110.0
FIG_H_MM = 89.0

AX_LEFT_MM = 23.0
AX_BOTTOM_MM = 17.0


def prepare_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(INPUT_CSV)

    needed = [
        "grid_id",
        "city_id",
        "grdi",
        "population",
        "built_density",
        "built_height",
        "distance_to_center_km",
        "climate",
        "Cover",
        *METRICS
    ]

    df = pd.read_csv(
        INPUT_CSV,
        dtype={
            "grid_id": str,
            "city_id": str
        },
        encoding="utf-8-sig"
    )

    missing = set(needed) - set(df.columns)

    if missing:
        raise ValueError(
            f"缺少字段：{sorted(missing)}"
        )

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError(
            "grid_id/city_id缺失或重复"
        )

    numeric = needed[2:]

    df[numeric] = df[numeric].apply(
        pd.to_numeric,
        errors="coerce"
    )

    if not np.isfinite(
        df[numeric].to_numpy(float)
    ).all():
        raise ValueError(
            "数值字段存在缺失或无效值"
        )

    valid = (
        df.grdi.between(0, 100).all()
        and df.population.ge(0).all()
        and df.built_density.between(0, 1).all()
        and df.built_height.ge(0).all()
        and df.distance_to_center_km.ge(0).all()
        and df.Cover.between(0, 100).all()
        and df.Hmean.gt(2).all()
        and df.HSD.ge(0).all()
        and df.HP90.gt(2).all()
    )

    if not valid:
        raise ValueError(
            "输入变量超出有效范围"
        )

    df = df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)

    # SES与协变量
    df["affluence"] = 100 - df.grdi

    df["log_population"] = np.log1p(
        df.population
    )

    df["log_building_height"] = np.log1p(
        df.built_height
    )


    standardize = {
        "Cover": "Cover_z",
        "Hmean": "Hmean_z",
        "HSD": "HSD_z",
        "HP90": "HP90_z",
        "affluence": "ses_z",
        "log_population": "population_z",
        "built_density": "density_z",
        "log_building_height": "building_z",
        "distance_to_center_km": "distance_z"
    }

    for raw, name in standardize.items():

        group = df.groupby("city_id")[raw]

        mean = group.transform("mean")

        sd = group.transform(
            lambda values: values.std(ddof=0)
        )

        df[name] = (
            (df[raw] - mean)
            / sd.where(sd > 0)
        ).fillna(0.0)


    df["ses_quintile"] = pd.Series(
        pd.NA,
        index=df.index,
        dtype="Int64"
    )

    for _, city in df.groupby(
        "city_id",
        sort=True
    ):

        if (
            len(city) < 5
            or city.affluence.nunique() < 5
        ):
            continue

        groups = pd.qcut(
            city.affluence,
            5,
            labels=False,
            duplicates="drop"
        )

        if groups.nunique() == 5:

            df.loc[
                city.index,
                "ses_quintile"
            ] = (groups + 1).astype("Int64")


    terms = ["Cover_z"]

    knots = np.quantile(
        df.Cover_z,
        (0.25, 0.50, 0.75)
    )

    for label, knot in zip(
        ("25", "50", "75"),
        knots
    ):

        key = f"cover_hinge_{label}"

        df[key] = np.maximum(
            df.Cover_z - knot,
            0
        )

        terms.append(key)

    climate = df.climate.astype(int)

    reference = climate.value_counts().idxmax()

    dummies = pd.get_dummies(
        climate,
        prefix="climate",
        dtype=float
    )

    dummies = dummies.drop(
        columns=f"climate_{reference}"
    )

    df = pd.concat(
        [df, dummies],
        axis=1
    )

    terms += [
        "population_z",
        "density_z",
        "building_z",
        "distance_z",
        *dummies.columns
    ]


    cover = df.Cover.to_numpy(float)

    strata = np.searchsorted(
        [10.0, 20.0, 30.0],
        cover,
        side="right"
    )

    strata[cover == 30.0] = 2

    df["cover_stratum"] = strata

    return df, terms



def prepare_model():

    df, predictors = prepare_data()

    codes, cities = pd.factorize(
        df.city_id,
        sort=True
    )

    g = len(cities)

    if g < 3:
        raise ValueError(
            "至少需要3座城市"
        )

    counts = np.bincount(
        codes,
        minlength=g
    )

    x = df[predictors].to_numpy(float).copy()

    y = df[
        [f"{name}_z" for name in METRICS]
    ].to_numpy(float).copy()

    x -= (
        pd.DataFrame(x)
        .groupby(codes)
        .transform("mean")
        .to_numpy()
    )

    y -= (
        pd.DataFrame(y)
        .groupby(codes)
        .transform("mean")
        .to_numpy()
    )


    _, r, pivots = qr(
        x,
        mode="economic",
        pivoting=True
    )

    diagonal = np.abs(
        np.diag(r)
    )

    tolerance = (
        max(x.shape)
        * np.finfo(float).eps
        * diagonal.max(initial=0)
    )

    rank = int(
        (diagonal > tolerance).sum()
    )

    if rank == 0:
        raise ValueError(
            "调整模型没有可识别自变量"
        )

    selected = np.sort(
        pivots[:rank]
    )

    kept = [
        predictors[j]
        for j in selected
    ]

    if "Cover_z" not in kept:
        raise ValueError(
            "Cover_z无法独立识别"
        )

    x = x[:, selected]

    p = x.shape[1]

    if len(df) - g - p <= 0:
        raise ValueError(
            "模型自由度不足"
        )


    a = np.zeros(
        (g, p, p)
    )

    b = np.zeros(
        (g, p, 3)
    )

    bounds = np.r_[
        0,
        np.cumsum(counts)
    ]

    for k in range(g):

        lo, hi = bounds[k:k + 2]

        xx = x[lo:hi]
        yy = y[lo:hi]

        a[k] = xx.T @ xx
        b[k] = xx.T @ yy

    beta = np.linalg.lstsq(
        a.sum(axis=0),
        b.sum(axis=0),
        rcond=None
    )[0]

    denominator = np.zeros(
        (2, 4, 2, g)
    )

    sum_y = np.zeros(
        (2, 4, 2, g, 3)
    )

    sum_x = np.zeros(
        (2, 4, 2, g, p)
    )

    n_cells = np.zeros(
        (4, 2, g),
        dtype=int
    )

    ses = df.ses_quintile.to_numpy(
        dtype=float,
        na_value=np.nan
    )

    band = df.cover_stratum.to_numpy(
        dtype=int
    )

    for si in range(4):

        for qi, quintile in enumerate(
            (1, 5)
        ):

            mask = (
                (band == si)
                & (ses == quintile)
            )

            ids = codes[mask]

            np.add.at(
                n_cells[si, qi],
                ids,
                1
            )

            for wi, weighting in enumerate(
                WEIGHTINGS
            ):

                if weighting == "grid_equal":

                    weights = np.ones(
                        len(ids)
                    )

                else:

                    weights = (
                        1.0 / counts[ids]
                    )

                np.add.at(
                    denominator[wi, si, qi],
                    ids,
                    weights
                )

                np.add.at(
                    sum_y[wi, si, qi],
                    ids,
                    y[mask] * weights[:, None]
                )

                np.add.at(
                    sum_x[wi, si, qi],
                    ids,
                    x[mask] * weights[:, None]
                )

    if (
        denominator.sum(axis=3) <= 0
    ).any():
        raise ValueError(
            "至少一个Cover区间没有Q1或Q5样本"
        )

    return (
        a,
        b,
        beta,
        denominator,
        sum_y,
        sum_x,
        n_cells
    )



def calculate_contrasts(model):

    (
        a,
        b,
        beta,
        denominator,
        sum_y,
        sum_x,
        n_cells
    ) = model

    g = len(a)


    def contrast(multiplicity, coefficients):

        d = np.einsum(
            "g,wsqg->wsq",
            multiplicity,
            denominator
        )

        sy = np.einsum(
            "g,wsqgm->wsqm",
            multiplicity,
            sum_y
        )

        sx = np.einsum(
            "g,wsqgp->wsqp",
            multiplicity,
            sum_x
        )

        if np.any(d <= 0):
            return None

        adjusted = (
            sy
            - np.einsum(
                "wsqp,pm->wsqm",
                sx,
                coefficients
            )
        ) / d[..., None]

        index = adjusted.mean(axis=-1)

        return (
            index[:, :, 1]
            - index[:, :, 0]
        )


    point = contrast(
        np.ones(g, dtype=int),
        beta
    )


    rng = np.random.default_rng(
        RANDOM_SEED
    )

    draws = np.empty(
        (N_BOOTSTRAP, 2, 4)
    )

    accepted = 0

    for _ in range(N_BOOTSTRAP):

        mult = rng.multinomial(
            g,
            np.full(g, 1.0 / g)
        )

        aa = np.einsum(
            "g,gij->ij",
            mult,
            a
        )

        bb = np.einsum(
            "g,gpm->pm",
            mult,
            b
        )

        if np.linalg.matrix_rank(
            aa
        ) < aa.shape[0]:
            continue

        boot_beta = np.linalg.solve(
            aa,
            bb
        )

        result = contrast(
            mult,
            boot_beta
        )

        if (
            result is not None
            and np.isfinite(result).all()
        ):

            draws[accepted] = result

            accepted += 1

    if accepted < MIN_VALID_BOOTSTRAP:

        raise RuntimeError(
            f"有效Bootstrap次数为"
            f"{accepted}/{N_BOOTSTRAP}，"
            f"少于{MIN_VALID_BOOTSTRAP}"
        )

    draws = draws[:accepted]

    ci = np.quantile(
        draws,
        [0.025, 0.975],
        axis=0
    )


    records = []

    for wi, weighting in enumerate(
        WEIGHTINGS
    ):

        for si, label in enumerate(STRATA):

            records.append({

                "cover_stratum": label,

                "weighting": weighting,

                "q5_minus_q1": float(
                    point[wi, si]
                ),

                "ci95_low": float(
                    ci[0, wi, si]
                ),

                "ci95_high": float(
                    ci[1, wi, si]
                ),

                "n_q1_grids": int(
                    n_cells[si, 0].sum()
                ),

                "n_q5_grids": int(
                    n_cells[si, 1].sum()
                ),

                "n_q1_cities": int(
                    (n_cells[si, 0] > 0).sum()
                ),

                "n_q5_cities": int(
                    (n_cells[si, 1] > 0).sum()
                ),

                "n_valid_bootstrap": accepted
            })

    return pd.DataFrame(records)



def draw_figure(results):

    plt.rcParams.update({

        "font.family": "sans-serif",

        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],

        "font.size": 9,
        "axes.labelsize": 9.5,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,

        "axes.linewidth": 0.75,

        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",

        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })


    fig = plt.figure(
        figsize=(
            FIG_W_MM / 25.4,
            FIG_H_MM / 25.4
        )
    )

    ax = fig.add_axes([
        AX_LEFT_MM / FIG_W_MM,
        AX_BOTTOM_MM / FIG_H_MM,
        AX_W_MM / FIG_W_MM,
        AX_H_MM / FIG_H_MM
    ])


    ax.axhline(
        0,
        color="#B5B5B5",
        linewidth=0.8,
        linestyle=(0, (3, 3)),
        zorder=1
    )

    centers = np.arange(
        4,
        dtype=float
    )


    for weighting, offset, marker, style in (

        (
            "grid_equal",
            -0.065,
            "o",
            "-"
        ),

        (
            "city_equal",
            0.065,
            "s",
            "--"
        )

    ):

        part = (
            results.loc[
                results.weighting.eq(weighting)
            ]
            .set_index("cover_stratum")
            .loc[list(STRATA)]
        )

        x = centers + offset

        y = part.q5_minus_q1.to_numpy(
            float
        )

        low = part.ci95_low.to_numpy(
            float
        )

        high = part.ci95_high.to_numpy(
            float
        )

        color = COLORS[weighting]


        ax.plot(
            x,
            y,

            linestyle=style,

            color=color,

            linewidth=1.25,

            marker=marker,

            markersize=5.5,

            zorder=4,

            label=(
                "Grid-equal"
                if weighting == "grid_equal"
                else "City-equal"
            )
        )


        ax.vlines(
            x,
            low,
            high,

            color=color,

            linewidth=1.0,

            zorder=3
        )

        ax.hlines(
            low,
            x - 0.045,
            x + 0.045,

            color=color,

            linewidth=1.0,

            zorder=3
        )

        ax.hlines(
            high,
            x - 0.045,
            x + 0.045,

            color=color,

            linewidth=1.0,

            zorder=3
        )


    ax.set_xlim(
        -0.38,
        3.38
    )

    low_all = float(
        results.ci95_low.min()
    )

    high_all = float(
        results.ci95_high.max()
    )

    ax.set_ylim(
        min(-0.70, low_all - 0.04),
        max(0.70, high_all + 0.04)
    )

    ax.set_xticks(
        centers,
        STRATA
    )

    ax.set_xlabel(
        "Canopy-cover stratum",
        labelpad=5
    )

    ax.set_ylabel(
        "Q5 − Q1 height index (SD)",
        labelpad=6
    )

    ax.tick_params(
        axis="both",
        direction="out",
        length=3,
        width=0.75,
        pad=3
    )

    for spine in ax.spines.values():

        spine.set_visible(True)

        spine.set_color("#5B5B5B")

        spine.set_linewidth(0.75)


    ax.legend(
        loc="lower left",
        frameon=False,
        fontsize=8.7,
        handlelength=1.7,
        labelspacing=0.25,
        borderaxespad=0.4
    )

    ax.grid(False)

    return fig



def main():

    results = calculate_contrasts(
        prepare_model()
    )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    results.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_source_data.csv",

        index=False,
        encoding="utf-8-sig"
    )

    fig = draw_figure(results)

    try:

        for ext in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none",
                "bbox_inches": None
            }

            if ext in (
                "png",
                "tiff"
            ):
                options["dpi"] = DPI

            if ext == "tiff":
                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{ext}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
