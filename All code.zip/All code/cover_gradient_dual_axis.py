
# -*- coding: utf-8 -*-


from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

import numpy as np
import pandas as pd



INPUT_CSV = Path(
    r"E:\李鑫论文\result summary\canopy_metrics_1m\grid_canopy_metrics_1m.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\results\figures\cover_height_gradient"
)



OUTPUT_NAME = "cover_height_gradient_dual_axis"

WINDOW_WIDTH_PP = 10.0
WINDOW_STEP_PP = 2.0

WINDOW_CENTERS = np.arange(
    5.0,
    95.0 + 1e-8,
    WINDOW_STEP_PP
)

MIN_GRIDS_PER_CITY_WINDOW = 3
MIN_CITIES_PER_WINDOW = 20
EXPECTED_CITIES = 140

DPI = 600



HEIGHT_COLOR = "#8A315C"
HEIGHT_FILL = "#D9B6C6"

HSD_COLOR = "#32756E"
HSD_FILL = "#B8D2CE"

LINE_WIDTH = 1.35



AXES_WIDTH_MM = 69.144
AXES_HEIGHT_MM = 52.211

LEFT_MM = 14.0
RIGHT_MM = 16.0
BOTTOM_MM = 13.0
TOP_MM = 5.0

FIG_WIDTH_MM = (
    LEFT_MM + AXES_WIDTH_MM + RIGHT_MM
)

FIG_HEIGHT_MM = (
    BOTTOM_MM + AXES_HEIGHT_MM + TOP_MM
)



def read_grid_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(
            f"输入文件不存在：{INPUT_CSV}"
        )

    required = [
        "grid_id",
        "city_id",
        "valid_pixels",
        "Cover",
        "Hmean",
        "HSD"
    ]

    df = pd.read_csv(
        INPUT_CSV,
        usecols=lambda name: name in required,
        dtype={
            "grid_id": "string",
            "city_id": "string"
        },
        encoding="utf-8-sig"
    )

    missing = set(required) - set(df.columns)

    if missing:
        raise ValueError(
            f"缺少必要字段：{sorted(missing)}"
        )

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError(
            "grid_id/city_id缺失，或grid_id重复"
        )

    for name in (
        "valid_pixels",
        "Cover",
        "Hmean",
        "HSD"
    ):
        df[name] = pd.to_numeric(
            df[name],
            errors="coerce"
        )


    good = (
        df.valid_pixels.gt(0)
        & df.Cover.between(0, 100)
        & df.Hmean.gt(2)
        & df.HSD.ge(0)
        & np.isfinite(
            df[["Cover", "Hmean", "HSD"]]
            .to_numpy(float)
        ).all(axis=1)
    )

    df = df.loc[
        good,
        ["grid_id", "city_id", "Cover", "Hmean", "HSD"]
    ].copy()

    if df.empty:
        raise ValueError(
            "没有可用的Cover/Hmean/HSD网格"
        )

    n_cities = df.city_id.nunique()

    if n_cities != EXPECTED_CITIES:
        raise ValueError(
            f"有效城市数为{n_cities}，"
            f"预期{EXPECTED_CITIES}"
        )

    return df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)



def weighted_quantiles(
    values,
    weights,
    quantiles
):

    values = np.asarray(
        values,
        dtype=float
    )

    weights = np.asarray(
        weights,
        dtype=float
    )

    quantiles = np.asarray(
        quantiles,
        dtype=float
    )

    valid = (
        np.isfinite(values)
        & np.isfinite(weights)
        & (weights > 0)
    )

    values = values[valid]
    weights = weights[valid]

    if not len(values):
        return np.full(
            quantiles.shape,
            np.nan
        )


    order = np.argsort(
        values,
        kind="stable"
    )

    values = values[order]
    weights = weights[order]

    positions = (
        np.cumsum(weights)
        - 0.5 * weights
    ) / weights.sum()

    return np.interp(
        quantiles,
        positions,
        values
    )



def calculate_windows(df):

    summaries = []
    city_windows = []

    half = WINDOW_WIDTH_PP / 2.0

    for center in WINDOW_CENTERS:

        lo = float(center - half)
        hi = float(center + half)


        mask = (
            df.Cover.ge(lo)
            &
            (
                df.Cover.le(hi)
                if hi >= 100
                else df.Cover.lt(hi)
            )
        )

        sub = df.loc[
            mask
        ].copy()

        if sub.empty:
            continue


        counts = (
            sub.groupby("city_id").size()
        )

        eligible = counts[
            counts >= MIN_GRIDS_PER_CITY_WINDOW
        ]

        if len(eligible) < MIN_CITIES_PER_WINDOW:
            continue

        sub = sub.loc[
            sub.city_id.isin(eligible.index)
        ].copy()


        sub["n_grid_city_window"] = (
            sub.city_id.map(eligible)
        )

        sub["city_equal_weight"] = (
            1.0 / sub.n_grid_city_window
        )


        per_city = (
            sub.groupby("city_id", sort=True)
            .agg(
                n_grids=("grid_id", "size"),
                Cover_median=("Cover", "median"),
                Hmean_median=("Hmean", "median"),
                HSD_median=("HSD", "median")
            )
            .reset_index()
        )

        per_city["window_center"] = center
        per_city["window_lower"] = lo
        per_city["window_upper"] = hi

        city_windows.append(per_city)


        for metric, field in (
            ("Mean canopy height", "Hmean"),
            ("Height variability", "HSD")
        ):

            p10, q1, median, q3, p90 = (
                weighted_quantiles(
                    sub[field],
                    sub.city_equal_weight,
                    (
                        0.10,
                        0.25,
                        0.50,
                        0.75,
                        0.90
                    )
                )
            )

            summaries.append({
                "metric": metric,
                "field": field,
                "window_center": center,
                "window_lower": lo,
                "window_upper": hi,
                "n_cities": len(eligible),
                "n_grids": len(sub),
                "p10": p10,
                "q1": q1,
                "median": median,
                "q3": q3,
                "p90": p90
            })

    if not summaries:
        raise ValueError(
            "没有窗口同时满足每城市至少3个网格"
            "和至少20座城市"
        )

    summary = pd.DataFrame(
        summaries
    )

    city_windows = pd.concat(
        city_windows,
        ignore_index=True
    )

    return summary, city_windows



def draw_figure(summary):

    plt.rcParams.update({

        "font.family": "sans-serif",

        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],

        "font.size": 9.0,
        "axes.labelsize": 9.0,

        "xtick.labelsize": 8.5,
        "ytick.labelsize": 8.5,

        "axes.linewidth": 0.65,

        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",

        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })


    fig = plt.figure(
        figsize=(
            FIG_WIDTH_MM / 25.4,
            FIG_HEIGHT_MM / 25.4
        )
    )

    ax = fig.add_axes([
        LEFT_MM / FIG_WIDTH_MM,
        BOTTOM_MM / FIG_HEIGHT_MM,
        AXES_WIDTH_MM / FIG_WIDTH_MM,
        AXES_HEIGHT_MM / FIG_HEIGHT_MM
    ])

    ax_right = ax.twinx()


    styles = (

        (
            "Mean canopy height",
            ax,
            HEIGHT_COLOR,
            HEIGHT_FILL,
            "-",
            0.25
        ),

        (
            "Height variability",
            ax_right,
            HSD_COLOR,
            HSD_FILL,
            (0, (4, 2)),
            0.16
        )

    )

    for (
        metric,
        axis,
        color,
        shade,
        linestyle,
        alpha
    ) in styles:

        part = summary.loc[
            summary.metric.eq(metric)
        ].sort_values(
            "window_center"
        )

        x = part.window_center.to_numpy(float)
        q1 = part.q1.to_numpy(float)
        median = part["median"].to_numpy(float)
        q3 = part.q3.to_numpy(float)


        axis.fill_between(
            x,
            q1,
            q3,

            color=shade,
            alpha=alpha,

            linewidth=0,
            zorder=1
        )


        axis.plot(
            x,
            median,

            color=color,

            linewidth=LINE_WIDTH,
            linestyle=linestyle,

            solid_capstyle="round",

            zorder=3
        )


        span = max(
            float(q3.max() - q1.min()),
            1.0
        )

        axis.set_ylim(
            max(
                0.0,
                float(q1.min()) - 0.25 * span
            ),
            float(q3.max()) + 0.25 * span
        )

        axis.grid(False)


    ax.set_xlim(
        5,
        95
    )

    ax.set_xticks(
        [5, 20, 40, 60, 80, 95]
    )

    ax.set_xlabel(
        "Canopy cover (%)",
        labelpad=4
    )



    ax.set_ylabel(
        "Mean canopy height (m)",
        color=HEIGHT_COLOR,
        labelpad=5
    )

    ax_right.set_ylabel(
        "Height variability (m)",
        color=HSD_COLOR,
        labelpad=5
    )


    for side in (
        "left",
        "bottom",
        "top"
    ):

        ax.spines[side].set_visible(True)
        ax.spines[side].set_color("#505050")
        ax.spines[side].set_linewidth(0.65)

        ax_right.spines[side].set_visible(False)

    ax.spines["right"].set_visible(False)

    ax_right.spines["right"].set_visible(True)
    ax_right.spines["right"].set_color("#505050")
    ax_right.spines["right"].set_linewidth(0.65)


    for axis in (ax, ax_right):

        axis.tick_params(
            direction="out",

            width=0.65,
            length=2.5,

            labelsize=8.5,

            colors="#303436",
            pad=2
        )


    handles = [

        Line2D(
            [], [],

            color=HEIGHT_COLOR,
            linewidth=LINE_WIDTH,

            linestyle="-",

            label="Mean height"
        ),

        Line2D(
            [], [],

            color=HSD_COLOR,
            linewidth=LINE_WIDTH,

            linestyle=(0, (4, 2)),

            label="Height variability"
        )

    ]

    ax.legend(
        handles=handles,

        loc="upper left",
        bbox_to_anchor=(0.02, 0.98),

        frameon=False,

        fontsize=8.3,

        handlelength=1.8,
        handletextpad=0.45,

        borderaxespad=0,
        labelspacing=0.25
    )

    return fig



def main():

    df = read_grid_data()

    summary, per_city = calculate_windows(df)

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )


    summary.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_summary.csv",

        index=False,
        encoding="utf-8-sig"
    )


    per_city.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_city_windows.csv",

        index=False,
        encoding="utf-8-sig"
    )


    fig = draw_figure(summary)

    try:

        for extension in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none",
                "bbox_inches": None
            }

            if extension in ("png", "tiff"):
                options["dpi"] = DPI

            if extension == "tiff":

                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{extension}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
