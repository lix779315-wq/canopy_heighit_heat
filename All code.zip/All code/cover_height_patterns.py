
# -*- coding: utf-8 -*-

from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D

import numpy as np
import pandas as pd



INPUT_CSV = Path(
    r"E:\李鑫论文\result summary\high_heat_screening_submission"
    r"\city_screening_population_summary.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\high_heat_screening_submission"
)



OUTPUT_NAME = "global_cover_only_omission_map"

DPI = 600
FIGSIZE_INCH = (7.2, 4.65)

SIZE_LEVELS = (
    25_000,
    50_000,
    100_000,
    250_000,
    500_000
)

COLOR_MIN = 0.0
COLOR_MAX = 75.0

COLOR_NODES = (
    "#1F5EFF",
    "#14A8E0",
    "#16B57A",
    "#6BCB3D",
    "#D7D83A",
    "#F4B328",
    "#F17C2F",
    "#D94841"
)

COUNTRY_FILL = "#F7F7F5"
COUNTRY_EDGE = "#BFC3C7"



def population_to_area(population):

    return (
        12.0
        + 280.0 * np.sqrt(
            np.maximum(population, 0)
            / 1_000_000.0
        )
    )



def load_city_summary():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(
            f"找不到09城市统计表：{INPUT_CSV}"
        )

    city = pd.read_csv(
        INPUT_CSV,
        dtype={"city_id": "string"},
        encoding="utf-8-sig"
    )

    required = {
        "city_id",
        "newly_identified_population",
        "high_heat_population"
    }

    missing = required - set(city.columns)

    if missing:
        raise ValueError(
            f"09统计表缺少字段：{sorted(missing)}"
        )

    city["city_id"] = city["city_id"].str.strip()

    if (
        city.city_id.isna().any()
        or city.city_id.eq("").any()
        or city.city_id.duplicated().any()
    ):
        raise ValueError(
            "city_id缺失、为空或重复"
        )

    columns = [
        "newly_identified_population",
        "high_heat_population"
    ]

    city[columns] = city[columns].apply(
        pd.to_numeric,
        errors="coerce"
    )

    if not np.isfinite(
        city[columns].to_numpy(float)
    ).all():
        raise ValueError(
            "人口统计存在缺失或无效数值"
        )

    missed = (
        city.newly_identified_population
        .to_numpy(float)
    )

    high = (
        city.high_heat_population
        .to_numpy(float)
    )

    if (
        np.any(missed < 0)
        or np.any(high < 0)
        or np.any(missed > high + 1e-6)
    ):
        raise ValueError(
            "遗漏人口必须介于0与全部高热人口之间"
        )

    if high.sum() <= 0:
        raise ValueError(
            "全部高热人口为0"
        )

    city["omission_rate_pct"] = np.divide(
        100.0 * missed,
        high,
        out=np.zeros_like(missed),
        where=high > 0
    )

    return city



def add_city_locations(city):

    if {"longitude", "latitude"}.issubset(
        city.columns
    ):

        mapped = city.copy()

    else:

        project_root = INPUT_CSV.parent.parent.parent

        city_shp = (
            project_root
            / "All Cities"
            / "AllCities_with_city_id.shp"
        )

        if not city_shp.is_file():
            raise FileNotFoundError(
                "09汇总表没有经纬度，"
                "且找不到01的城市边界：\n"
                f"{city_shp}\n"
                "请先运行01，或在CSV中添加"
                "真实的longitude和latitude字段。"
            )

        import geopandas as gpd

        boundaries = gpd.read_file(city_shp)

        if not {
            "city_id",
            "geometry"
        }.issubset(boundaries.columns):
            raise ValueError(
                "城市边界缺少city_id或geometry"
            )

        if boundaries.crs is None:
            raise ValueError(
                "城市边界缺少坐标参考系"
            )

        boundaries = boundaries.copy()

        boundaries["city_id"] = (
            boundaries["city_id"]
            .astype("string")
            .str.strip()
        )

        if (
            boundaries.city_id.isna().any()
            or boundaries.city_id.duplicated().any()
        ):
            raise ValueError(
                "01城市边界的city_id缺失或重复"
            )

        if (
            boundaries.geometry.isna().any()
            or boundaries.geometry.is_empty.any()
        ):
            raise ValueError(
                "城市边界存在空几何"
            )

        projected = boundaries.to_crs(
            "EPSG:6933"
        )

        centres = gpd.GeoSeries(
            projected.geometry.centroid,
            crs=projected.crs
        )

        wgs84 = centres.to_crs(
            "EPSG:4326"
        )

        locations = pd.DataFrame({
            "city_id": boundaries.city_id.to_numpy(),
            "longitude": wgs84.x.to_numpy(),
            "latitude": wgs84.y.to_numpy()
        })

        if "city_name" in boundaries.columns:
            locations["city_name"] = (
                boundaries.city_name.to_numpy()
            )

        mapped = city.merge(
            locations,
            on="city_id",
            how="left",
            validate="one_to_one"
        )

    coordinates = [
        "longitude",
        "latitude"
    ]

    mapped[coordinates] = (
        mapped[coordinates]
        .apply(pd.to_numeric, errors="coerce")
    )

    if not np.isfinite(
        mapped[coordinates].to_numpy(float)
    ).all():
        raise ValueError(
            "部分城市未能匹配真实经纬度"
        )

    if not mapped.longitude.between(
        -180, 180
    ).all():
        raise ValueError(
            "城市经度超出有效范围"
        )

    if not mapped.latitude.between(
        -90, 90
    ).all():
        raise ValueError(
            "城市纬度超出有效范围"
        )

    if not mapped.latitude.between(
        -60, 85
    ).all():
        raise ValueError(
            "部分城市超出当前地图纬度显示范围"
        )

    return mapped.sort_values(
        [
            "newly_identified_population",
            "city_id"
        ]
    ).reset_index(drop=True)



def draw_world(ax):

    project_root = INPUT_CSV.parent.parent.parent

    candidates = (
        project_root
        / "All Cities"
        / "10m_cultural"
        / "10m_cultural"
        / "ne_10m_admin_0_countries.shp",

        project_root
        / "All Cities"
        / "10m_cultural"
        / "ne_10m_admin_0_countries.shp",

        project_root
        / "results"
        / "figures"
        / "figures 1 0729"
        / "figure 4"
        / "ne_110m_admin_0_countries.geojson"
    )

    for candidate in candidates:

        if not candidate.is_file():
            continue

        import geopandas as gpd

        countries = gpd.read_file(candidate)

        if countries.crs is None:
            raise ValueError(
                f"世界国界缺少坐标系：{candidate}"
            )

        countries = countries.to_crs(
            "EPSG:4326"
        )

        countries["geometry"] = (
            countries.geometry.simplify(
                0.18,
                preserve_topology=True
            )
        )

        countries.plot(
            ax=ax,
            color=COUNTRY_FILL,
            edgecolor=COUNTRY_EDGE,
            linewidth=0.45,
            zorder=1
        )

        ax.set_aspect("auto")
        return

    try:
        from mpl_toolkits.basemap import Basemap

    except ImportError as exc:
        raise FileNotFoundError(
            "未找到Natural Earth世界国界，"
            "且未安装Basemap。"
        ) from exc

    world = Basemap(
        projection="cyl",
        resolution="c",
        ax=ax,
        llcrnrlon=-180,
        urcrnrlon=180,
        llcrnrlat=-60,
        urcrnrlat=85
    )

    world.fillcontinents(
        color=COUNTRY_FILL,
        lake_color="white",
        zorder=1
    )

    world.drawcoastlines(
        color=COUNTRY_EDGE,
        linewidth=0.45,
        zorder=2
    )

    world.drawcountries(
        color=COUNTRY_EDGE,
        linewidth=0.45,
        zorder=2
    )



def draw_figure(city):

    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],
        "font.size": 8.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })

    fig = plt.figure(
        figsize=FIGSIZE_INCH,
        facecolor="white"
    )

    ax = fig.add_axes([
        0.04,
        0.08,
        0.92,
        0.84
    ])

    draw_world(ax)

    ax.set_xlim(-180, 180)
    ax.set_ylim(-60, 85)
    ax.set_aspect("auto")
    ax.set_axis_off()

    cmap = LinearSegmentedColormap.from_list(
        "omission",
        COLOR_NODES,
        N=256
    )

    norm = Normalize(
        vmin=COLOR_MIN,
        vmax=COLOR_MAX,
        clip=True
    )


    scatter = ax.scatter(
        city.longitude,
        city.latitude,
        s=population_to_area(
            city.newly_identified_population
            .to_numpy(float)
        ),
        c=city.omission_rate_pct,
        cmap=cmap,
        norm=norm,
        edgecolors="#9A9A9A",
        linewidths=0.35,
        alpha=0.96,
        zorder=4
    )


    handles = [
        Line2D(
            [], [],
            marker="o",
            linestyle="none",
            markerfacecolor="white",
            markeredgecolor="#A0A0A0",
            markeredgewidth=0.6,
            markersize=np.sqrt(
                population_to_area(value)
            ),
            label=f"{value:,}"
        )
        for value in SIZE_LEVELS
    ]

    ax.legend(
        handles=handles,
        title="Overlooked\npopulation",
        loc="lower left",
        bbox_to_anchor=(0.00, 0.13),
        frameon=False,
        fontsize=7.3,
        title_fontsize=7.6,
        ncol=1,
        handlelength=1.7,
        handletextpad=0.85,
        labelspacing=0.75,
        borderaxespad=0
    )


    cax = fig.add_axes([
        0.49,
        0.145,
        0.245,
        0.017
    ])

    bar = fig.colorbar(
        scatter,
        cax=cax,
        orientation="horizontal",
        ticks=(0, 25, 50, 75)
    )

    bar.set_label(
        "Omission rate (%)",
        fontsize=7.8,
        labelpad=2
    )

    bar.ax.tick_params(
        axis="x",
        labelsize=7,
        length=2.5,
        width=0.6,
        pad=2
    )

    bar.outline.set_edgecolor("#777C82")
    bar.outline.set_linewidth(0.5)

    return fig


def main():

    city = add_city_locations(
        load_city_summary()
    )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )


    city.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_source_data.csv",
        index=False,
        encoding="utf-8-sig"
    )


    summary = pd.DataFrame([{
        "n_cities": len(city),

        "cities_with_newly_identified": int(
            city.newly_identified_population.gt(0).sum()
        ),

        "newly_identified_population": float(
            city.newly_identified_population.sum()
        ),

        "high_heat_population": float(
            city.high_heat_population.sum()
        ),

        "global_omission_rate_pct": float(
            100
            * city.newly_identified_population.sum()
            / city.high_heat_population.sum()
        ),

        "maximum_city_omission_rate_pct": float(
            city.omission_rate_pct.max()
        )
    }])

    summary.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_summary.csv",
        index=False,
        encoding="utf-8-sig"
    )


    fig = draw_figure(city)

    try:

        for ext in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none",
                "bbox_inches": None
            }

            if ext in ("png", "tiff"):
                options["dpi"] = DPI

            if ext == "tiff":
                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{ext}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
