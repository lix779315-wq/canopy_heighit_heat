
# -*- coding: utf-8 -*-


from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from scipy.interpolate import PchipInterpolator
from scipy.ndimage import gaussian_filter1d



INPUT_CSV = Path(
    r"E:\李鑫论文\result summary\high_heat_screening_submission"
    r"\grid_screening_details.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\high_heat_screening_submission"
)



OUTPUT_NAME = "cover_percentile_population_curves"

DPI = 600

BIN_WIDTH_PP = 5.0
SMOOTH_SIGMA_BINS = 1.0

EDGES = np.arange(
    0.0,
    100.0 + BIN_WIDTH_PP,
    BIN_WIDTH_PP
)

CENTERS = (
    EDGES[:-1] + EDGES[1:]
) / 2.0

X_SMOOTH = np.linspace(
    0.0,
    100.0,
    501
)

GROUPS = (
    (
        "all_high_heat",
        "high_heat",
        "All high-heat population",
        "#0065B3",
        "#D7E8ED"
    ),
    (
        "newly_identified",
        "newly_identified",
        "Newly identified population",
        "#D96A2B",
        "#F2E0CF"
    )
)

FIG_W_IN = 7.205
FIG_H_IN = 4.055



def parse_flag(series, field):

    result = (
        series.astype("string")
        .str.strip()
        .str.lower()
        .map({
            "true": True,
            "false": False,
            "1": True,
            "0": False,
            "1.0": True,
            "0.0": False
        })
    )

    if result.isna().any():
        raise ValueError(
            f"{field}存在无法识别的布尔值"
        )

    return result.to_numpy(
        dtype=bool
    )



def read_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(
            f"找不到09模块逐网格结果：{INPUT_CSV}"
        )

    required = {
        "high_heat",
        "newly_identified",
        "population",
        "Cover_city_percentile"
    }

    df = pd.read_csv(
        INPUT_CSV,
        usecols=lambda column: column in required,
        encoding="utf-8-sig"
    )

    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            f"输入CSV缺少字段：{sorted(missing)}"
        )


    for field in (
        "high_heat",
        "newly_identified"
    ):

        df[field] = parse_flag(
            df[field],
            field
        )


    for field in (
        "population",
        "Cover_city_percentile"
    ):

        df[field] = pd.to_numeric(
            df[field],
            errors="coerce"
        )

    numeric = df[
        [
            "population",
            "Cover_city_percentile"
        ]
    ].to_numpy(float)

    if not np.isfinite(numeric).all():
        raise ValueError(
            "人口或Cover百分位存在无效值"
        )

    if (
        df.population.lt(0).any()
        or not df.Cover_city_percentile
        .between(0, 100).all()
    ):
        raise ValueError(
            "人口不能为负，Cover百分位必须在0–100之间"
        )

    if (
        df.newly_identified
        & ~df.high_heat
    ).any():
        raise ValueError(
            "新增识别网格必须属于高热网格"
        )

    for flag in (
        "high_heat",
        "newly_identified"
    ):

        population = df.loc[
            df[flag],
            "population"
        ].sum()

        if population <= 0:
            raise ValueError(
                f"{flag}对应人口总数为0"
            )

    return df


def weighted_median(values, weights):

    positive = weights > 0

    values = values[positive]
    weights = weights[positive]

    order = np.argsort(
        values,
        kind="stable"
    )

    sorted_values = values[order]

    cumulative = np.cumsum(
        weights[order]
    )

    index = np.searchsorted(
        cumulative,
        0.5 * cumulative[-1],
        side="left"
    )

    return float(
        sorted_values[
            min(index, len(sorted_values) - 1)
        ]
    )



def calculate_curves(df):

    records = []


    new = df.loc[
        df.newly_identified
    ]

    median_new = weighted_median(
        new.Cover_city_percentile.to_numpy(float),
        new.population.to_numpy(float)
    )

    for (
        group_id,
        flag,
        label,
        _,
        _
    ) in GROUPS:

        selected = df.loc[
            df[flag]
        ]

        values = (
            selected.Cover_city_percentile
            .to_numpy(float)
        )

        weights = (
            selected.population
            .to_numpy(float)
        )

        total = float(
            weights.sum()
        )


        bin_population, _ = np.histogram(
            values,
            bins=EDGES,
            weights=weights
        )

        bin_shares = (
            bin_population
            / total
            * 100.0
        )


        smoothed_bins = gaussian_filter1d(
            bin_shares,
            sigma=SMOOTH_SIGMA_BINS,
            mode="reflect"
        )


        support_x = np.r_[
            0.0,
            CENTERS,
            100.0
        ]

        support_y = np.r_[
            smoothed_bins[0],
            smoothed_bins,
            smoothed_bins[-1]
        ]

        smooth_y = PchipInterpolator(
            support_x,
            support_y
        )(X_SMOOTH)

        smooth_y = np.maximum(
            smooth_y,
            0.0
        )

        area = float(
            np.trapezoid(
                smooth_y,
                X_SMOOTH
            )
        )

        if area <= 0:
            raise ValueError(
                f"{group_id}平滑曲线面积无效"
            )

        smooth_y *= (
            100.0 * BIN_WIDTH_PP / area
        )


        indices = np.minimum(
            np.searchsorted(
                EDGES,
                X_SMOOTH,
                side="right"
            ) - 1,
            len(bin_shares) - 1
        )

        for x, y, index in zip(
            X_SMOOTH,
            smooth_y,
            indices
        ):

            records.append({
                "group_id": group_id,
                "group_label": label,

                "cover_percentile": float(x),

                "smoothed_population_share_percent": float(y),

                "bin_lower_percentile": float(
                    EDGES[index]
                ),

                "bin_upper_percentile": float(
                    EDGES[index + 1]
                ),

                "unsmoothed_bin_share_percent": float(
                    bin_shares[index]
                ),

                "group_population": total,

                "newly_identified_weighted_median_percentile": median_new
            })

    return (
        pd.DataFrame(records),
        median_new
    )



def draw_figure(curves, median_new):

    plt.rcParams.update({
        "font.family": "sans-serif",

        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],

        "font.size": 8.5,
        "axes.labelsize": 9,

        "axes.linewidth": 0.7,
        "axes.edgecolor": "#60656B",

        "xtick.labelsize": 8,
        "ytick.labelsize": 8,

        "legend.frameon": False,

        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,

        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })


    fig = plt.figure(
        figsize=(
            FIG_W_IN,
            FIG_H_IN
        ),
        facecolor="white"
    )

    ax = fig.add_axes([
        0.095,
        0.16,
        0.880,
        0.815
    ])

    max_share = float(
        curves.smoothed_population_share_percent.max()
    )

    ymax = max(
        15.5,
        float(
            np.ceil(
                max_share * 1.12 * 2
            ) / 2
        )
    )


    for (
        group_id,
        _,
        label,
        line_color,
        fill_color
    ) in GROUPS:

        group = curves.loc[
            curves.group_id.eq(group_id)
        ]

        x = (
            group.cover_percentile
            .to_numpy(float)
        )

        y = (
            group.smoothed_population_share_percent
            .to_numpy(float)
        )

        ax.fill_between(
            x,
            0,
            y,
            color=fill_color,
            alpha=0.40,
            linewidth=0,
            zorder=1
        )

        ax.plot(
            x,
            y,
            color=line_color,
            linewidth=1.15,
            label=label,
            zorder=3
        )


    ax.axvline(
        50,
        color="#C4CAD0",
        linewidth=0.8,
        linestyle=(0, (2, 3)),
        zorder=2
    )


    ax.axvline(
        median_new,
        color="#D96A2B",
        linewidth=0.9,
        zorder=2
    )


    ax.text(
        51,
        ymax * 0.87,
        "City median",
        color="#66707D",
        fontsize=8,
        ha="left",
        va="center"
    )

    if median_new < 95:

        ax.text(
            median_new + 1.2,
            ymax * 0.94,
            f"Median P{median_new:.1f}",
            color="#D96A2B",
            fontsize=8.5,
            fontweight="bold",
            ha="left",
            va="top"
        )

    else:

        ax.text(
            median_new - 1.2,
            ymax * 0.94,
            f"Median P{median_new:.1f}",
            color="#D96A2B",
            fontsize=8.5,
            fontweight="bold",
            ha="right",
            va="top"
        )


    ax.legend(
        loc="upper left",
        fontsize=8.5,
        handlelength=1.5,
        handletextpad=0.45,
        labelspacing=0.15,
        borderaxespad=0.5
    )


    ax.set_xlim(
        0,
        100
    )

    ax.set_ylim(
        0,
        ymax
    )

    ax.set_xticks([
        0,
        25,
        50,
        75,
        100
    ])

    ax.set_yticks(
        np.arange(
            0,
            ymax + 0.01,
            5
        )
    )

    ax.set_xlabel(
        "Canopy-cover percentile"
    )

    ax.set_ylabel(
        "Population share (%)"
    )

    ax.tick_params(
        direction="out",
        width=0.7,
        length=2.5,
        pad=2
    )

    ax.grid(False)

    return fig



def main():

    df = read_data()

    curves, median_new = calculate_curves(
        df
    )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )


    curves.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_source_data.csv",
        index=False,
        encoding="utf-8-sig"
    )


    fig = draw_figure(
        curves,
        median_new
    )

    try:

        for extension in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none"
            }

            if extension in (
                "png",
                "tiff"
            ):
                options["dpi"] = DPI

            if extension == "tiff":
                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{extension}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
9