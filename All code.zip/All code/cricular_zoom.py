
# -*- coding: utf-8 -*-


from pathlib import Path
import re
import unicodedata

import geopandas as gpd
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import to_hex, to_rgb


ROOT = Path(r"E:\李鑫论文")
GRID_SHP = ROOT / "All Cities" / "AllCities_1km_grid_cityid.shp"
METRICS_CSV = (
    ROOT / "result summary" / "canopy_metrics_1m" / "grid_canopy_metrics_1m.csv"
)
OUTPUT_DIR = ROOT / "results" / "figures" / "Fig1" / "buchongtu"

CITIES = ("London", "Seattle", "Melbourne")
MAP_CRS = "EPSG:6933"
FIGSIZE = (7, 5)
DPI = 600

COVER_THRESHOLDS = (5.0, 20.0)
HEIGHT_THRESHOLDS = (7.0, 11.0)

LOW_LOW = "#F2F2EE"
HIGH_COVER_LOW_HEIGHT = "#4E8BA5"
LOW_COVER_HIGH_HEIGHT = "#CFA24A"
HIGH_HIGH = "#B44F48"
NO_DATA = "#E5E5E5"


ZERO_COVER_COLOR = LOW_LOW


def bivariate_palette():
    corners = [
        np.asarray(to_rgb(c))
        for c in (
            LOW_LOW, HIGH_COVER_LOW_HEIGHT,
            LOW_COVER_HIGH_HEIGHT, HIGH_HIGH
        )
    ]
    c00, c10, c01, c11 = corners
    palette = np.empty((3, 3), dtype=object)
    for row, y in enumerate(np.linspace(0, 1, 3)):
        for col, x in enumerate(np.linspace(0, 1, 3)):
            rgb = (
                (1 - x) * (1 - y) * c00
                + x * (1 - y) * c10
                + (1 - x) * y * c01
                + x * y * c11
            )
            palette[row, col] = to_hex(rgb)
    return palette


PALETTE = bivariate_palette()


def normalize_name(value):
    text = unicodedata.normalize("NFKD", str(value))
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"\s+", " ", text.casefold().strip())


def resolve_cities(grid):
    """从01的city_name找到目标城市，之后一律通过city_id筛选。"""
    names = grid[["city_id", "city_name"]].drop_duplicates()
    if names.groupby("city_id")["city_name"].nunique().gt(1).any():
        raise ValueError("同一个city_id对应多个城市名称")

    names["key"] = names["city_name"].map(normalize_name)
    city_ids = {}
    for city in CITIES:
        key = normalize_name(city)
        exact = names["key"].eq(key)
        candidates = exact if exact.any() else names["key"].str.contains(
            rf"(?<![a-z]){re.escape(key)}(?![a-z])", regex=True, na=False
        )
        matched = names.loc[candidates, "city_id"]
        if len(matched) != 1:
            raise ValueError(
                f"{city}城市匹配到{len(matched)}条记录，请检查01的city_name："
                f"{names.loc[candidates, 'city_name'].tolist()}"
            )
        city_ids[city] = matched.iloc[0]
    if len(set(city_ids.values())) != len(CITIES):
        raise ValueError("目标城市对应的city_id不唯一")
    return city_ids


def load_grids_and_metrics():
    if not GRID_SHP.is_file():
        raise FileNotFoundError(GRID_SHP)
    if not METRICS_CSV.is_file():
        raise FileNotFoundError(METRICS_CSV)

    grid = gpd.read_file(GRID_SHP)
    required = {"grid_id", "city_id", "city_name", "geometry"}
    if not required.issubset(grid.columns):
        raise ValueError(f"01网格文件缺少字段：{sorted(required - set(grid.columns))}")
    if grid.crs is None:
        raise ValueError("01网格文件没有坐标参考系")
    grid = grid[["grid_id", "city_id", "city_name", "geometry"]].copy()
    for field in ("grid_id", "city_id", "city_name"):
        grid[field] = grid[field].astype("string").str.strip()
    if grid[["grid_id", "city_id", "city_name"]].isna().any().any():
        raise ValueError("01网格ID或城市名称缺失")
    if grid["grid_id"].duplicated().any():
        raise ValueError("01网格grid_id重复")

    city_ids = resolve_cities(grid)
    grid = grid.loc[grid["city_id"].isin(city_ids.values())].copy()
    if grid.geometry.isna().any() or grid.geometry.is_empty.any():
        raise ValueError("选定城市包含空网格几何")

    metrics = pd.read_csv(
        METRICS_CSV,
        usecols=["grid_id", "city_id", "valid_pixels", "Cover", "Hmean"],
        dtype={"grid_id": "string", "city_id": "string"},
        encoding="utf-8-sig"
    )
    if metrics["grid_id"].duplicated().any():
        raise ValueError("02树冠指标文件grid_id重复")
    metrics = metrics.loc[metrics["grid_id"].isin(grid["grid_id"])].copy()

    merged = grid.merge(
        metrics, on="grid_id", how="left", validate="one_to_one",
        suffixes=("", "_metric"), indicator=True
    )
    if not merged["_merge"].eq("both").all():
        raise ValueError("02指标表缺少部分选定城市的网格，请先检查02输出")
    if not merged["city_id"].eq(merged["city_id_metric"]).all():
        raise ValueError("01与02的city_id不一致")
    merged = merged.drop(columns=["city_id_metric", "_merge"])

    for field in ("valid_pixels", "Cover", "Hmean"):
        merged[field] = pd.to_numeric(merged[field], errors="coerce")

    if (merged["valid_pixels"].dropna() < 0).any():
        raise ValueError("valid_pixels不能为负数")
    if (~merged.loc[merged["valid_pixels"].gt(0), "Cover"].between(0, 100)).any():
        raise ValueError("有效网格Cover必须为0–100%")

    return merged.to_crs(MAP_CRS), city_ids


def colorize(gdf):
    """仅对有效网格分级；无数据与Cover=0网格显式处理。"""
    cover = gdf["Cover"].to_numpy(float)
    height = gdf["Hmean"].to_numpy(float)
    valid_pixels = gdf["valid_pixels"].to_numpy(float)

    colors = np.full(len(gdf), NO_DATA, dtype=object)
    valid_cover = np.isfinite(valid_pixels) & (valid_pixels > 0) & np.isfinite(cover)
    zero_canopy = valid_cover & (cover == 0)
    colors[zero_canopy] = ZERO_COVER_COLOR

    valid_height = valid_cover & (cover > 0) & np.isfinite(height) & (height > 2)
    cover_classes = np.searchsorted(COVER_THRESHOLDS, cover[valid_height], side="right")
    height_classes = np.searchsorted(HEIGHT_THRESHOLDS, height[valid_height], side="right")
    colors[valid_height] = PALETTE[height_classes, cover_classes]

    result = gdf.copy()
    result["plot_color"] = colors
    return result


def plot_city(gdf, city):
    fig, ax = plt.subplots(figsize=FIGSIZE, dpi=DPI)
    gdf.plot(
        ax=ax, color=gdf["plot_color"].tolist(),
        edgecolor="white", linewidth=0.05,
        rasterized=False
    )
    ax.set_aspect("equal")
    ax.set_axis_off()
    fig.tight_layout(pad=0)

    base = OUTPUT_DIR / f"{city}_canopy_bivariate"
    try:
        for ext in ("pdf", "svg", "png"):
            kwargs = {"facecolor": "white", "bbox_inches": "tight", "pad_inches": 0.02}
            if ext == "png":
                kwargs["dpi"] = DPI
            fig.savefig(base.with_suffix(f".{ext}"), **kwargs)
    finally:
        plt.close(fig)


def main():
    mapped, city_ids = load_grids_and_metrics()
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    for city, city_id in city_ids.items():
        city_grids = mapped.loc[mapped["city_id"].eq(city_id)].copy()
        if city_grids.empty:
            raise ValueError(f"{city}没有可绘制网格")
        plot_city(colorize(city_grids), city)


if __name__ == "__main__":
    main()
