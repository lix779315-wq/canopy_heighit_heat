
# -*- coding: utf-8 -*-


from pathlib import Path
import re
import unicodedata

import geopandas as gpd
import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from matplotlib.cm import ScalarMappable
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D




CITY_RESULTS_CSV = Path(
    r"E:\李鑫论文\result summary"
    r"\cover_height_analysis_1m\city_results.csv"
)


GRID_SHP = Path(
    r"E:\李鑫论文\All Cities"
    r"\AllCities_1km_grid_cityid.shp"
)


WORLD_SHP = Path(
    r"E:\李鑫论文\All Cities\10m_cultural"
    r"\10m_cultural\ne_10m_admin_0_countries.shp"
)


OUTPUT_DIR = Path(
    r"E:\李鑫论文\results\figures\Fig1"
)

OUT_PNG = (
    OUTPUT_DIR / "Fig1a_global_canopy_cover_height.png"
)
OUT_PDF = (
    OUTPUT_DIR / "Fig1a_global_canopy_cover_height.pdf"
)



EXPECTED_CITIES = 140
MAP_CRS = "ESRI:54030"

FIGSIZE = (7.2, 3.8)
DPI = 600

SIZE_FACTOR = 350.0
POINT_ALPHA = 0.92

POINT_EDGE_COLOR = "#4F5557"
POINT_EDGE_WIDTH = 0.28

HIGHLIGHT_EDGE_COLOR = "#080A0B"
HIGHLIGHT_EDGE_WIDTH = 0.95

LAND_COLOR = "#F4F4F2"
COUNTRY_EDGE_COLOR = "#858B8D"
COUNTRY_EDGE_WIDTH = 0.40

COVER_LEGEND_FRACTIONS = (
    0.10, 0.20, 0.30, 0.40, 0.50
)

HEIGHT_VMIN = 4.0
HEIGHT_VMAX = 18.0

HEIGHT_TICKS = (
    4, 8, 10, 12, 14, 16, 18
)

HEIGHT_COLORS = (
    "#2453A6",
    "#007FA3",
    "#009E78",
    "#B7AD20",
    "#EF6C24",
    "#9E1F5C",
)

HIGHLIGHT_LABELS = {
    "london": {
        "text": "London",
        "offset": (-15, 11),
        "ha": "right",
        "va": "bottom"
    },
    "melbourne": {
        "text": "Melbourne",
        "offset": (15, -11),
        "ha": "left",
        "va": "top"
    },
    "seattle": {
        "text": "Seattle",
        "offset": (-15, 11),
        "ha": "right",
        "va": "bottom"
    },
}



def normalized_name(value):
    name = unicodedata.normalize(
        "NFKC", str(value)
    ).strip().casefold()

    name = (
        name.replace("–", "-")
        .replace("—", "-")
    )

    return re.sub(r"\s+", " ", name)



def read_city_results():

    if not CITY_RESULTS_CSV.is_file():
        raise FileNotFoundError(
            f"未找到04输出的城市统计表：{CITY_RESULTS_CSV}"
        )

    city = pd.read_csv(
        CITY_RESULTS_CSV,
        dtype={"city_id": "string"},
        encoding="utf-8-sig"
    )

    required = {
        "city_id",
        "Cover",
        "Hmean",
        "n_cover"
    }

    missing = required - set(city.columns)

    if missing:
        raise ValueError(
            f"city_results.csv缺少字段：{sorted(missing)}"
        )

    if (
        city["city_id"].isna().any()
        or city["city_id"].duplicated().any()
    ):
        raise ValueError(
            "城市统计表的city_id必须非空且唯一"
        )

    for col in ("Cover", "Hmean", "n_cover"):
        city[col] = pd.to_numeric(
            city[col], errors="coerce"
        )

    if city[
        ["Cover", "Hmean", "n_cover"]
    ].isna().any().any():
        raise ValueError(
            "城市Cover、Hmean或n_cover存在缺失"
        )

    if (
        not city["Cover"].between(0, 100).all()
        or not city["Hmean"].gt(2).all()
    ):
        raise ValueError(
            "Cover或Hmean超出有效范围"
        )

    if not city["n_cover"].gt(0).all():
        raise ValueError(
            "部分城市没有有效网格"
        )

    if len(city) != EXPECTED_CITIES:
        raise ValueError(
            f"预期{EXPECTED_CITIES}座城市，"
            f"实际{len(city)}座"
        )

    return city[
        ["city_id", "Cover", "Hmean", "n_cover"]
    ].copy()


def read_city_locations():

    if not GRID_SHP.is_file():
        raise FileNotFoundError(
            f"未找到01输出的网格：{GRID_SHP}"
        )

    grid = gpd.read_file(GRID_SHP)

    needed = {
        "grid_id",
        "city_id",
        "city_name",
        "geometry"
    }

    missing = needed - set(grid.columns)

    if missing:
        raise ValueError(
            f"网格Shapefile缺少字段：{sorted(missing)}"
        )

    if grid.crs is None:
        raise ValueError(
            "网格Shapefile缺少CRS"
        )

    grid = grid[
        ["grid_id", "city_id", "city_name", "geometry"]
    ].copy()

    for col in ("grid_id", "city_id", "city_name"):
        grid[col] = grid[col].astype("string")

    if grid[
        ["grid_id", "city_id", "city_name"]
    ].isna().any().any():
        raise ValueError(
            "网格ID、城市ID或城市名称存在空值"
        )

    if grid["grid_id"].duplicated().any():
        raise ValueError(
            "空间网格grid_id重复"
        )

    if (
        grid.geometry.isna().any()
        or grid.geometry.is_empty.any()
    ):
        raise ValueError(
            "空间网格存在无效几何"
        )

    if not grid.groupby("city_id")[
        "city_name"
    ].nunique().eq(1).all():
        raise ValueError(
            "同一city_id对应多个城市名称"
        )


    projected = grid.to_crs(MAP_CRS)

    bounds = projected.geometry.bounds

    projected["x_center"] = (
        bounds["minx"].to_numpy()
        + bounds["maxx"].to_numpy()
    ) / 2

    projected["y_center"] = (
        bounds["miny"].to_numpy()
        + bounds["maxy"].to_numpy()
    ) / 2


    locations = projected.groupby(
        "city_id", as_index=False
    ).agg(
        city_name=("city_name", "first"),
        x=("x_center", "median"),
        y=("y_center", "median"),
        n_geometry_grids=("grid_id", "size")
    )

    if len(locations) != EXPECTED_CITIES:
        raise ValueError(
            f"空间网格实际包含{len(locations)}座城市"
        )

    if not np.isfinite(
        locations[["x", "y"]].to_numpy(float)
    ).all():
        raise ValueError(
            "城市投影坐标存在无效值"
        )

    return locations



def prepare_cities():

    city = read_city_results()
    locations = read_city_locations()

    merged = city.merge(
        locations,
        on="city_id",
        how="outer",
        validate="one_to_one",
        indicator=True
    )

    unmatched = merged.loc[
        merged["_merge"].ne("both"),
        ["city_id", "_merge"]
    ]

    if not unmatched.empty:
        raise ValueError(
            "01与04的city_id不匹配：\n"
            + unmatched.to_string(index=False)
        )

    merged = merged.drop(columns="_merge")


    merged["cover_fraction"] = (
        merged["Cover"] / 100.0
    )

    merged["name_key"] = (
        merged["city_name"].map(normalized_name)
    )

    merged["highlight"] = False

    for name in HIGHLIGHT_LABELS:

        exact = merged["name_key"].eq(name)


        candidates = (
            exact
            if exact.any()
            else merged["name_key"].str.contains(
                rf"(?<![a-z]){re.escape(name)}(?![a-z])",
                regex=True,
                na=False
            )
        )

        if candidates.sum() != 1:
            raise ValueError(
                f"无法唯一找到需标注的{name}，"
                "请检查01网格中的city_name"
            )

        merged.loc[
            candidates, "highlight"
        ] = True

        merged.loc[
            candidates, "label_key"
        ] = name

    return merged



def read_world():

    if not WORLD_SHP.is_file():
        raise FileNotFoundError(
            f"未找到全球国界文件：{WORLD_SHP}"
        )

    world = gpd.read_file(WORLD_SHP)

    if world.crs is None:
        raise ValueError(
            "Natural Earth国界数据缺少CRS"
        )

    lookup = {
        str(c).casefold(): c
        for c in world.columns
    }

    name_col = next(
        (
            lookup[c]
            for c in (
                "continent",
                "admin",
                "name",
                "name_en",
                "sovereignt"
            )
            if c in lookup
        ),
        None
    )

    if name_col is None:
        raise ValueError(
            "无法识别南极洲字段"
        )

    world = world.loc[
        world[name_col]
        .astype("string")
        .str.strip()
        .str.casefold()
        .ne("antarctica")
        .fillna(True)
    ].copy()

    return world.to_crs(MAP_CRS)



def plot_figure(cities, world):

    mpl.rcParams.update({
        "font.family": "Arial",
        "font.size": 8,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })

    height_cmap = (
        LinearSegmentedColormap.from_list(
            "canopy_height",
            HEIGHT_COLORS,
            N=256
        )
    )

    height_norm = Normalize(
        vmin=HEIGHT_VMIN,
        vmax=HEIGHT_VMAX
    )

    fig, ax = plt.subplots(
        figsize=FIGSIZE,
        dpi=DPI
    )

    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")


    world.plot(
        ax=ax,
        facecolor=LAND_COLOR,
        edgecolor=COUNTRY_EDGE_COLOR,
        linewidth=COUNTRY_EDGE_WIDTH,
        zorder=1
    )

    ordinary = cities.loc[
        ~cities["highlight"]
    ].sort_values(
        "Cover", ascending=False
    )

    highlighted = cities.loc[
        cities["highlight"]
    ]


    ax.scatter(
        ordinary["x"],
        ordinary["y"],
        s=(
            ordinary["cover_fraction"]
            * SIZE_FACTOR
        ),
        c=ordinary["Hmean"],
        cmap=height_cmap,
        norm=height_norm,
        alpha=POINT_ALPHA,
        edgecolors=POINT_EDGE_COLOR,
        linewidths=POINT_EDGE_WIDTH,
        zorder=5
    )


    ax.scatter(
        highlighted["x"],
        highlighted["y"],
        s=(
            highlighted["cover_fraction"]
            * SIZE_FACTOR
        ),
        c=highlighted["Hmean"],
        cmap=height_cmap,
        norm=height_norm,
        alpha=1.0,
        edgecolors=HIGHLIGHT_EDGE_COLOR,
        linewidths=HIGHLIGHT_EDGE_WIDTH,
        zorder=8
    )


    for _, city in highlighted.iterrows():

        setting = HIGHLIGHT_LABELS[
            city["label_key"]
        ]

        ax.annotate(
            setting["text"],
            xy=(city["x"], city["y"]),
            xytext=setting["offset"],
            textcoords="offset points",
            ha=setting["ha"],
            va=setting["va"],
            fontsize=8,
            fontfamily="Arial",
            color="#101214",
            arrowprops={
                "arrowstyle": "-",
                "color": "#686E70",
                "linewidth": 0.45,
                "shrinkA": 2,
                "shrinkB": 3
            },
            zorder=10
        )


    handles = [
        Line2D(
            [], [],
            marker="o",
            linestyle="none",
            markersize=np.sqrt(
                fraction * SIZE_FACTOR
            ),
            markerfacecolor="#F2F2F0",
            markeredgecolor=POINT_EDGE_COLOR,
            markeredgewidth=0.65,
            label=f"{int(fraction * 100)}%"
        )
        for fraction in COVER_LEGEND_FRACTIONS
    ]

    size_legend = ax.legend(
        handles=handles,
        title="Canopy cover",
        loc="lower left",
        bbox_to_anchor=(0.018, 0.048),
        frameon=False,
        fontsize=7,
        title_fontsize=8,
        handletextpad=0.55,
        handlelength=1.8,
        labelspacing=0.70,
        borderaxespad=0,
        ncol=5,
        columnspacing=1.05
    )

    ax.add_artist(size_legend)


    mappable = ScalarMappable(
        norm=height_norm,
        cmap=height_cmap
    )

    mappable.set_array([])

    cax = ax.inset_axes([
        0.33,
        0.055,
        0.30,
        0.030
    ])

    colorbar = fig.colorbar(
        mappable,
        cax=cax,
        orientation="horizontal",
        ticks=HEIGHT_TICKS
    )

    colorbar.ax.xaxis.set_ticks_position(
        "bottom"
    )

    colorbar.ax.tick_params(
        axis="x",
        which="both",
        labelsize=7,
        length=0,
        width=0,
        pad=2,
        colors="#252A2C"
    )

    colorbar.set_label(
        "Mean height (m)",
        fontsize=8,
        labelpad=3
    )

    colorbar.outline.set_edgecolor(
        "#4D5355"
    )

    colorbar.outline.set_linewidth(0.5)


    ax.text(
        0.008, 0.985,
        "a",
        transform=ax.transAxes,
        ha="left",
        va="top",
        fontsize=10,
        fontweight="bold",
        color="#101214",
        zorder=20
    )

    minx, miny, maxx, maxy = (
        world.total_bounds
    )

    ax.set_xlim(minx, maxx)
    ax.set_ylim(miny, maxy)

    ax.set_aspect(
        "equal",
        adjustable="box"
    )

    ax.set_axis_off()

    fig.subplots_adjust(
        left=0.005,
        right=0.995,
        bottom=0.005,
        top=0.995
    )


    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    fig.savefig(
        OUT_PNG,
        dpi=DPI,
        facecolor="white",
        edgecolor="none",
        transparent=False,
        bbox_inches="tight",
        pad_inches=0.02
    )

    fig.savefig(
        OUT_PDF,
        facecolor="white",
        edgecolor="none",
        transparent=False,
        bbox_inches="tight",
        pad_inches=0.02
    )

    plt.close(fig)



def main():

    cities = prepare_cities()
    world = read_world()

    plot_figure(cities, world)


if __name__ == "__main__":
    main()
