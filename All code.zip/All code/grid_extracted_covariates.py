
# -*- coding: utf-8 -*-


from contextlib import ExitStack
from pathlib import Path

import fiona
import numpy as np
import pandas as pd
import rasterio
from pyproj import CRS, Geod, Transformer
from rasterio.errors import WindowError
from rasterio.features import geometry_mask, geometry_window
from shapely.geometry import mapping, shape
from shapely.ops import transform




CITY_SHP = Path(
    r"E:\李鑫论文\All Cities\AllCities_with_city_id.shp"
)
GRID_SHP = Path(
    r"E:\李鑫论文\All Cities\AllCities_1km_grid_cityid.shp"
)
CANOPY_CSV = Path(
    r"E:\李鑫论文\result summary\canopy_metrics_1m\grid_canopy_metrics_1m.csv"
)

GRDI_TIF = Path(r"E:\李鑫论文\GRDI\GRDI_2020.tif")
POP_TIF = Path(
    r"E:\李鑫论文\world pop\WorldPop_population_count_2020.tif"
)
BUILT_S_TIF = Path(
    r"E:\李鑫论文\GHSL\GHS_BUILT_S_2020.tif"
)
BUILT_H_TIF = Path(
    r"E:\李鑫论文\GHSL\GHS_BUILT_H_2018.tif"
)
CLIMATE_TIF = Path(
    r"E:\李鑫论文\柯本气候带1km\Koppen_Geiger_present.tif"
)
LST_TIF = Path(
    r"E:\李鑫论文\LST\LST_local_summer_mean_2019_2021.tif"
)


SMOD_TIF = None

OUTPUT_DIR = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing"
)



LST_EXTRA_SCALE = 1.0
LST_EXTRA_OFFSET = 0.0


MIN_BUILT_DENSITY = 0.0
REQUIRE_POSITIVE_POPULATION = False
ALLOWED_SMOD_CODES = None

RASTERS = {
    "grdi": (GRDI_TIF, "mean"),
    "population": (POP_TIF, "sum"),
    "built_density": (BUILT_S_TIF, "built_fraction"),
    "built_height": (BUILT_H_TIF, "mean"),
    "climate": (CLIMATE_TIF, "mode"),
    "lst": (LST_TIF, "mean"),
}

if SMOD_TIF is not None:
    RASTERS["smod"] = (SMOD_TIF, "mode")

GEOD = Geod(ellps="WGS84")
EQUAL_AREA = CRS.from_epsg(6933)
WGS84 = CRS.from_epsg(4326)


def get_crs(src):
    crs = src.crs_wkt or src.crs
    if not crs:
        raise ValueError("输入Shapefile缺少坐标系")
    return CRS.from_user_input(crs)


def load_city_centers():
    centers = {}

    with fiona.open(CITY_SHP) as src:
        crs = get_crs(src)

        to_area = Transformer.from_crs(
            crs, EQUAL_AREA, always_xy=True
        ).transform

        to_geo = Transformer.from_crs(
            EQUAL_AREA, WGS84, always_xy=True
        ).transform

        for feat in src:
            city_id = str(feat["properties"]["city_id"])

            if city_id in centers:
                raise ValueError(f"城市ID重复：{city_id}")

            geom = shape(feat["geometry"])

            if geom.is_empty or not geom.is_valid:
                raise ValueError(f"城市几何无效：{city_id}")

            center = transform(
                to_geo,
                transform(to_area, geom).centroid
            )
            centers[city_id] = (center.x, center.y)

    return centers


def pixel_areas(src, window):
    tr = src.window_transform(window)
    h = int(window.height)

    if abs(tr.b) > 1e-12 or abs(tr.d) > 1e-12:
        raise ValueError("不支持旋转栅格")

    crs = CRS.from_user_input(src.crs)

    if crs.is_geographic:
        geod = crs.get_geod()
        out = np.empty((h, 1), dtype=float)

        for i in range(h):
            y0 = tr.f + i * tr.e
            y1 = tr.f + (i + 1) * tr.e

            area, _ = geod.polygon_area_perimeter(
                [tr.c, tr.c + tr.a, tr.c + tr.a, tr.c],
                [y0, y0, y1, y1]
            )
            out[i, 0] = abs(area)

        return out

    axes = crs.axis_info

    if not crs.is_projected or len(axes) < 2:
        raise ValueError("无法确定像元面积")

    return np.full(
        (h, 1),
        abs(
            tr.a * tr.e
            * axes[0].unit_conversion_factor
            * axes[1].unit_conversion_factor
        )
    )



def zonal_value(src, geometry, project, name, method):
    geom = mapping(transform(project, geometry))

    try:
        win = geometry_window(
            src, [geom], boundless=False
        )
    except WindowError:
        return np.nan

    if win.width <= 0 or win.height <= 0:
        return np.nan

    data = src.read(
        1,
        window=win,
        masked=True,
        out_dtype="float64"
    )

    inside = geometry_mask(
        [geom],
        out_shape=data.shape,
        transform=src.window_transform(win),
        invert=True,
        all_touched=False
    )

    vals = (
        data.data * float(src.scales[0])
        + float(src.offsets[0])
    )

    if name == "lst":
        vals = vals * LST_EXTRA_SCALE + LST_EXTRA_OFFSET

    valid = (
        inside
        & ~np.ma.getmaskarray(data)
        & np.isfinite(vals)
    )

    if name == "grdi":
        valid &= (vals >= 0) & (vals <= 100)

    elif name == "lst":
        valid &= (vals >= -50) & (vals <= 90)

    elif name in (
        "population", "built_density", "built_height"
    ):
        valid &= vals >= 0

    elif name == "climate":
        valid &= np.isclose(vals, np.round(vals))

    area = np.broadcast_to(
        pixel_areas(src, win),
        vals.shape
    )

    if name == "built_density":
        # BUILT_S必须是每个源像元内的建成面积，单位m²。
        valid &= vals <= area * (1 + 1e-6)

    if not np.any(valid):
        return np.nan

    v = vals[valid]
    a = area[valid]

    if method == "sum":
        return float(v.sum())

    if method == "built_fraction":
        return float(v.sum() / a.sum())

    if method == "mean":
        return float(np.average(v, weights=a))

    codes, inv = np.unique(
        np.rint(v).astype(int),
        return_inverse=True
    )

    return int(
        codes[np.argmax(np.bincount(inv, weights=a))]
    )



def extract_covariates():
    centers = load_city_centers()
    rows = []

    with ExitStack() as stack:
        grids = stack.enter_context(fiona.open(GRID_SHP))
        crs = get_crs(grids)

        to_area = Transformer.from_crs(
            crs, EQUAL_AREA, always_xy=True
        ).transform

        to_geo = Transformer.from_crs(
            EQUAL_AREA, WGS84, always_xy=True
        ).transform

        sources = {}

        for name, (path, method) in RASTERS.items():
            src = stack.enter_context(rasterio.open(path))

            if src.count != 1 or src.crs is None:
                raise ValueError(
                    f"栅格必须为带坐标系的单波段影像：{path}"
                )

            raster_crs = CRS.from_user_input(src.crs)

            if name == "built_density" and raster_crs.is_projected:
                op = raster_crs.coordinate_operation

                desc = " ".join((
                    raster_crs.name or "",
                    op.name if op else "",
                    op.method_name if op else ""
                )).lower()

                equal_area_terms = (
                    "equal area", "equal-area",
                    "mollweide", "sinusoidal",
                    "albers", "equal earth"
                )

                if not any(k in desc for k in equal_area_terms):
                    raise ValueError(
                        "BUILT_S影像需使用等积投影或地理坐标系"
                    )

            prj = Transformer.from_crs(
                crs, raster_crs, always_xy=True
            ).transform

            sources[name] = (src, prj, method)

        seen = set()

        for feat in grids:
            p = feat["properties"]

            grid_id = str(p["grid_id"])
            city_id = str(p["city_id"])

            if grid_id in seen:
                raise ValueError(f"重复网格ID：{grid_id}")

            seen.add(grid_id)

            if city_id not in centers:
                raise ValueError(
                    f"城市ID未匹配：{city_id}"
                )

            g = shape(feat["geometry"])

            if g.is_empty or not g.is_valid:
                raise ValueError(
                    f"网格几何无效：{grid_id}"
                )

            g_area = transform(to_area, g)
            center = transform(to_geo, g_area.centroid)

            lon, lat = centers[city_id]
            _, _, distance = GEOD.inv(
                lon, lat, center.x, center.y
            )

            row = {
                "grid_id": grid_id,
                "city_id": city_id,
                "grid_area_km2": g_area.area / 1e6,
                "distance_to_center_km": distance / 1000
            }

            for name, (src, project, method) in sources.items():
                row[name] = zonal_value(
                    src, g, project, name, method
                )

            rows.append(row)

    return pd.DataFrame(rows)


def standardize(df, thermal=False):
    df = df.copy()

    df["ses_affluence"] = 100 - df["grdi"]

    df["population_density_km2"] = (
        df["population"] / df["grid_area_km2"]
    )

    df["log1p_population"] = np.log1p(
        df["population"]
    )

    df["log1p_population_density"] = np.log1p(
        df["population_density_km2"]
    )

    df["log1p_built_height"] = np.log1p(
        df["built_height"]
    )

    variables = {
        "ses_affluence": "z_ses_affluence",
        "population": "z_population",
        "log1p_population": "z_log1p_population",
        "population_density_km2": "z_population_density",
        "log1p_population_density": "z_log1p_population_density",
        "built_density": "z_built_density",
        "built_height": "z_built_height",
        "log1p_built_height": "z_log1p_built_height",
        "distance_to_center_km": "z_distance_to_center_km",
        "Cover": "z_Cover",
        "Hmean": "z_Hmean",
        "HSD": "z_HSD",
        "HP90": "z_HP90",
        "UpperCover12": "z_UpperCover12"
    }

    for col, newcol in variables.items():
        group = df.groupby("city_id")[col]

        mean = group.transform("mean")
        sd = group.transform(
            lambda s: s.std(ddof=0)
        )

        df[newcol] = (
            (df[col] - mean)
            / sd.where(sd > 0, np.nan)
        )

    df["ses_city_z"] = df["z_ses_affluence"]

    df["ses_percentile"] = (
        df.groupby("city_id")["ses_affluence"]
        .rank(pct=True) * 100
    )

    df["ses_quintile"] = pd.Series(
        pd.NA,
        index=df.index,
        dtype="Int64"
    )

    df["ses_city_eligible"] = False

    for _, city in df.groupby("city_id"):
        if (
            len(city) < 5
            or city["ses_affluence"].nunique() < 5
        ):
            continue

        groups = pd.qcut(
            city["ses_affluence"],
            5,
            labels=False,
            duplicates="drop"
        )

        if groups.nunique() == 5:
            df.loc[city.index, "ses_quintile"] = pd.array(
                groups.to_numpy() + 1,
                dtype="Int64"
            )

            df.loc[
                city.index, "ses_city_eligible"
            ] = True

    df["climate"] = df["climate"].astype("Int64")

    if "smod" in df:
        df["smod"] = df["smod"].astype("Int64")

    if thermal:
        df["LST_anomaly_C"] = (
            df["lst"]
            - df.groupby("city_id")["lst"].transform("mean")
        )

    return df



def main():
    canopy = pd.read_csv(
        CANOPY_CSV,
        dtype={"grid_id": str, "city_id": str}
    )

    covariates = extract_covariates()

    for df in (canopy, covariates):
        if (
            df[["grid_id", "city_id"]].isna().any().any()
            or df["grid_id"].duplicated().any()
        ):
            raise ValueError(
                "grid_id或city_id为空、重复"
            )

    needed = [
        "Cover", "Hmean", "HSD",
        "HP90", "UpperCover12", "valid_pixels"
    ]

    if any(c not in canopy.columns for c in needed):
        raise ValueError(
            "树冠指标CSV缺少必需字段"
        )

    if set(canopy.grid_id) != set(covariates.grid_id):
        raise ValueError(
            "树冠指标与协变量使用的grid_id不一致"
        )

    df = canopy.merge(
        covariates,
        on="grid_id",
        validate="one_to_one",
        suffixes=("_canopy", "_covariates")
    )

    if not (
        df["city_id_canopy"]
        == df["city_id_covariates"]
    ).all():
        raise ValueError(
            "同一网格的城市ID不一致"
        )

    df["city_id"] = df["city_id_canopy"]

    df = df.drop(columns=[
        "city_id_canopy",
        "city_id_covariates"
    ])

    numeric_columns = needed + [
        "grid_area_km2",
        "distance_to_center_km",
        *RASTERS
    ]

    for col in numeric_columns:
        df[col] = pd.to_numeric(
            df[col],
            errors="coerce"
        )

    df = df.replace(
        [np.inf, -np.inf],
        np.nan
    )

    base = (
        df["valid_pixels"].gt(0)
        & df["Cover"].between(0, 100)
        & df["Hmean"].gt(2)
        & df["HSD"].ge(0)
        & df["HP90"].gt(2)
        & df["UpperCover12"].between(0, 100)
        & df["UpperCover12"].le(df["Cover"] + 1e-6)
        & df["grdi"].between(0, 100)
        & df["population"].ge(0)
        & df["built_density"].between(
            MIN_BUILT_DENSITY, 1
        )
        & df["built_height"].ge(0)
        & df["climate"].notna()
        & df["grid_area_km2"].gt(0)
        & df["distance_to_center_km"].ge(0)
    )

    if REQUIRE_POSITIVE_POPULATION:
        base &= df["population"].gt(0)

    if ALLOWED_SMOD_CODES is not None:
        if "smod" not in df:
            raise ValueError(
                "使用SMOD掩膜需要先配置SMOD_TIF"
            )

        base &= df["smod"].isin(
            ALLOWED_SMOD_CODES
        )

    structure = df.loc[base].copy()

    thermal = df.loc[
        base & df["lst"].between(-50, 90)
    ].copy()

    if structure.empty or thermal.empty:
        raise ValueError(
            "分析样本为空，请核对输入产品、单位和筛选条件"
        )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    standardize(structure).to_csv(
        OUTPUT_DIR / "sample_structure_ses.csv",
        index=False,
        encoding="utf-8-sig"
    )

    standardize(thermal, thermal=True).to_csv(
        OUTPUT_DIR / "sample_thermal.csv",
        index=False,
        encoding="utf-8-sig"
    )


if __name__ == "__main__":
    main()
