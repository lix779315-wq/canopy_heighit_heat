
# -*- coding: utf-8 -*-

from pathlib import Path

import numpy as np
import pandas as pd


INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_thermal.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\high_heat_screening_submission"
)

HIGH_HEAT_Q = 0.80
LOW_COVER_Q = 0.25
HEIGHT_DEFICIT_Q = 0.25

SPLINE_KNOT_Q = (0.0, 0.25, 0.50, 0.75, 1.0)
POPULATION_PERCENTILES = (10, 25, 50, 75, 90)

GROUPS = {
    "all_grids": "all_grids",
    "high_heat": "high_heat",
    "cover_only": "screen_cover_only",
    "height_informed": "screen_height_informed",
    "overlap": "screen_overlap",
    "combined": "screen_combined",
    "newly_identified": "newly_identified",
    "cover_only_exclusive": "cover_only_exclusive",
    "neither_screened": "neither_screened",
}



def prepare_data():
    df = pd.read_csv(
        INPUT_CSV,
        dtype={"grid_id": str, "city_id": str},
        encoding="utf-8-sig"
    )

    required = [
        "grid_id", "city_id", "lst",
        "population", "Cover", "UpperCover12"
    ]

    missing = set(required) - set(df.columns)

    if missing:
        raise ValueError(f"缺少字段：{sorted(missing)}")

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df["grid_id"].duplicated().any()
    ):
        raise ValueError("grid_id或city_id缺失、重复")

    numeric = required[2:]

    df[numeric] = df[numeric].apply(
        pd.to_numeric, errors="coerce"
    )

    if not np.isfinite(
        df[numeric].to_numpy(dtype=float)
    ).all():
        raise ValueError("筛查样本存在缺失或非有限值")

    valid = (
        df["lst"].between(-50, 90)
        & df["population"].ge(0)
        & df["Cover"].between(0, 100)
        & df["UpperCover12"].between(0, 100)
        & df["UpperCover12"].le(df["Cover"] + 1e-6)
    )

    if not valid.all():
        raise ValueError("筛查样本数值范围异常")

    df = df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)

    df["LST_anomaly_C"] = (
        df["lst"]
        - df.groupby("city_id")["lst"].transform("mean")
    )

    return df


def restricted_cubic_spline(cover):

    knots = np.quantile(
        cover, SPLINE_KNOT_Q
    )

    if np.any(np.diff(knots) <= 0):
        raise ValueError("Cover样条节点重复")

    k4, k5 = knots[-2:]
    scale = (k5 - knots[0]) ** 2

    x = np.asarray(cover, dtype=float)
    columns = [x]

    for knot in knots[:-2]:
        basis = (
            np.maximum(x - knot, 0) ** 3
            - (k5 - knot) / (k5 - k4)
            * np.maximum(x - k4, 0) ** 3
            + (k4 - knot) / (k5 - k4)
            * np.maximum(x - k5, 0) ** 3
        ) / scale

        columns.append(basis)

    return np.column_stack(columns)


def cover_adjusted_height(df):
    # UpperCover12 ~ RCS(Cover) + 城市固定效应
    x = restricted_cubic_spline(
        df["Cover"].to_numpy()
    )

    y = df["UpperCover12"].to_numpy(float)

    codes, cities = pd.factorize(
        df["city_id"], sort=True
    )

    counts = np.bincount(
        codes, minlength=len(cities)
    )

    x_means = np.zeros(
        (len(cities), x.shape[1])
    )

    np.add.at(x_means, codes, x)
    x_means /= counts[:, None]

    y_means = (
        np.bincount(
            codes, weights=y,
            minlength=len(cities)
        ) / counts
    )

    x_within = x - x_means[codes]
    y_within = y - y_means[codes]

    beta, _, rank, _ = np.linalg.lstsq(
        x_within,
        y_within,
        rcond=None
    )

    if rank != x.shape[1]:
        raise ValueError(
            "城市固定效应Cover样条模型不满秩"
        )

    predicted = (
        x @ beta
        + (y_means - x_means @ beta)[codes]
    )

    df["UpperCover12_expected_pct"] = predicted

    df["UpperCover12_cover_residual_pp"] = (
        y - predicted
    )

    return df


def screen_population(df):
    city = df.groupby("city_id")

    df["heat_P80_C"] = (
        city["LST_anomaly_C"].transform(
            lambda s: s.quantile(HIGH_HEAT_Q)
        )
    )

    df["Cover_P25_pct"] = (
        city["Cover"].transform(
            lambda s: s.quantile(LOW_COVER_Q)
        )
    )

    df["height_residual_P25_pp"] = (
        city["UpperCover12_cover_residual_pp"]
        .transform(
            lambda s: s.quantile(HEIGHT_DEFICIT_Q)
        )
    )

    df["all_grids"] = True

    df["high_heat"] = (
        df["LST_anomaly_C"] > df["heat_P80_C"]
    )

    df["low_cover"] = (
        df["Cover"] < df["Cover_P25_pct"]
    )

    df["height_deficit"] = (
        df["UpperCover12_cover_residual_pp"]
        <= df["height_residual_P25_pp"]
    )

    df["screen_cover_only"] = (
        df["high_heat"] & df["low_cover"]
    )

    df["screen_height_informed"] = (
        df["high_heat"] & df["height_deficit"]
    )

    df["screen_overlap"] = (
        df["screen_cover_only"]
        & df["screen_height_informed"]
    )

    df["screen_combined"] = (
        df["screen_cover_only"]
        | df["screen_height_informed"]
    )

    df["newly_identified"] = (
        df["screen_height_informed"]
        & ~df["screen_cover_only"]
    )

    df["cover_only_exclusive"] = (
        df["screen_cover_only"]
        & ~df["screen_height_informed"]
    )

    df["neither_screened"] = (
        df["high_heat"]
        & ~df["screen_combined"]
    )

    df["Cover_city_percentile"] = (
        city["Cover"].rank(
            method="average", pct=True
        ) * 100
    )

    df["Cover_percentile_bin"] = np.minimum(
        np.floor(
            df["Cover_city_percentile"]
        ).astype(int),
        99
    )

    return df


def fraction(top, bottom):
    return (
        float(top / bottom)
        if bottom > 0 else np.nan
    )


def weighted_percentile(values, weights, q):
    values = np.asarray(values, float)
    weights = np.asarray(weights, float)

    valid = (
        np.isfinite(values)
        & np.isfinite(weights)
        & (weights > 0)
    )

    if not valid.any():
        return np.nan

    order = np.argsort(
        values[valid],
        kind="stable"
    )

    v = values[valid][order]
    w = weights[valid][order]

    position = np.searchsorted(
        np.cumsum(w),
        q * w.sum(),
        side="left"
    )

    return float(
        v[min(position, len(v) - 1)]
    )



def population_summary(df):
    row = {}

    for name, column in GROUPS.items():
        flag = df[column]

        row[f"{name}_n_grids"] = int(
            flag.sum()
        )

        row[f"{name}_population"] = float(
            df.loc[flag, "population"].sum()
        )

    missed = row["newly_identified_population"]

    row["newly_identified_fraction_of_high_heat"] = (
        fraction(
            missed,
            row["high_heat_population"]
        )
    )

    row["omission_fraction_of_height_informed"] = (
        fraction(
            missed,
            row["height_informed_population"]
        )
    )

    row["omission_fraction_of_combined"] = (
        fraction(
            missed,
            row["combined_population"]
        )
    )

    new = df.loc[df["newly_identified"]]

    row["newly_identified_fraction_above_Cover_P50"] = (
        fraction(
            new.loc[
                new["Cover_city_percentile"] > 50,
                "population"
            ].sum(),
            missed
        )
    )

    for q in POPULATION_PERCENTILES:
        row[f"newly_identified_cover_rank_P{q}"] = (
            weighted_percentile(
                new["Cover_city_percentile"],
                new["population"],
                q / 100
            )
        )

    return row



def percentile_distribution(df):
    rows = []

    for name, column in GROUPS.items():
        selected = df.loc[df[column]]

        population = (
            selected.groupby(
                "Cover_percentile_bin"
            )["population"].sum()
        )

        grids = selected.groupby(
            "Cover_percentile_bin"
        ).size()

        total = float(
            selected["population"].sum()
        )

        cumulative = 0.0

        for bin_id in range(100):
            pop = float(
                population.get(bin_id, 0)
            )

            cumulative += pop

            rows.append({
                "group": name,
                "cover_percentile_bin": bin_id,
                "n_grids": int(
                    grids.get(bin_id, 0)
                ),
                "population": pop,
                "population_fraction": fraction(
                    pop, total
                ),
                "cumulative_population_fraction": (
                    fraction(cumulative, total)
                )
            })

    return pd.DataFrame(rows)


def main():
    df = prepare_data()

    df = cover_adjusted_height(df)
    df = screen_population(df)

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    df.to_csv(
        OUTPUT_DIR / "grid_screening_details.csv",
        index=False,
        encoding="utf-8-sig"
    )

    cities = pd.DataFrame([
        {
            "city_id": city_id,
            **population_summary(city)
        }
        for city_id, city in df.groupby(
            "city_id", sort=True
        )
    ])

    cities.to_csv(
        OUTPUT_DIR / "city_screening_population_summary.csv",
        index=False,
        encoding="utf-8-sig"
    )

    global_summary = {
        "n_cities": df["city_id"].nunique(),
        "n_cities_with_newly_identified": int(
            (
                cities["newly_identified_population"] > 0
            ).sum()
        ),
        **population_summary(df)
    }

    pd.DataFrame([global_summary]).to_csv(
        OUTPUT_DIR / "global_screening_population_summary.csv",
        index=False,
        encoding="utf-8-sig"
    )

    percentile_distribution(df).to_csv(
        OUTPUT_DIR / "population_distribution_by_city_cover_percentile.csv",
        index=False,
        encoding="utf-8-sig"
    )


if __name__ == "__main__":
    main()
