
# -*- coding: utf-8 -*-


from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np
import pandas as pd



INPUT_CSV = Path(
    r"E:\李鑫论文\result summary\canopy_metrics_1m\grid_canopy_metrics_1m.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\results\figures\neighbor_height_difference"
)



OUTPUT_NAME = "neighbor_height_difference_heatmap"

EXPECTED_CITIES = 140
COVER_CALIPER_PP = 5.0
DPI = 600

NEIGHBORS = (
    (1, 0),
    (0, 1),
    (1, 1),
    (1, -1)
)

COVER_EDGES = np.array([
    0, 10, 20, 30, 40, 50,
    60, 70, 80, 90, 100.000001
])

HEIGHT_EDGES = np.array([
    0, 0.25, 0.5, 0.75, 1,
    1.5, 2, 3, 4, 5, np.inf
])

COVER_LABELS = [
    f"{a}–{a + 10}"
    for a in range(0, 100, 10)
]

HEIGHT_LABELS = [
    "<0.25",
    "0.25–0.5",
    "0.5–0.75",
    "0.75–1",
    "1–1.5",
    "1.5–2",
    "2–3",
    "3–4",
    "4–5",
    "≥5"
]

HEIGHT_TICK_LABELS = [
    "<0.25",
    "0.5",
    "0.75",
    "1",
    "1.5",
    "2",
    "3",
    "4",
    "5",
    "≥5"
]



AX_W_MM = 69.144
AX_H_MM = 52.211

LEFT_MM = 18.0
BOTTOM_MM = 16.0
TOP_MM = 4.0

CBAR_GAP_MM = 3.0
CBAR_W_MM = 4.0
RIGHT_MM = 10.0

FIG_W_MM = (
    LEFT_MM
    + AX_W_MM
    + CBAR_GAP_MM
    + CBAR_W_MM
    + RIGHT_MM
)

FIG_H_MM = (
    BOTTOM_MM
    + AX_H_MM
    + TOP_MM
)



def read_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(
            f"未找到输入文件：{INPUT_CSV}"
        )

    columns = [
        "grid_id",
        "city_id",
        "valid_pixels",
        "Cover",
        "Hmean",
        "HSD"
    ]

    df = pd.read_csv(
        INPUT_CSV,
        usecols=lambda name: name in columns,
        dtype={
            "grid_id": "string",
            "city_id": "string"
        },
        encoding="utf-8-sig"
    )

    missing = set(columns) - set(df.columns)

    if missing:
        raise ValueError(
            f"缺少必要字段：{sorted(missing)}"
        )

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError(
            "grid_id/city_id有缺失，或grid_id重复"
        )

    if df.city_id.nunique() != EXPECTED_CITIES:
        raise ValueError(
            f"输入城市数不是{EXPECTED_CITIES}座"
        )

    for field in (
        "valid_pixels",
        "Cover",
        "Hmean",
        "HSD"
    ):
        df[field] = pd.to_numeric(
            df[field],
            errors="coerce"
        )


    indices = df.grid_id.str.extract(
        r"_R(-?\d+)_C(-?\d+)$"
    )

    if indices.isna().any().any():
        raise ValueError(
            "grid_id不符合_R行_C列格式，无法判断相邻网格"
        )

    df["grid_row"] = indices[0].astype("int64")
    df["grid_col"] = indices[1].astype("int64")

    if df.duplicated([
        "city_id",
        "grid_row",
        "grid_col"
    ]).any():
        raise ValueError(
            "同一城市的网格行列编号重复"
        )


    valid = (
        df.valid_pixels.gt(0)
        & df.Cover.gt(0)
        & df.Cover.le(100)
        & df.Hmean.gt(2)
        & df.HSD.ge(0)
        & np.isfinite(
            df[["Cover", "Hmean", "HSD"]]
            .to_numpy(float)
        ).all(axis=1)
    )

    df = df.loc[
        valid,
        [
            "city_id",
            "grid_id",
            "grid_row",
            "grid_col",
            "Cover",
            "Hmean"
        ]
    ].copy()

    if df.empty:
        raise ValueError(
            "没有符合条件的有效网格"
        )

    return df.sort_values([
        "city_id",
        "grid_row",
        "grid_col"
    ]).reset_index(drop=True)



def matched_pairs(city):

    base = city[
        ["grid_col", "grid_row", "Cover", "Hmean"]
    ]

    left = base.rename(columns={
        "Cover": "cover1",
        "Hmean": "height1"
    })

    matches = []

    for dx, dy in NEIGHBORS:

        right = base.rename(columns={
            "Cover": "cover2",
            "Hmean": "height2"
        }).copy()

        right["grid_col"] -= dx
        right["grid_row"] -= dy

        pairs = left.merge(
            right,
            on=["grid_col", "grid_row"],
            how="inner",
            validate="one_to_one"
        )

        # Cover差异严格小于5个百分点
        pairs = pairs.loc[
            (pairs.cover1 - pairs.cover2)
            .abs() < COVER_CALIPER_PP
        ]

        if not pairs.empty:

            matches.append(
                pd.DataFrame({
                    "mean_cover": (
                        pairs.cover1.to_numpy()
                        + pairs.cover2.to_numpy()
                    ) / 2,

                    "abs_height_diff": np.abs(
                        pairs.height1.to_numpy()
                        - pairs.height2.to_numpy()
                    )
                })
            )

    if not matches:

        return pd.DataFrame(columns=[
            "mean_cover",
            "abs_height_diff"
        ])

    return pd.concat(
        matches,
        ignore_index=True
    )



def summarize(df):

    cities = np.sort(
        df.city_id.unique()
    )

    nc = len(COVER_LABELS)
    nh = len(HEIGHT_LABELS)

    counts_all = []
    medians_all = []
    p90s_all = []

    pair_totals = []
    gt2 = []
    gt5 = []
    city_rows = []

    for city_id in cities:

        pairs = matched_pairs(
            df.loc[df.city_id.eq(city_id)]
        )

        n = len(pairs)
        pair_totals.append(n)

        counts = np.zeros(
            (nc, nh),
            dtype=int
        )

        medians = np.full(nc, np.nan)
        p90s = np.full(nc, np.nan)

        if n:

            cover = (
                pairs.mean_cover.to_numpy(float)
            )

            height = (
                pairs.abs_height_diff.to_numpy(float)
            )

            cover_bin = (
                np.searchsorted(
                    COVER_EDGES,
                    cover,
                    side="right"
                ) - 1
            )

            height_bin = (
                np.searchsorted(
                    HEIGHT_EDGES,
                    height,
                    side="right"
                ) - 1
            )

            if (
                (cover_bin < 0).any()
                or (cover_bin >= nc).any()
                or (height_bin < 0).any()
                or (height_bin >= nh).any()
            ):
                raise ValueError(
                    "配对结果超出分箱范围"
                )

            np.add.at(
                counts,
                (cover_bin, height_bin),
                1
            )

            for i in range(nc):

                values = height[
                    cover_bin == i
                ]

                if len(values):

                    medians[i] = np.median(values)

                    p90s[i] = np.quantile(
                        values,
                        0.90
                    )

            gt2.append(
                float(np.mean(height > 2))
            )

            gt5.append(
                float(np.mean(height > 5))
            )

        cover_total = counts.sum(axis=1)

        conditional = np.divide(
            counts,
            cover_total[:, None],

            out=np.full(
                counts.shape,
                np.nan,
                dtype=float
            ),

            where=cover_total[:, None] > 0
        )

        unconditional = (
            counts / n
            if n
            else np.zeros_like(
                counts,
                dtype=float
            )
        )

        counts_all.append(counts)
        medians_all.append(medians)
        p90s_all.append(p90s)

        for i, cover_label in enumerate(
            COVER_LABELS
        ):

            for j, height_label in enumerate(
                HEIGHT_LABELS
            ):

                city_rows.append({
                    "city_id": city_id,
                    "cover_bin": cover_label,
                    "height_diff_bin": height_label,

                    "matched_pair_count_city": n,

                    "city_cover_bin_pair_count": int(
                        cover_total[i]
                    ),

                    "city_bin_pair_count": int(
                        counts[i, j]
                    ),

                    "city_bin_prop": float(
                        unconditional[i, j]
                    ),

                    "city_cover_conditional_prop": float(
                        conditional[i, j]
                    )
                })

    counts_all = np.stack(counts_all)
    medians_all = np.stack(medians_all)
    p90s_all = np.stack(p90s_all)

    totals = np.asarray(
        pair_totals,
        dtype=float
    )[:, None, None]

    unconditional_all = np.divide(
        counts_all,
        totals,

        out=np.zeros_like(
            counts_all,
            dtype=float
        ),

        where=totals > 0
    )

    cover_counts_all = (
        counts_all.sum(axis=2)
    )

    summary_rows = []


    for i, cover_label in enumerate(
        COVER_LABELS
    ):

        city_median = medians_all[:, i]

        city_median = city_median[
            np.isfinite(city_median)
        ]

        city_p90 = p90s_all[:, i]

        city_p90 = city_p90[
            np.isfinite(city_p90)
        ]

        for j, height_label in enumerate(
            HEIGHT_LABELS
        ):

            conditional = np.divide(
                counts_all[:, i, j],
                cover_counts_all[:, i],

                out=np.full(
                    len(cities),
                    np.nan
                ),

                where=cover_counts_all[:, i] > 0
            )

            conditional = conditional[
                np.isfinite(conditional)
            ]

            raw = counts_all[:, i, j]

            summary_rows.append({

                "cover_bin_index": i,
                "cover_bin": cover_label,

                "height_diff_bin_index": j,
                "height_diff_bin": height_label,

                "raw_pair_count": int(
                    raw.sum()
                ),

                "n_city_total": len(cities),

                "n_city_with_pairs": int(
                    (raw > 0).sum()
                ),

                "n_city_with_cover_bin": int(
                    (cover_counts_all[:, i] > 0).sum()
                ),

                "city_equal_mean_prop_percent": float(
                    unconditional_all[:, i, j].mean()
                    * 100
                ),

                "city_equal_mean_conditional_prop_percent": (
                    float(
                        conditional.mean() * 100
                    )
                    if len(conditional)
                    else np.nan
                ),

                "city_equal_median_abs_delta_mean_height_m": (
                    float(np.median(city_median))
                    if len(city_median)
                    else np.nan
                ),

                "city_equal_p90_abs_delta_mean_height_m": (
                    float(np.median(city_p90))
                    if len(city_p90)
                    else np.nan
                )
            })

    overview = pd.DataFrame([{

        "valid_cities": len(cities),

        "cities_with_matched_pairs": int(
            np.count_nonzero(pair_totals)
        ),

        "total_matched_pairs": int(
            sum(pair_totals)
        ),

        "city_equal_fraction_abs_height_diff_gt2m": (
            float(np.mean(gt2))
            if gt2
            else np.nan
        ),

        "city_equal_fraction_abs_height_diff_gt5m": (
            float(np.mean(gt5))
            if gt5
            else np.nan
        ),

        "cover_caliper_pp": COVER_CALIPER_PP
    }])

    return (
        pd.DataFrame(summary_rows),
        pd.DataFrame(city_rows),
        overview
    )



def height_to_axis(value):

    if not np.isfinite(value):
        return np.nan

    index = (
        np.searchsorted(
            HEIGHT_EDGES,
            max(value, 0),
            side="right"
        ) - 1
    )

    if index >= len(HEIGHT_LABELS) - 1:
        return len(HEIGHT_LABELS) - 1 + 0.20

    low, high = HEIGHT_EDGES[
        index:index + 2
    ]

    return (
        index - 0.5
        + (value - low) / (high - low)
    )



def draw_figure(summary):

    nc = len(COVER_LABELS)
    nh = len(HEIGHT_LABELS)

    matrix = np.full(
        (nh, nc),
        np.nan
    )

    for row in summary.itertuples(
        index=False
    ):

        matrix[
            row.height_diff_bin_index,
            row.cover_bin_index
        ] = (
            row.city_equal_mean_conditional_prop_percent
        )

    if not np.isfinite(matrix).any():
        raise ValueError(
            "没有可绘制的网格对条件比例"
        )


    cmap = LinearSegmentedColormap.from_list(
        "height_difference_warm",
        [
            "#F4F1EA",
            "#E7B24C",
            "#EF6C24",
            "#9E1F5C"
        ],
        N=256
    )

    cmap.set_bad("#E5E5E5")

    plt.rcParams.update({

        "font.family": "sans-serif",

        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],

        "font.size": 9,
        "axes.labelsize": 9,

        "xtick.labelsize": 8,
        "ytick.labelsize": 8,

        "axes.linewidth": 0.65,

        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,

        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })


    fig = plt.figure(
        figsize=(
            FIG_W_MM / 25.4,
            FIG_H_MM / 25.4
        )
    )

    ax = fig.add_axes([
        LEFT_MM / FIG_W_MM,
        BOTTOM_MM / FIG_H_MM,
        AX_W_MM / FIG_W_MM,
        AX_H_MM / FIG_H_MM
    ])

    cax = fig.add_axes([
        (
            LEFT_MM
            + AX_W_MM
            + CBAR_GAP_MM
        ) / FIG_W_MM,

        BOTTOM_MM / FIG_H_MM,
        CBAR_W_MM / FIG_W_MM,
        AX_H_MM / FIG_H_MM
    ])


    peak = float(
        np.nanmax(matrix)
    )

    vmax = max(
        40.0,
        np.ceil(peak / 10.0) * 10.0
    )

    im = ax.imshow(
        matrix,

        origin="lower",
        aspect="auto",

        cmap=cmap,

        vmin=0,
        vmax=vmax
    )


    ax.set_xticks(
        np.arange(nc),
        [
            str(value)
            for value in range(10, 101, 10)
        ]
    )

    ax.set_xlabel(
        "Mean canopy cover (%)",
        labelpad=4
    )


    ax.set_yticks(
        np.arange(nh),
        HEIGHT_TICK_LABELS
    )

    ax.set_ylabel(
        "Height difference (m)",
        labelpad=4
    )


    ax.set_xticks(
        np.arange(-0.5, nc, 1),
        minor=True
    )

    ax.set_yticks(
        np.arange(-0.5, nh, 1),
        minor=True
    )

    ax.grid(
        which="minor",
        color="white",
        linewidth=0.35
    )

    ax.tick_params(
        which="minor",
        bottom=False,
        left=False
    )

    ax.tick_params(
        axis="both",
        direction="out",
        width=0.65,
        length=2.5,
        pad=2
    )


    median = (
        summary[
            [
                "cover_bin_index",
                "city_equal_median_abs_delta_mean_height_m"
            ]
        ]
        .drop_duplicates(
            "cover_bin_index"
        )
        .sort_values(
            "cover_bin_index"
        )
    )

    xs = (
        median.cover_bin_index
        .to_numpy(float)
    )

    ys = np.array([
        height_to_axis(value)

        for value in (
            median.city_equal_median_abs_delta_mean_height_m
        )
    ])

    keep = np.isfinite(ys)

    ax.plot(
        xs[keep],
        ys[keep],

        color="#272727",
        linewidth=1.1,

        marker="o",
        markersize=2,

        zorder=5
    )


    cbar = fig.colorbar(
        im,
        cax=cax
    )

    cbar.set_label(
        "Paired grids (%)",
        rotation=270,
        labelpad=11
    )

    if vmax == 40:
        cbar.set_ticks([0, 20, 40])
    else:
        cbar.set_ticks(
            np.linspace(0, vmax, 5)
        )

    cbar.ax.tick_params(
        labelsize=8,
        width=0.65,
        length=2.5,
        pad=2
    )

    cbar.outline.set_linewidth(
        0.65
    )


    for spine in ax.spines.values():

        spine.set_visible(True)
        spine.set_color("#444444")
        spine.set_linewidth(0.65)


    return fig



def main():

    data = read_data()

    summary, city_bins, overview = summarize(
        data
    )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    summary.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_summary.csv",

        index=False,
        encoding="utf-8-sig"
    )

    city_bins.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_city_bins.csv",

        index=False,
        encoding="utf-8-sig"
    )

    overview.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_overview.csv",

        index=False,
        encoding="utf-8-sig"
    )

    fig = draw_figure(summary)

    try:

        for extension in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none",
                "bbox_inches": None
            }

            if extension in ("png", "tiff"):
                options["dpi"] = DPI

            if extension == "tiff":

                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{extension}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
