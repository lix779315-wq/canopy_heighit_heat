
# -*- coding: utf-8 -*-

from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import chi2, f, t



INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_thermal.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\lst_nested_models_submission"
)

HEIGHT_TERMS = ("Hmean", "HSD", "HP90")



def prepare_data():
    df = pd.read_csv(
        INPUT_CSV,
        dtype={"grid_id": str, "city_id": str}
    )

    required = [
        "grid_id", "city_id", "lst", "grdi", "population",
        "built_density", "built_height", "distance_to_center_km",
        "climate", "Cover", *HEIGHT_TERMS,
    ]

    missing = set(required) - set(df.columns)
    if missing:
        raise ValueError(f"输入缺少字段：{sorted(missing)}")

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError("网格ID或城市ID缺失、重复")

    numbers = required[2:]
    df[numbers] = df[numbers].apply(
        pd.to_numeric, errors="coerce"
    )

    if not np.isfinite(df[numbers].to_numpy(float)).all():
        raise ValueError("输入样本包含缺失值或非有限值")

    valid = (
        df.lst.between(-50, 90)
        & df.grdi.between(0, 100)
        & df.population.ge(0)
        & df.built_density.between(0, 1)
        & df.built_height.ge(0)
        & df.distance_to_center_km.ge(0)
        & df.climate.isin(range(1, 31))
        & df.Cover.between(0, 100)
        & df.Hmean.gt(2)
        & df.HSD.ge(0)
        & df.HP90.gt(2)
    )

    if not valid.all():
        raise ValueError("输入样本存在异常值，请核对数据与筛选规则")

    df = df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)

    df["affluence"] = 100 - df.grdi
    df["log_population"] = np.log1p(df.population)
    df["log_building_height"] = np.log1p(df.built_height)

    standardize = {
        "affluence": "ses_z",
        "log_population": "population_z",
        "built_density": "built_density_z",
        "log_building_height": "built_height_z",
        "distance_to_center_km": "distance_z",
    }

    for source, target in standardize.items():
        group = df.groupby("city_id")[source]
        mean = group.transform("mean")
        sd = group.transform(lambda x: x.std(ddof=0))

        df[target] = (
            (df[source] - mean) / sd.where(sd > 0)
        ).fillna(0.0)

    df["LST_anomaly_C"] = (
        df.lst - df.groupby("city_id").lst.transform("mean")
    )

    climate = df.climate.astype(int)

    reference = sorted(
        climate.value_counts()[
            lambda x: x == x.max()
        ].index
    )[0]

    dummies = pd.get_dummies(
        climate, prefix="climate", dtype=float
    )

    dummies = dummies.drop(
        columns=f"climate_{reference}"
    )

    df = pd.concat([df, dummies], axis=1)

    controls = [
        "ses_z",
        "population_z",
        "built_density_z",
        "built_height_z",
        "distance_z",
        *dummies.columns.tolist(),
    ]

    return df, controls


def independent_columns(x):


    basis, keep = [], []

    for j in range(x.shape[1]):
        v = x[:, j].copy()
        norm = np.linalg.norm(v)

        if norm < 1e-10:
            continue

        for _ in range(2):
            for q in basis:
                v -= q * np.dot(q, v)

        length = np.linalg.norm(v)

        if length > 1e-10 * norm:
            keep.append(j)
            basis.append(v / length)

    return keep


def fit_fe(df, terms, name):
    codes, cities = pd.factorize(
        df.city_id, sort=True
    )

    n, g = len(df), len(cities)

    if g < 3:
        raise ValueError("城市数量不足以进行聚类推断")

    counts = np.bincount(codes)

    original_x = df[terms].to_numpy(float)
    y = df.LST_anomaly_C.to_numpy(float)

    sums_x = np.zeros((g, len(terms)))
    np.add.at(sums_x, codes, original_x)

    mean_x = sums_x / counts[:, None]

    mean_y = (
        np.bincount(codes, weights=y, minlength=g)
        / counts
    )

    x_within = original_x - mean_x[codes]
    y_within = y - mean_y[codes]

    selected = independent_columns(x_within)

    kept = [terms[j] for j in selected]
    x = x_within[:, selected]

    p = len(selected)
    residual_df = n - g - p

    if residual_df <= 0:
        raise ValueError(f"{name}没有足够的残差自由度")

    if p:
        beta = np.linalg.lstsq(
            x, y_within, rcond=None
        )[0]

        residuals = y_within - x @ beta

        _, r = np.linalg.qr(x, mode="reduced")

        r_inv = np.linalg.solve(
            r, np.eye(p)
        )

        bread = r_inv @ r_inv.T

        scores = np.zeros((g, p))

        np.add.at(
            scores,
            codes,
            x * residuals[:, None]
        )

        correction = (
            g / (g - 1)
            * (n - 1) / residual_df
        )

        covariance = (
            correction
            * bread
            @ (scores.T @ scores)
            @ bread
        )

    else:
        beta = np.empty(0)
        residuals = y_within
        covariance = np.empty((0, 0))

    rss = float(residuals @ residuals)
    tss = float(y_within @ y_within)

    if rss <= 0 or tss <= 0:
        raise ValueError(f"{name}无法计算R²或BIC")

    k = g + p

    loglik = -n / 2 * (
        np.log(2 * np.pi)
        + 1
        + np.log(rss / n)
    )

    return dict(
        name=name,
        n=n,
        g=g,
        p=p,
        df=residual_df,
        terms=kept,
        beta=beta,
        covariance=covariance,
        rss=rss,
        tss=tss,
        r2=1 - rss / tss,
        adjusted_r2=1 - (
            (rss / residual_df)
            / (tss / (n - g))
        ),
        bic=-2 * loglik + k * np.log(n),
        rmse=np.sqrt(rss / n),
    )



def model_coefficients(model):
    rows = []

    critical = t.ppf(
        0.975, model["g"] - 1
    )

    for i, term in enumerate(model["terms"]):
        beta = model["beta"][i]

        se = np.sqrt(
            max(model["covariance"][i, i], 0.0)
        )

        p_value = (
            2 * t.sf(
                abs(beta / se),
                model["g"] - 1
            )
            if se > 0 else np.nan
        )

        rows.append({
            "model": model["name"],
            "term": term,
            "coefficient": beta,
            "cluster_se_city": se,
            "ci95_low": beta - critical * se,
            "ci95_high": beta + critical * se,
            "p_value": p_value,
        })

    return rows


def compare_models(reduced, full, added):
    if (
        reduced["n"] != full["n"]
        or reduced["g"] != full["g"]
    ):
        raise ValueError("嵌套模型必须使用相同分析样本")

    if any(
        term not in full["terms"]
        for term in added
    ):
        raise ValueError(f"新增变量不可识别：{added}")

    q = full["p"] - reduced["p"]

    if q != len(added):
        raise ValueError("嵌套模型新增变量存在共线性")

    gain = reduced["rss"] - full["rss"]

    if gain < -1e-8 * max(reduced["rss"], 1):
        raise ValueError("嵌套模型残差平方和异常")

    gain = max(0.0, gain)

    classical_f = (
        (gain / q)
        / (full["rss"] / full["df"])
    )

    positions = [
        full["terms"].index(term)
        for term in added
    ]

    beta = full["beta"][positions]

    cov = full["covariance"][
        np.ix_(positions, positions)
    ]

    if np.linalg.matrix_rank(cov) != q:
        raise ValueError("新增变量聚类稳健协方差矩阵不可逆")

    wald = float(
        beta @ np.linalg.solve(cov, beta)
    )

    cluster_f = wald / q

    return {
        "reduced_model": reduced["name"],
        "full_model": full["name"],
        "added_terms": "+".join(added),
        "incremental_R2": (
            full["r2"] - reduced["r2"]
        ),
        "partial_R2": gain / reduced["rss"],
        "BIC_improvement": (
            reduced["bic"] - full["bic"]
        ),
        "classical_F": classical_f,
        "classical_F_p": f.sf(
            classical_f, q, full["df"]
        ),
        "cluster_Wald_chi2": wald,
        "cluster_Wald_p": chi2.sf(wald, q),
        "cluster_F": cluster_f,
        "cluster_F_df1": q,
        "cluster_F_df2": full["g"] - 1,
        "cluster_F_p": f.sf(
            cluster_f, q, full["g"] - 1
        ),
    }


def main():
    df, controls = prepare_data()


    specs = {
        "M0": controls,
        "M1": [*controls, "Cover"],
        "M2": [
            *controls,
            "Cover",
            *HEIGHT_TERMS
        ],
    }

    models = {
        name: fit_fe(df, terms, name)
        for name, terms in specs.items()
    }


    summary = pd.DataFrame([
        {
            "model": model["name"],
            "n_grids": model["n"],
            "n_cities": model["g"],
            "n_parameters": (
                model["g"] + model["p"]
            ),
            "R2_within": model["r2"],
            "adjusted_R2_within": (
                model["adjusted_r2"]
            ),
            "RMSE_C": model["rmse"],
            "BIC": model["bic"],
        }
        for model in models.values()
    ])

    coefficients = pd.DataFrame([
        row
        for model in models.values()
        for row in model_coefficients(model)
    ])

    comparisons = pd.DataFrame([
        compare_models(
            models["M0"],
            models["M1"],
            ["Cover"]
        ),
        compare_models(
            models["M1"],
            models["M2"],
            list(HEIGHT_TERMS)
        ),
        compare_models(
            models["M0"],
            models["M2"],
            ["Cover", *HEIGHT_TERMS]
        ),
    ])

    OUTPUT_DIR.mkdir(
        parents=True, exist_ok=True
    )

    summary.to_csv(
        OUTPUT_DIR / "model_summary.csv",
        index=False,
        encoding="utf-8-sig"
    )

    coefficients.to_csv(
        OUTPUT_DIR / "model_coefficients.csv",
        index=False,
        encoding="utf-8-sig"
    )

    comparisons.to_csv(
        OUTPUT_DIR / "model_comparisons.csv",
        index=False,
        encoding="utf-8-sig"
    )


if __name__ == "__main__":
    main()
