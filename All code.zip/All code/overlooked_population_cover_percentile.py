
# -*- coding: utf-8 -*-


from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


INPUT_CSV = Path(
    r"E:\李鑫论文\result summary\high_heat_screening_submission"
    r"\grid_screening_details.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\high_heat_screening_submission"
)



OUTPUT_NAME = "overlooked_population_cover_percentile"
DPI = 600

EDGES = np.arange(25.0, 105.0, 5.0)

FILL_COLOR = "#E7AE54"
LINE_COLOR = "#E65F00"
REFERENCE_COLOR = "#B5BBC1"
SHADE_COLOR = "#D9DEE5"

FIG_W_IN = 3.504
FIG_H_IN = 3.150

def weighted_median(values, weights):

    order = np.argsort(
        values,
        kind="stable"
    )

    sorted_values = values[order]

    cumulative = np.cumsum(
        weights[order]
    )

    position = np.searchsorted(
        cumulative,
        0.5 * cumulative[-1],
        side="left"
    )

    return float(
        sorted_values[
            min(position, len(sorted_values) - 1)
        ]
    )


def calculate_distribution():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(
            f"未找到09筛查结果：{INPUT_CSV}\n"
            "请先运行09_heat_screening.py。"
        )

    required = {
        "newly_identified",
        "population",
        "Cover_city_percentile"
    }

    data = pd.read_csv(
        INPUT_CSV,
        usecols=lambda name: name in required,
        encoding="utf-8-sig"
    )

    missing = required - set(data.columns)

    if missing:
        raise ValueError(
            f"输入CSV缺少字段：{sorted(missing)}"
        )

    flags = (
        data["newly_identified"]
        .astype("string")
        .str.strip()
        .str.lower()
        .map({
            "true": True,
            "false": False,
            "1": True,
            "0": False,
            "1.0": True,
            "0.0": False
        })
    )

    if flags.isna().any():
        raise ValueError(
            "newly_identified列存在无法识别的布尔值"
        )

    subset = data.loc[
        flags.to_numpy(dtype=bool)
    ].copy()

    if subset.empty:
        raise ValueError(
            "没有newly_identified=True的网格"
        )


    for column in (
        "population",
        "Cover_city_percentile"
    ):

        subset[column] = pd.to_numeric(
            subset[column],
            errors="coerce"
        )

    values = subset[
        "Cover_city_percentile"
    ].to_numpy(dtype=float)

    weights = subset[
        "population"
    ].to_numpy(dtype=float)

    if not (
        np.isfinite(values).all()
        and np.isfinite(weights).all()
    ):
        raise ValueError(
            "人口或覆盖率百分位存在无效值"
        )

    if (
        np.any(weights < 0)
        or np.any(values <= 0)
        or np.any(values > 100)
    ):
        raise ValueError(
            "人口不能为负，Cover百分位必须属于(0,100]"
        )

    positive = weights > 0

    if not positive.any():
        raise ValueError(
            "新增识别人口总数为0"
        )

    values = values[positive]
    weights = weights[positive]

    total_population = float(
        weights.sum()
    )

    median = weighted_median(
        values,
        weights
    )

    bin_population, _ = np.histogram(
        values,
        bins=EDGES,
        weights=weights
    )

    bin_counts, _ = np.histogram(
        values,
        bins=EDGES
    )

    # 分母始终为全部新增识别人口
    shares = (
        bin_population
        / total_population
        * 100.0
    )


    source = pd.DataFrame({
        "percentile_lower": EDGES[:-1].astype(int),
        "percentile_upper": EDGES[1:].astype(int),
        "n_grids": bin_counts,
        "population": bin_population,
        "population_share_pct": shares,
        "population_weighted_median_percentile": median,
        "total_newly_identified_population": total_population
    })

    return source, median



def draw_figure(source, median):

    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],
        "font.size": 7.5,
        "axes.labelsize": 8,
        "axes.linewidth": 0.7,
        "axes.edgecolor": "#60656B",
        "xtick.labelsize": 7,
        "ytick.labelsize": 7,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })

    fig = plt.figure(
        figsize=(
            FIG_W_IN,
            FIG_H_IN
        ),
        facecolor="white"
    )

    ax = fig.add_axes([
        0.16,
        0.15,
        0.805,
        0.835
    ])

    shares = source[
        "population_share_pct"
    ].to_numpy(dtype=float)

    y_max = max(
        17.0,
        float(np.ceil(shares.max() * 1.12))
    )


    ax.axvspan(
        25,
        30,
        color=SHADE_COLOR,
        alpha=0.30,
        zorder=0
    )


    ax.stairs(
        shares,
        EDGES,
        baseline=0,
        fill=True,
        facecolor=FILL_COLOR,
        edgecolor="none",
        zorder=2
    )


    ax.stairs(
        shares,
        EDGES,
        baseline=None,
        color=LINE_COLOR,
        linewidth=0.9,
        zorder=3
    )

    for percentile in (25, 50):

        ax.axvline(
            percentile,
            color=REFERENCE_COLOR,
            linewidth=0.7,
            linestyle=(0, (3, 3)),
            zorder=4
        )


    ax.axvline(
        median,
        color=LINE_COLOR,
        linewidth=0.8,
        zorder=5
    )


    ax.text(
        26,
        y_max - 0.2,
        "P25",
        color="#66707D",
        fontweight="bold",
        va="top"
    )

    ax.text(
        51.2,
        y_max - 0.2,
        "P50",
        color="#66707D",
        fontweight="bold",
        va="top"
    )

    ax.text(
        25.7,
        0.65,
        "P25–P30",
        color="#3C434C",
        fontsize=7,
        va="bottom"
    )

    ax.set_xlim(
        25,
        100
    )

    ax.set_ylim(
        0,
        y_max
    )

    ax.set_xticks([
        25,
        30,
        50,
        75,
        100
    ])

    ax.set_yticks(
        np.arange(
            0,
            y_max + 0.01,
            5
        )
    )

    ax.set_xlabel(
        "Canopy-cover percentile"
    )

    ax.set_ylabel(
        "Population share (%)"
    )

    ax.tick_params(
        direction="out",
        width=0.7,
        length=2.5,
        pad=2
    )

    ax.grid(False)

    return fig


def main():

    source, median = calculate_distribution()

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    source.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_source_data.csv",
        index=False,
        encoding="utf-8-sig"
    )

    fig = draw_figure(
        source,
        median
    )

    try:

        for extension in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none"
            }

            if extension in ("png", "tiff"):
                options["dpi"] = DPI

            if extension == "tiff":
                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{extension}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
