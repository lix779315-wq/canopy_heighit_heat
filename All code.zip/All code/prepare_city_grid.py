# -*- coding: utf-8 -*-


import argparse
import csv
import hashlib
import json
import math
import re
import unicodedata
from pathlib import Path

import fiona
from pyproj import CRS, Transformer
from shapely.geometry import box, mapping, shape
from shapely.ops import transform, unary_union
from shapely.prepared import prep

try:
    from shapely.validation import make_valid
except ImportError:
    make_valid = None


DEFAULT_INPUT = Path(r"E:\李鑫论文\All Cities\AllCities.shp")
DEFAULT_OUTPUT_DIR = DEFAULT_INPUT.parent
DEFAULT_GRID_CRS = "EPSG:6933"
DEFAULT_GRID_SIZE = 1000.0
DEFAULT_ORIGIN_X = 0.0
DEFAULT_ORIGIN_Y = 0.0
DEFAULT_EXPECTED_CITIES = 140


def parse_args():
    p = argparse.ArgumentParser(description="Build an auditable city-aligned 1-km grid")
    p.add_argument("--input", type=Path, default=DEFAULT_INPUT, help="City polygon Shapefile")
    p.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    p.add_argument("--id-field", default=None, help="Existing immutable city ID field")
    p.add_argument("--name-field", default=None, help="City name field")
    p.add_argument("--expected-cities", type=int, default=DEFAULT_EXPECTED_CITIES)
    p.add_argument("--grid-crs", default=DEFAULT_GRID_CRS)
    p.add_argument("--grid-size", type=float, default=DEFAULT_GRID_SIZE)
    p.add_argument("--origin-x", type=float, default=DEFAULT_ORIGIN_X)
    p.add_argument("--origin-y", type=float, default=DEFAULT_ORIGIN_Y)
    p.add_argument("--no-clip", action="store_true", help="Write full squares instead of city-clipped cells")
    p.add_argument("--overwrite", action="store_true", help="Replace existing outputs")
    p.add_argument("--relative-area-tolerance", type=float, default=1e-6)
    return p.parse_args()


def find_field(fields, explicit, candidates):
    lookup = {str(x).casefold(): x for x in fields}
    if explicit is not None:
        key = lookup.get(explicit.casefold())
        if key is None:
            raise ValueError(f"Field not found: {explicit}. Available fields: {fields}")
        return key
    for candidate in candidates:
        if candidate.casefold() in lookup:
            return lookup[candidate.casefold()]
    return None


def fix_polygon(geom):
    """Keep valid, nonempty polygon components; avoid dropping multipolygons."""
    if geom is None or geom.is_empty:
        return None
    if not geom.is_valid:
        geom = make_valid(geom) if make_valid is not None else geom.buffer(0)
    if geom.is_empty:
        return None
    if geom.geom_type in ("Polygon", "MultiPolygon"):
        return geom if geom.area > 0 else None
    if hasattr(geom, "geoms"):
        polygons = [p for g in geom.geoms if (p := fix_polygon(g)) is not None]
        return unary_union(polygons) if polygons else None
    return None


def make_fallback_city_id(name):

    normalized = unicodedata.normalize("NFKC", name).strip().casefold()
    normalized = re.sub(r"\s+", " ", normalized)
    return "N" + hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def shapefile_parts(path):
    sidecar_suffixes = {".shp", ".shx", ".dbf", ".prj", ".cpg", ".qix", ".fix"}
    return [p for p in path.parent.glob(path.stem + ".*")
            if p.suffix.lower() in sidecar_suffixes]


def check_outputs(paths, overwrite):
    found = []
    for p in paths:
        if p.suffix.casefold() == ".shp":
            found.extend(shapefile_parts(p))
        elif p.exists():
            found.append(p)
    if found and not overwrite:
        raise FileExistsError("Output already exists. Use --overwrite if intentional: "
                              + ", ".join(str(x) for x in found))
    if overwrite:
        for p in found:
            p.unlink()


def write_csv(path, fieldnames, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def load_cities(source_path, id_field_arg, name_field_arg, expected_cities):
    cities = []
    with fiona.open(source_path) as src:
        source_crs = src.crs_wkt or src.crs
        if not source_crs:
            raise ValueError("Missing source CRS. Check the input .prj file.")
        source_crs = CRS.from_user_input(source_crs)
        fields = list(src.schema["properties"])
        id_field = find_field(fields, id_field_arg, ("city_id", "cityid"))
        name_field = find_field(fields, name_field_arg,
                                ("city_name", "city", "name", "name_en", "城市名称", "城市"))
        if name_field is None:
            raise ValueError("City name field not found. Pass --name-field FIELD.")

        used_ids = set()
        used_names = set()
        for pos, feature in enumerate(src, start=1):
            attributes = dict(feature["properties"])
            name = str(attributes.get(name_field) or "").strip()
            if not name:
                raise ValueError(f"Empty city name in feature {pos}")
            if len(name.encode("utf-8")) > 254:
                raise ValueError(f"City name exceeds Shapefile width: {name}")

            if id_field is None:
                norm_name = unicodedata.normalize("NFKC", name).strip().casefold()
                if norm_name in used_names:
                    raise ValueError(f"Duplicate city name '{name}'. Provide --id-field "
                                     "using a persistent unique city ID.")
                used_names.add(norm_name)
                city_id = make_fallback_city_id(name)
                id_source = "name_hash"
            else:
                raw_id = attributes.get(id_field)
                city_id = str(raw_id).strip() if raw_id is not None else ""
                id_source = "input_field"
            if not city_id or len(city_id.encode("utf-8")) > 80:
                raise ValueError(f"Invalid city ID at feature {pos}: {city_id!r}")
            if city_id in used_ids:
                raise ValueError(f"Repeated city ID: {city_id}")
            used_ids.add(city_id)

            geom = fix_polygon(shape(feature["geometry"])) if feature["geometry"] else None
            if geom is None:
                raise ValueError(f"No valid polygon for city '{name}'")
            cities.append({"city_id": city_id, "city_name": name,
                           "city_order": pos, "source_fid": str(feature["id"]),
                           "id_source": id_source, "geometry": geom})

    if len(cities) != expected_cities:
        raise ValueError(f"Expected {expected_cities} cities, got {len(cities)}")
    return cities, source_crs


def main():
    args = parse_args()
    if args.grid_size <= 0 or not math.isfinite(args.grid_size):
        raise ValueError("--grid-size must be a finite positive number")
    if args.expected_cities <= 0:
        raise ValueError("--expected-cities must be positive")
    if not (0 < args.relative_area_tolerance < 1):
        raise ValueError("--relative-area-tolerance must be between 0 and 1")
    if not all(map(math.isfinite, (args.origin_x, args.origin_y))):
        raise ValueError("Grid origin must be finite")

    in_path = args.input.expanduser().resolve()
    out_dir = args.output_dir.expanduser().resolve()
    if not in_path.is_file():
        raise FileNotFoundError(in_path)
    out_dir.mkdir(parents=True, exist_ok=True)

    city_out = out_dir / "AllCities_with_city_id.shp"
    grid_out = out_dir / "AllCities_1km_grid_cityid.shp"
    mapping_out = out_dir / "AllCities_city_id_mapping.csv"
    qa_out = out_dir / "AllCities_grid_QA.csv"
    config_out = out_dir / "AllCities_grid_specification.json"
    outputs = [city_out, grid_out, mapping_out, qa_out, config_out]
    if in_path in outputs:
        raise ValueError("Input cannot be one of the output files")
    check_outputs(outputs, args.overwrite)

    grid_crs = CRS.from_user_input(args.grid_crs)
    metre_units = ("metre", "meter", "metres", "meters")
    if not grid_crs.is_projected or not all(
        axis.unit_name.lower() in metre_units for axis in grid_crs.axis_info[:2]
    ):
        raise ValueError("Grid CRS must be projected in metres")
    if grid_crs.to_epsg() != 6933:
        print("WARNING: Verify that this CRS has suitable area properties for your study.")

    cities, source_crs = load_cities(in_path, args.id_field, args.name_field,
                                     args.expected_cities)
    project = Transformer.from_crs(source_crs, grid_crs, always_xy=True).transform

    tokens = {c["city_id"]: hashlib.sha256(c["city_id"].encode("utf-8")).hexdigest()[:14]
              for c in cities}
    if len(set(tokens.values())) != len(tokens):
        raise ValueError("City ID hash collision; increase the hash prefix length")

    write_csv(mapping_out,
              ["city_id", "city_name", "city_order", "source_fid", "id_source"],
              [{key: c[key] for key in ("city_id", "city_name", "city_order", "source_fid", "id_source")}
               for c in cities])

    city_schema = {"geometry": "Polygon", "properties": {
        "city_id": "str:80", "city_name": "str:254", "city_order": "int",
        "source_fid": "str:40"}}
    with fiona.open(city_out, "w", driver="ESRI Shapefile", schema=city_schema,
                    crs_wkt=source_crs.to_wkt(), encoding="UTF-8") as dst:
        for c in cities:
            dst.write({"geometry": mapping(c["geometry"]), "properties": {
                "city_id": c["city_id"], "city_name": c["city_name"],
                "city_order": c["city_order"], "source_fid": c["source_fid"]}})

    grid_schema = {"geometry": "Polygon", "properties": {
        "grid_id": "str:64", "cell_id": "str:40", "city_id": "str:80",
        "city_name": "str:254", "grid_col": "int", "grid_row": "int",
        "area_km2": "float:20.8", "full_km2": "float:20.8",
        "cover_frac": "float:20.8"}}
    area_full = (args.grid_size ** 2) / 1_000_000.0
    qa_rows = []
    total_grids = 0
    with fiona.open(grid_out, "w", driver="ESRI Shapefile", schema=grid_schema,
                    crs_wkt=grid_crs.to_wkt(), encoding="UTF-8") as dst:
        for i, city in enumerate(cities, start=1):
            projected = fix_polygon(transform(project, city["geometry"]))
            if projected is None:
                raise ValueError(f"Projected city is invalid: {city['city_name']}")
            source_area_km2 = projected.area / 1_000_000.0
            prepared = prep(projected)
            parts = [projected] if projected.geom_type == "Polygon" else projected.geoms
            visited = set()
            count = 0
            edge_count = 0
            sum_clip_area_km2 = 0.0
            min_area = float("inf")

            for part in parts:
                minx, miny, maxx, maxy = part.bounds
                c_start = math.floor((minx - args.origin_x) / args.grid_size)
                c_stop = math.ceil((maxx - args.origin_x) / args.grid_size)
                r_start = math.floor((miny - args.origin_y) / args.grid_size)
                r_stop = math.ceil((maxy - args.origin_y) / args.grid_size)
                for col in range(c_start, c_stop):
                    for row in range(r_start, r_stop):
                        if (col, row) in visited:
                            continue
                        visited.add((col, row))
                        x0 = args.origin_x + col * args.grid_size
                        y0 = args.origin_y + row * args.grid_size
                        square = box(x0, y0, x0 + args.grid_size, y0 + args.grid_size)
                        if not prepared.intersects(square):
                            continue
                        clipped = fix_polygon(projected.intersection(square))
                        if clipped is None:
                            continue
                        clip_area = clipped.area / 1_000_000.0
                        if clip_area <= 0:
                            continue
                        fraction = min(1.0, max(0.0, clip_area / area_full))
                        out_geometry = clipped if not args.no_clip else square
                        cell_id = f"R{row}_C{col}"
                        grid_id = f"C{tokens[city['city_id']]}_{cell_id}"
                        if len(grid_id.encode("utf-8")) > 64:
                            raise ValueError(f"grid_id too long: {grid_id}")
                        dst.write({"geometry": mapping(out_geometry), "properties": {
                            "grid_id": grid_id, "cell_id": cell_id,
                            "city_id": city["city_id"], "city_name": city["city_name"],
                            "grid_col": col, "grid_row": row,
                            "area_km2": clip_area, "full_km2": area_full,
                            "cover_frac": fraction}})
                        count += 1
                        sum_clip_area_km2 += clip_area
                        min_area = min(min_area, clip_area)
                        if fraction < 1.0 - 1e-8:
                            edge_count += 1

            if count == 0:
                raise ValueError(f"No grids created for {city['city_name']}")
            err = sum_clip_area_km2 - source_area_km2
            relative_err = abs(err) / source_area_km2
            # Projection and clipping may introduce tiny floating point differences.
            if relative_err > args.relative_area_tolerance:
                raise ValueError(f"Area QA FAILED for {city['city_name']}: "
                                 f"relative error = {relative_err:.8g}")
            qa_rows.append({"city_id": city["city_id"], "city_name": city["city_name"],
                            "city_area_km2": round(source_area_km2, 8),
                            "sum_clip_area_km2": round(sum_clip_area_km2, 8),
                            "area_error_km2": round(err, 8),
                            "relative_area_error": relative_err,
                            "grid_count": count, "edge_grid_count": edge_count,
                            "min_clip_area_km2": round(min_area, 8)})
            total_grids += count
            print(f"[{i:03d}/{len(cities)}] {city['city_name']} | "
                  f"city_id={city['city_id']} | grids={count:,} | "
                  f"edge={edge_count:,} | area_error={relative_err:.2e}")

    write_csv(qa_out,
              ["city_id", "city_name", "city_area_km2", "sum_clip_area_km2",
               "area_error_km2", "relative_area_error", "grid_count",
               "edge_grid_count", "min_clip_area_km2"], qa_rows)
    spec = {
        "input": str(in_path), "source_crs": source_crs.to_string(),
        "grid_crs": grid_crs.to_string(), "grid_size_m": args.grid_size,
        "grid_origin_x_m": args.origin_x, "grid_origin_y_m": args.origin_y,
        "clip_to_city": not args.no_clip, "expected_cities": args.expected_cities,
        "n_cities": len(cities), "n_grids": total_grids,
        "id_field": args.id_field, "name_field": args.name_field,
        "relative_area_tolerance": args.relative_area_tolerance,
        "interpretation": "area_km2 = city intersection within cell; "
                          "cover_frac = area_km2 / full_km2; "
                          "if no-clip, saved shape is the full square but "
                          "area_km2 is still the city intersection."
    }
    config_out.write_text(json.dumps(spec, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nDONE | Cities: {len(cities)} | Grid cells: {total_grids:,}")
    for path in outputs:
        print(f"  {path}")
    print("IMPORTANT: Compare the grid CRS, origin, geometry and city IDs "
          "with the original analysis before treating these outputs as publication-reproducible.")


if __name__ == "__main__":
    main()
