
# -*- coding: utf-8 -*-


from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
from matplotlib.cm import ScalarMappable
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.ticker import MultipleLocator

import numpy as np
import pandas as pd

from scipy.linalg import qr
from scipy.stats import t



INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_structure_ses.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\cover_adjusted_height_index"
)



OUTPUT_NAME = "regional_vertical_ses_slopes"
DPI = 600
RANDOM_SEED = 20261023

HEIGHT_METRICS = ("Hmean", "HSD", "HP90")

REGIONS = (
    "Americas",
    "Europe",
    "Asia",
    "Oceania",
    "Africa"
)

REGION_MAP = {
    "North America": "Americas",
    "South America": "Americas",
    "Latin America": "Americas",
    "Central America": "Americas",
    "Caribbean": "Americas",
    "Americas": "Americas",
    "East Asia": "Asia",
    "South Asia": "Asia",
    "Southeast Asia": "Asia",
    "Middle East": "Asia",
    "West Asia": "Asia",
    "Middle Asia": "Asia",
    "Central Asia": "Asia",
    "Asia": "Asia",
    "Europe": "Europe",
    "Africa": "Africa",
    "Oceania": "Oceania"
}

# 主坐标框尺寸，单位mm
AX_W_MM = 80.439
AX_H_MM = 62.226

FIG_W_MM = 116.0
FIG_H_MM = 86.0

AX_LEFT_MM = 25.0
AX_BOTTOM_MM = 14.0



def read_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(INPUT_CSV)

    df = pd.read_csv(
        INPUT_CSV,
        dtype={"grid_id": str, "city_id": str},
        encoding="utf-8-sig"
    )

    fields = {
        "grid_id", "city_id", "grdi",
        "population", "built_density",
        "built_height", "distance_to_center_km",
        "climate", "Cover", *HEIGHT_METRICS
    }

    missing = fields - set(df.columns)

    if missing:
        raise ValueError(
            f"缺少分析字段：{sorted(missing)}"
        )

    geography_col = next(
        (
            col for col in ("continent", "region", "Region")
            if col in df.columns
        ),
        None
    )

    if geography_col is None:
        raise ValueError(
            "输入CSV需要continent或region列，"
            "用于识别五大洲。"
        )

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError(
            "grid_id/city_id缺失或重复"
        )

    df["continent"] = (
        df[geography_col]
        .astype("string")
        .str.strip()
        .replace(REGION_MAP)
    )

    if (
        df.continent.isna().any()
        or not df.continent.isin(REGIONS).all()
    ):
        raise ValueError(
            "存在无法识别的大洲"
        )

    if (
        df.groupby("city_id")
        .continent.nunique()
        .gt(1).any()
    ):
        raise ValueError(
            "同一城市对应多个大洲"
        )

    numeric = sorted(
        fields - {"grid_id", "city_id"}
    )

    df[numeric] = df[numeric].apply(
        pd.to_numeric,
        errors="coerce"
    )

    if not np.isfinite(
        df[numeric].to_numpy(float)
    ).all():
        raise ValueError(
            "分析变量存在无效数值"
        )

    valid = (
        df.grdi.between(0, 100).all()
        and df.population.ge(0).all()
        and df.built_density.between(0, 1).all()
        and df.built_height.ge(0).all()
        and df.distance_to_center_km.ge(0).all()
        and df.Cover.between(0, 100).all()
        and df.Hmean.gt(2).all()
        and df.HSD.ge(0).all()
        and df.HP90.gt(2).all()
        and np.isclose(
            df.climate,
            np.round(df.climate)
        ).all()
    )

    if not valid:
        raise ValueError(
            "部分变量超出有效范围"
        )

    return df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)



def calculate_cover_adjusted_index(df):

    df = df.copy()

    df["ses_affluence"] = 100 - df.grdi
    df["log_population"] = np.log1p(df.population)
    df["log_building_height"] = np.log1p(df.built_height)

    variables = {
        "Cover": "Cover_z",
        "Hmean": "Hmean_z",
        "HSD": "HSD_z",
        "HP90": "HP90_z",
        "ses_affluence": "ses_z",
        "log_population": "population_z",
        "built_density": "density_z",
        "log_building_height": "building_z",
        "distance_to_center_km": "distance_z"
    }

    for source, name in variables.items():

        group = df.groupby("city_id")[source]
        mean = group.transform("mean")
        sd = group.transform(
            lambda x: x.std(ddof=0)
        )

        df[name] = (
            (df[source] - mean)
            / sd.where(sd > 0)
        ).fillna(0.0)

    terms = ["Cover_z"]

    knots = np.quantile(
        df.Cover_z,
        [0.25, 0.50, 0.75]
    )

    for label, knot in zip(
        ("25", "50", "75"),
        knots
    ):

        name = f"cover_hinge_{label}"
        df[name] = np.maximum(
            df.Cover_z - knot,
            0
        )
        terms.append(name)

    # 气候类别
    climate = df.climate.astype(int)
    reference = climate.value_counts().idxmax()

    dummy = pd.get_dummies(
        climate,
        prefix="climate",
        dtype=float
    )

    dummy = dummy.drop(
        columns=f"climate_{reference}"
    )

    df = pd.concat([df, dummy], axis=1)

    terms += [
        "population_z",
        "density_z",
        "building_z",
        "distance_z",
        *dummy.columns
    ]

    codes, cities = pd.factorize(
        df.city_id,
        sort=True
    )

    x = df[terms].to_numpy(float)
    y = df[
        [f"{v}_z" for v in HEIGHT_METRICS]
    ].to_numpy(float)

    for i in range(len(cities)):

        mask = codes == i

        x[mask] -= x[mask].mean(axis=0)
        y[mask] -= y[mask].mean(axis=0)

    _, r, pivot = qr(
        x,
        mode="economic",
        pivoting=True
    )

    diagonal = np.abs(np.diag(r))

    tolerance = (
        max(x.shape)
        * np.finfo(float).eps
        * diagonal.max(initial=0)
    )

    rank = int(
        np.sum(diagonal > tolerance)
    )

    chosen = np.sort(pivot[:rank])

    if (
        len(chosen) == 0
        or "Cover_z" not in [terms[i] for i in chosen]
    ):
        raise ValueError(
            "Cover调整模型无法识别Cover系数"
        )

    beta = np.linalg.lstsq(
        x[:, chosen],
        y,
        rcond=None
    )[0]

    residuals = y - x[:, chosen] @ beta

    df["CoverAdjustedHeightIndex"] = (
        residuals.mean(axis=1)
    )

    return df



def city_slopes(df):

    records = []

    for city_id, city in df.groupby(
        "city_id",
        sort=True
    ):

        xx = city.ses_z.to_numpy(float)

        if (
            len(xx) < 5
            or np.unique(xx).size < 2
        ):
            continue

        design = np.column_stack([
            np.ones(len(xx)),
            xx
        ])

        inverse = np.linalg.inv(
            design.T @ design
        )

        leverage = np.einsum(
            "ij,jk,ik->i",
            design,
            inverse,
            design
        )

        if np.any(1 - leverage <= 1e-10):
            continue

        yy = (
            city.CoverAdjustedHeightIndex
            .to_numpy(float)
        )

        beta = np.linalg.lstsq(
            design,
            yy,
            rcond=None
        )[0]

        residual = yy - design @ beta
        adjusted = residual / (1 - leverage)

        covariance = (
            inverse
            @ (
                design.T
                @ (
                    design
                    * adjusted[:, None] ** 2
                )
            )
            @ inverse
        )

        variance = float(covariance[1, 1])

        if (
            not np.isfinite(variance)
            or variance <= 0
        ):
            continue

        se = np.sqrt(variance)
        critical = t.ppf(0.975, len(xx) - 2)

        row = {
            "city_id": city_id,
            "continent": str(city.continent.iloc[0]),
            "n_grids": len(xx),
            "slope": float(beta[1]),
            "se_HC3": float(se),
            "ci95_low": float(beta[1] - critical * se),
            "ci95_high": float(beta[1] + critical * se)
        }

        if "city_name" in df.columns:
            row["city_name"] = str(
                city.city_name.iloc[0]
            )

        records.append(row)

    if not records:
        raise ValueError(
            "没有可估计SES斜率的城市"
        )

    return pd.DataFrame(records)



def regional_summary(slopes):

    records = []

    for region in REGIONS:

        values = slopes.loc[
            slopes.continent.eq(region),
            "slope"
        ].to_numpy(float)

        if len(values) < 2:
            raise ValueError(
                f"{region}有效城市不足2座"
            )

        p5, q1, median, q3, p95 = np.quantile(
            values,
            [0.05, 0.25, 0.50, 0.75, 0.95]
        )

        records.append({
            "region": region,
            "n_cities": len(values),
            "mean": float(np.mean(values)),
            "median": float(median),
            "q1": float(q1),
            "q3": float(q3),
            "p5": float(p5),
            "p95": float(p95),
            "proportion_positive": float(
                np.mean(values > 0)
            )
        })

    return pd.DataFrame(records)



def draw_figure(slopes, summary):

    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],
        "font.size": 9,
        "axes.labelsize": 9.5,
        "xtick.labelsize": 8.7,
        "ytick.labelsize": 9.5,
        "axes.linewidth": 0.7,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })

    fig = plt.figure(
        figsize=(
            FIG_W_MM / 25.4,
            FIG_H_MM / 25.4
        )
    )

    ax = fig.add_axes([
        AX_LEFT_MM / FIG_W_MM,
        AX_BOTTOM_MM / FIG_H_MM,
        AX_W_MM / FIG_W_MM,
        AX_H_MM / FIG_H_MM
    ])

    # 红—灰—绿渐变
    cmap = LinearSegmentedColormap.from_list(
        "SES_slope",
        [
            "#A92331",
            "#C16E70",
            "#A8B1AD",
            "#599777",
            "#176942"
        ],
        N=256
    )

    norm = TwoSlopeNorm(
        vmin=-0.6,
        vcenter=0,
        vmax=0.6
    )

    positions = np.arange(
        len(REGIONS),
        0,
        -1,
        dtype=float
    )

    # 零值参考线
    ax.axvline(
        0,
        color="#BFC3C2",
        linewidth=0.75,
        linestyle=(0, (3, 3)),
        zorder=1
    )


    boxes = [
        {
            "label": row.region,
            "med": row.median,
            "q1": row.q1,
            "q3": row.q3,
            "whislo": row.p5,
            "whishi": row.p95,
            "fliers": []
        }
        for row in summary.itertuples(index=False)
    ]

    bp = ax.bxp(
        boxes,
        positions=positions,
        widths=0.39,
        vert=False,
        patch_artist=True,
        showfliers=False,
        manage_ticks=False,
        zorder=2
    )

    for artist in bp["boxes"]:
        artist.set(
            facecolor="#E0E4E2",
            alpha=0.43,
            edgecolor="#8F9994",
            linewidth=0.75
        )

    for artist in (
        *bp["whiskers"],
        *bp["caps"]
    ):
        artist.set(
            color="#A4ACA8",
            linewidth=0.8
        )

    for artist in bp["medians"]:
        artist.set(
            color="#63726C",
            linewidth=1.0
        )


    rng = np.random.default_rng(RANDOM_SEED)

    for region, ypos in zip(
        REGIONS,
        positions
    ):

        city = slopes.loc[
            slopes.continent.eq(region)
        ].sort_values("city_id")

        x = city.slope.to_numpy(float)

        jitter = rng.uniform(
            -0.145,
            0.145,
            size=len(x)
        )

        ax.scatter(
            x,
            ypos + jitter,
            s=15,
            c=np.clip(x, -0.6, 0.6),
            cmap=cmap,
            norm=norm,
            edgecolors="none",
            alpha=0.93,
            zorder=5
        )


    lower = min(
        -0.70,
        float(slopes.slope.min()) - 0.03
    )

    upper = max(
        0.60,
        float(slopes.slope.max()) + 0.03
    )

    ax.set_xlim(lower, upper)
    ax.set_ylim(0.4, 5.55)

    ax.set_yticks(
        positions,
        REGIONS
    )

    ax.set_xlabel(
        "City-specific SES slope",
        labelpad=5
    )

    if lower >= -0.75 and upper <= 0.65:
        ax.set_xticks(
            [-0.6, -0.3, 0, 0.3, 0.6]
        )
    else:
        ax.xaxis.set_major_locator(
            MultipleLocator(0.3)
        )

    ax.tick_params(
        axis="both",
        direction="out",
        length=3,
        width=0.7,
        color="#303030",
        pad=3
    )

    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_color("#303030")
        spine.set_linewidth(0.7)

    ax.grid(False)


    cax = ax.inset_axes([
        0.045,
        0.066,
        0.35,
        0.045
    ])

    sm = ScalarMappable(
        cmap=cmap,
        norm=norm
    )

    sm.set_array([])

    colorbar = fig.colorbar(
        sm,
        cax=cax,
        orientation="horizontal",
        ticks=[-0.6, -0.3, 0, 0.3, 0.6]
    )

    colorbar.outline.set_visible(False)

    colorbar.ax.tick_params(
        labelsize=6.5,
        width=0.5,
        length=2,
        pad=1
    )

    ax.text(
        0.045,
        0.135,
        "SES slope",
        transform=ax.transAxes,
        fontsize=8,
        ha="left",
        va="bottom",
        color="#3A3A3A"
    )

    return fig



def main():

    df = read_data()

    df = calculate_cover_adjusted_index(df)

    slopes = city_slopes(df)

    summary = regional_summary(slopes)

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    slopes.to_csv(
        OUTPUT_DIR / f"{OUTPUT_NAME}_city_slopes.csv",
        index=False,
        encoding="utf-8-sig"
    )

    summary.to_csv(
        OUTPUT_DIR / f"{OUTPUT_NAME}_regional_summary.csv",
        index=False,
        encoding="utf-8-sig"
    )

    fig = draw_figure(slopes, summary)

    try:

        for ext in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none"
            }

            if ext in ("png", "tiff"):
                options["dpi"] = DPI

            if ext == "tiff":
                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR / f"{OUTPUT_NAME}.{ext}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
