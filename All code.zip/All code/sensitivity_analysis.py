# -*- coding: utf-8 -*-


import importlib
import tempfile
from contextlib import ExitStack
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd
import rasterio
from pyproj import Geod, Transformer
from scipy.stats import norm

SCRIPT_DIR = Path(__file__).resolve().parent
SCREENING_CSV = Path(r"E:\李鑫论文\result summary\high_heat_screening_submission\grid_screening_details.csv")
STRUCTURE_CSV = Path(r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_structure_ses.csv")
THERMAL_CSV = Path(r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_thermal.csv")
GRID_SHP = Path(r"E:\李鑫论文\All Cities\AllCities_1km_grid_cityid.shp")
OUTPUT_DIR = Path(r"E:\李鑫论文\results\sensitivity_submission")

N_BOOT = 2000
SEED = 20261023
HEIGHTS = (11, 12, 13, 14, 15)
HEATS = (0.80, 0.85, 0.90)
DEFICITS = (0.20, 0.25, 0.50)
COVERS = (0.20, 0.25, 0.50)
COVER_GROUPS = ("none", "city_cover_quintiles", "fixed_cover_strata")
SCENARIOS = ("Height_only", "Cover_only", "Joint")

canopy02 = importlib.import_module("02_calculate_canopy_metrics")
cov03 = importlib.import_module("03_prepare_covariates")
ses05 = importlib.import_module("05_SES_canopy_models")
upper08 = importlib.import_module("08_upper_canopy_threshold")
screen09 = importlib.import_module("09_heat_screening")
cf10 = importlib.import_module("10_canopy_counterfactual")


def save(df, filename):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    df.to_csv(OUTPUT_DIR / filename, index=False, encoding="utf-8-sig")


def read_data(path):
    df = pd.read_csv(path, dtype={"grid_id": str, "city_id": str})
    if df[["grid_id", "city_id"]].isna().any().any() or df.grid_id.duplicated().any():
        raise ValueError(f"网格ID缺失/重复：{path}")
    return df


def city_bootstrap(cities):
    rng = np.random.default_rng(SEED)
    n = len(cities)
    return rng.multinomial(n, np.ones(n) / n, size=N_BOOT)


def interval(values):
    values = np.asarray(values, float)
    values = values[np.isfinite(values)]
    if len(values) < max(100, int(N_BOOT * 0.8)):
        return np.nan, np.nan, len(values)
    a, b = np.percentile(values, [2.5, 97.5])
    return float(a), float(b), len(values)


def within_city_residual(df, outcome):

    x = screen09.restricted_cubic_spline(df.Cover.to_numpy(float))
    y = df[outcome].to_numpy(float)
    codes, city = pd.factorize(df.city_id, sort=True)
    count = np.bincount(codes)
    sx = np.zeros((len(city), x.shape[1]))
    np.add.at(sx, codes, x)
    mx = sx / count[:, None]
    my = np.bincount(codes, weights=y) / count
    xx, yy = x - mx[codes], y - my[codes]
    beta, _, rank, _ = np.linalg.lstsq(xx, yy, rcond=None)
    if rank != x.shape[1]:
        raise ValueError(f"{outcome} 的Cover样条不满秩")
    return yy - xx @ beta


def cases_screening():
    main = dict(height=12, heat_q=.80, deficit_q=.25,
                cover_q=.25, group="none")
    cases = [("primary", main)]
    sweeps = {"height": HEIGHTS, "heat_q": HEATS, "deficit_q": DEFICITS,
              "cover_q": COVERS, "group": COVER_GROUPS}
    for key, values in sweeps.items():
        for v in values:
            if v != main[key]:
                cases.append((f"{key}_{v}", {**main, key: v}))
    return cases


def screen_flags(df, residual, spec):
    temp = pd.DataFrame({"city_id": df.city_id, "Cover": df.Cover,
                         "lst": df.lst, "residual": residual})
    c = temp.groupby("city_id")
    anomaly = temp.lst - c.lst.transform("mean")
    high = anomaly.gt(anomaly.groupby(temp.city_id).transform(
        lambda x: x.quantile(spec["heat_q"]))).to_numpy()
    low = temp.Cover.lt(c.Cover.transform(
        lambda x: x.quantile(spec["cover_q"]))).to_numpy()
    if spec["group"] == "none":
        group = pd.Series("all", index=df.index)
    elif spec["group"] == "city_cover_quintiles":
        group = np.ceil(c.Cover.rank(pct=True, method="average") * 5).clip(1, 5).astype(str)
    else:
        group = pd.cut(temp.Cover, [0, 10, 20, 30, 100],
                       labels=["0-10", "10-20", "20-30", ">30"],
                       include_lowest=True).astype("string")
    cutoff = temp.groupby([temp.city_id, group], observed=True).residual.transform(
        lambda x: x.quantile(spec["deficit_q"]))
    height = high & temp.residual.le(cutoff).to_numpy()
    cover = high & low
    return {"high_heat": high, "cover_only": cover,
            "height_informed": height, "newly_identified": height & ~cover}


def screening_sensitivity(df, multiplicities, cities):
    city_codes = df.city_id.map({c: i for i, c in enumerate(cities)}).to_numpy(int)
    pop = df.population.to_numpy(float)
    rank = df.groupby("city_id").Cover.rank(pct=True, method="average").to_numpy() * 100
    residual = {h: within_city_residual(df, f"UpperCover{h}") for h in HEIGHTS}
    results = []
    primary = None
    for name, spec in cases_screening():
        flags = screen_flags(df, residual[spec["height"]], spec)
        if name == "primary":
            primary = flags
            if "newly_identified" in df.columns:
                parsed = df.newly_identified.astype(str).str.lower().isin(["true", "1", "1.0"])
                if not np.array_equal(parsed.to_numpy(), flags["newly_identified"]):
                    raise ValueError("主筛查与09输出不一致，请检查筛查参数或样本")
        counts = np.zeros((len(cities), 4))
        for j, key in enumerate(("high_heat", "height_informed", "newly_identified")):
            np.add.at(counts[:, j], city_codes, pop * flags[key])
        np.add.at(counts[:, 3], city_codes,
                  pop * flags["newly_identified"] * (rank > 50))
        point, sampled = counts.sum(axis=0), multiplicities @ counts
        tests = {
            "newly_identified_population": (point[2], sampled[:, 2]),
            "fraction_of_high_heat": (point[2] / point[0] if point[0] else np.nan,
                                     sampled[:, 2] / np.where(sampled[:, 0] > 0, sampled[:, 0], np.nan)),
            "omission_fraction_of_height_informed": (point[2] / point[1] if point[1] else np.nan,
                                                      sampled[:, 2] / np.where(sampled[:, 1] > 0, sampled[:, 1], np.nan)),
            "fraction_above_cover_P50": (point[3] / point[2] if point[2] else np.nan,
                                         sampled[:, 3] / np.where(sampled[:, 2] > 0, sampled[:, 2], np.nan)),
        }
        for metric, (value, draws) in tests.items():
            lo, hi, n = interval(draws)
            results.append({"case": name, **spec, "statistic": metric,
                            "estimate": value, "ci95_low": lo, "ci95_high": hi,
                            "n_valid_bootstrap": n,
                            "n_newly_identified_grids": int(flags["newly_identified"].sum())})
    return pd.DataFrame(results), primary


def conditional_stats(cover, tall, query, target_q):

    if len(cover) < 20 or query < cover.min() - 1e-8 or query > cover.max() + 1e-8:
        return np.nan, np.nan, np.nan
    k = min(len(cover), max(20, int(np.ceil(.10 * len(cover)))))
    distance = np.abs(cover - query)
    radius = np.partition(distance, k - 1)[k - 1]
    sub = tall[distance <= radius + 1e-8]
    target, lower, upper = np.quantile(sub, [target_q, .025, .975])
    return float(target), float(lower), float(upper)


def cases_counterfactual():
    result = [(f"CoverP{int(q*100)}_TallP{int(t*100)}", "conditional", q, t)
              for q in (.65, .75, .85) for t in (.50, .75)]
    return result + [("fixed_5pp", "fixed", 5., .50),
                     ("fixed_10pp", "fixed", 10., .50)]


def counterfactual_sensitivity(df, controls, flags, multiplicities, cities):

    model = cf10.fit_model(df, controls)
    targets = df.loc[flags["newly_identified"]].copy().reset_index(drop=True)
    if targets.empty:
        raise ValueError("没有新增识别网格")
    obs_c = targets.Cover.to_numpy(float)
    obs_t = targets.TallShare12.to_numpy(float)
    obs_basis = cf10.cover_spline(obs_c, model["knots"])
    target_codes = targets.city_id.map({c: i for i, c in enumerate(cities)}).to_numpy(int)
    population = targets.population.to_numpy(float)
    city_data = {cid: (s.Cover.to_numpy(float), s.TallShare12.to_numpy(float))
                 for cid, s in df.groupby("city_id")}
    cover_terms = [model["terms"].index(t) for t in model["cover_terms"]]
    tall_term = model["terms"].index("TallShare12")
    designs = []
    for name, kind, cover_q, tall_q in cases_counterfactual():
        cf_c = np.zeros(len(targets))
        h_t, j_t = np.full((2, len(targets)), np.nan)
        obs_lo, obs_hi = np.full((2, len(targets)), np.nan)
        cf_lo, cf_hi = np.full((2, len(targets)), np.nan)
        for cid, positions in targets.groupby("city_id").indices.items():
            c, tall = city_data[cid]
            pos = np.asarray(positions)
            if kind == "conditional":
                cf_c[pos] = np.maximum(obs_c[pos], np.quantile(c, cover_q))
            else:
                cf_c[pos] = np.minimum(100., obs_c[pos] + cover_q)
            queries = np.unique(np.r_[obs_c[pos], cf_c[pos]])
            stats = np.array([conditional_stats(c, tall, v, tall_q) for v in queries])
            s0 = stats[np.searchsorted(queries, obs_c[pos])]
            s1 = stats[np.searchsorted(queries, cf_c[pos])]
            obs_lo[pos], obs_hi[pos] = s0[:, 1], s0[:, 2]
            cf_lo[pos], cf_hi[pos] = s1[:, 1], s1[:, 2]
            if kind == "conditional":
                h_t[pos] = np.maximum(obs_t[pos], s0[:, 0])
                j_t[pos] = np.maximum(obs_t[pos], s1[:, 0])
            else:
                h_t[pos] = np.minimum(100., obs_t[pos] + cover_q)
                j_t[pos] = h_t[pos]

        def within(v, low, high):
            return (np.isfinite(v) & np.isfinite(low) & np.isfinite(high)
                    & (v >= low - 1e-8) & (v <= high + 1e-8))

        support = (within(obs_t, obs_lo, obs_hi)
                   & within(h_t, obs_lo, obs_hi)
                   & within(obs_t, cf_lo, cf_hi)
                   & within(j_t, cf_lo, cf_hi))
        differences = {}
        for scenario, changed_c, changed_t in (
            ("Height_only", obs_c, h_t), ("Cover_only", cf_c, obs_t),
            ("Joint", cf_c, j_t)
        ):
            delta = np.zeros((len(targets), len(model["beta"])))
            delta[:, cover_terms] = cf10.cover_spline(changed_c, model["knots"]) - obs_basis
            delta[:, tall_term] = changed_t - obs_t
            differences[scenario] = delta
        designs.append((name, support, differences))

    across = np.logical_and.reduce([x[1] for x in designs])
    ncity, p = len(cities), len(model["beta"])
    records = []
    for name, support, differences in designs:
        for label, kept in (("case_specific", support), ("shared_all_cases", across)):
            city_pop = np.bincount(target_codes[kept], weights=population[kept], minlength=ncity)
            for scenario, delta in differences.items():
                weighted = np.zeros((ncity, p))
                np.add.at(weighted, target_codes[kept], delta[kept] * population[kept, None])
                records.append((name, label, scenario, int(kept.sum()), city_pop, weighted))

    beta0 = model["beta"]
    estimates = np.full((N_BOOT, len(records)), np.nan)
    for i, mult in enumerate(multiplicities):
        aa = np.einsum("g,gij->ij", mult, model["a"])
        bb = np.einsum("g,gi->i", mult, model["b"])
        beta = np.linalg.lstsq(aa, bb, rcond=None)[0]
        for j, (_, _, _, _, city_pop, weighted) in enumerate(records):
            den = mult @ city_pop
            if den <= 0:
                continue
            contrast = (mult @ weighted) / den
            projection = np.linalg.lstsq(aa, contrast, rcond=None)[0]
            if np.allclose(aa @ projection, contrast, atol=1e-6, rtol=1e-6):
                estimates[i, j] = contrast @ beta

    rows = []
    for j, (name, sample, scenario, n_grids, cp, weighted) in enumerate(records):
        total = cp.sum()
        effect = float(weighted.sum(axis=0) @ beta0 / total) if total > 0 else np.nan
        lo, hi, n = interval(estimates[:, j])
        rows.append({"case": name, "scenario": scenario, "support_sample": sample,
                     "n_supported_grids": n_grids, "supported_population": total,
                     "population_weighted_delta_LST_C": effect,
                     "ci95_low": lo, "ci95_high": hi, "n_valid_bootstrap": n})
    return pd.DataFrame(rows)


def scale_sample(frame):

    keys = ["grdi", "population", "built_density", "built_height", "climate",
            "distance_to_center_km", "Cover", "Hmean", "HSD", "HP90",
            "TallShare12", "UpperCover12", "lst"]
    for key in keys:
        if key not in frame:
            raise ValueError(f"缺少字段：{key}")
        frame[key] = pd.to_numeric(frame[key], errors="coerce")
    good = (frame[[k for k in keys if k != "lst"]].notna().all(axis=1)
            & frame.grdi.between(0, 100) & frame.population.ge(0)
            & frame.built_density.between(cov03.MIN_BUILT_DENSITY, 1)
            & frame.built_height.ge(0) & frame.climate.notna()
            & frame.distance_to_center_km.ge(0) & frame.Cover.between(0, 100)
            & frame.Hmean.gt(2) & frame.HSD.ge(0) & frame.HP90.gt(2)
            & frame.TallShare12.between(0, 100)
            & frame.UpperCover12.between(0, 100)
            & frame.UpperCover12.le(frame.Cover + 1e-6))
    if cov03.REQUIRE_POSITIVE_POPULATION:
        good &= frame.population.gt(0)
    if cov03.ALLOWED_SMOD_CODES is not None:
        if "smod" not in frame:
            raise ValueError("03使用SMOD筛选，但粗网格缺少SMOD")
        good &= frame.smod.isin(cov03.ALLOWED_SMOD_CODES)
    return frame.loc[good].copy(), frame.loc[good & frame.lst.between(-50, 90)].copy()


def coarse_samples():

    grids = gpd.read_file(GRID_SHP)
    needed = {"grid_id", "city_id", "grid_col", "grid_row", "geometry"}
    if not needed.issubset(grids.columns) or grids.crs is None:
        raise ValueError("1 km网格必须包含grid_id、city_id、grid_col、grid_row和坐标系")
    grids = grids[list(needed)].to_crs("EPSG:6933")
    centers = cov03.load_city_centers()
    geod = Geod(ellps="WGS84")
    tiles = canopy02.load_tiles()
    results = {}
    with tempfile.TemporaryDirectory() as temp, ExitStack() as stack:
        vrt = Path(temp) / "canopy_1m.vrt"
        canopy02.create_vrt(tiles, vrt)
        height = stack.enter_context(rasterio.open(vrt))
        sources = {}
        for variable, (path, method) in cov03.RASTERS.items():
            src = stack.enter_context(rasterio.open(path))
            project = Transformer.from_crs("EPSG:6933", src.crs, always_xy=True).transform
            sources[variable] = (src, project, method)
        height_project = Transformer.from_crs("EPSG:6933", height.crs, always_xy=True).transform
        for scale in (2, 3):
            g = grids.copy()
            g["coarse_col"] = np.floor_divide(g.grid_col.astype(int), scale)
            g["coarse_row"] = np.floor_divide(g.grid_row.astype(int), scale)
            coarse = g.dissolve(by=["city_id", "coarse_col", "coarse_row"], as_index=False)
            lonlat = gpd.GeoSeries(coarse.geometry.centroid, crs=g.crs).to_crs(4326)
            rows = []
            for index, feature in coarse.iterrows():
                cid = str(feature.city_id)
                geom = feature.geometry
                x, y = lonlat.iloc[index].x, lonlat.iloc[index].y
                _, _, dist = geod.inv(*centers[cid], x, y)
                heights, _ = canopy02.get_grid_heights(height, geom, height_project)
                if not len(heights):
                    continue
                canopy = heights[heights > 2]
                m, n = len(canopy), len(heights)
                upper_count = int((heights > 12).sum())
                row = {"city_id": cid,
                       "grid_id": f"{cid}_{scale}km_R{feature.coarse_row}_C{feature.coarse_col}",
                       "Cover": 100 * m / n,
                       "Hmean": float(canopy.mean()) if m else np.nan,
                       "HSD": float(canopy.std(ddof=0)) if m else np.nan,
                       "HP90": float(np.percentile(canopy, 90)) if m else np.nan,
                       "TallShare12": 100 * upper_count / m if m else np.nan,
                       "UpperCover12": 100 * upper_count / n,
                       "distance_to_center_km": dist / 1000}
                for variable, (src, project, method) in sources.items():
                    row[variable] = cov03.zonal_value(src, geom, project, variable, method)
                rows.append(row)
            results[scale] = pd.DataFrame(rows)
    return results


def model_data(df):
    df = df.sort_values(["city_id", "grid_id"]).reset_index(drop=True).copy()
    df = df.drop(columns=[c for c in df if c.startswith("climate_")], errors="ignore")
    df["ses_affluence"] = 100 - df.grdi
    df["log_population"] = np.log1p(df.population)
    df["log_building"] = np.log1p(df.built_height)
    names = {"ses_affluence": "ses_z", "log_population": "population_z",
             "built_density": "density_z", "log_building": "building_z",
             "distance_to_center_km": "distance_z", "Cover": "Cover_z",
             "Hmean": "Hmean_z", "HP90": "HP90_z"}
    for orig, target in names.items():
        group = df.groupby("city_id")[orig]
        sd = group.transform(lambda s: s.std(ddof=0))
        df[target] = ((df[orig] - group.transform("mean")) / sd.where(sd > 0)).fillna(0.)
    df["LST_anomaly_C"] = df.lst - df.groupby("city_id").lst.transform("mean")
    codes = pd.get_dummies(df.climate.astype(int), prefix="climate", dtype=float)
    codes = codes.drop(columns=f"climate_{int(df.climate.mode().min())}")
    df = pd.concat([df, codes], axis=1)
    controls = ["ses_z", "population_z", "density_z", "building_z", "distance_z", *codes.columns]
    return df, controls


def city_meta(thermal, controls):
    result = upper08.city_coefficients(thermal, controls)
    eligible = result.loc[result.eligible]
    if len(eligible) < 3:
        return np.nan, np.nan, np.nan, len(eligible)
    summary = upper08.meta_analysis(result).iloc[0]
    return (summary.pooled_UC12_coefficient, summary.ci95_low,
            summary.ci95_high, len(eligible))


def spatial_sensitivity(struct_1km, thermal_1km, coarse, multiplicities, cities):
    results = []
    lookup = {str(cid): i for i, cid in enumerate(cities)}
    for scale in (1, 2, 3):
        if scale == 1:
            struct, thermal = struct_1km, thermal_1km
        else:
            struct, thermal = scale_sample(coarse[scale])
        if struct.empty or thermal.empty:
            raise ValueError(f"{scale} km筛选后没有有效样本")
        struct, ctr_s = model_data(struct)
        thermal, ctr_t = model_data(thermal)
        xx = (struct.Cover - struct.groupby("city_id").Cover.transform("mean")).to_numpy()
        yy = (struct.Hmean - struct.groupby("city_id").Hmean.transform("mean")).to_numpy()
        ids = struct.city_id.map(lookup).to_numpy(int)
        moments = np.zeros((len(cities), 3))
        np.add.at(moments[:, 0], ids, xx * xx)
        np.add.at(moments[:, 1], ids, yy * yy)
        np.add.at(moments[:, 2], ids, xx * yy)
        summed = moments.sum(axis=0)
        estimate = summed[2] / np.sqrt(summed[0] * summed[1])
        boot = multiplicities @ moments
        draws = boot[:, 2] / np.sqrt(boot[:, 0] * boot[:, 1])
        lo, hi, n = interval(draws)
        results.append({"scale_km": scale, "analysis": "within_city_Cover_Hmean_Pearson",
                        "estimate": estimate, "ci95_low": lo, "ci95_high": hi,
                        "n_grids": len(struct), "n_cities": struct.city_id.nunique(),
                        "n_valid_bootstrap": n})
        knots = np.quantile(struct.Cover_z, [.25, .50, .75])
        for j, knot in enumerate(knots):
            struct[f"cover_hinge{j}"] = np.maximum(struct.Cover_z - knot, 0)
        for outcome in ("Cover", "Hmean", "HP90"):
            terms = ctr_s.copy()
            if outcome != "Cover":
                terms += ["Cover_z", "cover_hinge0", "cover_hinge1", "cover_hinge2"]
            fit = ses05.fit_fe(struct, terms, [f"{outcome}_z"], "grid_equal")
            j = fit["kept"].index("ses_z")
            value = float(fit["beta"][j, 0])
            eye = np.zeros(fit["a"].shape[1]); eye[j] = 1
            positions = [lookup[str(cid)] for cid in np.sort(struct.city_id.unique())]
            draws = np.full(N_BOOT, np.nan)
            for r, all_mult in enumerate(multiplicities):
                mult = all_mult[positions]
                aa = np.einsum("g,gij->ij", mult, fit["a"])
                bb = np.einsum("g,gpd->pd", mult, fit["b"])[:, 0]
                solution = np.linalg.lstsq(aa, np.column_stack([bb, eye]), rcond=None)[0]
                if np.allclose(aa @ solution[:, 1], eye, rtol=1e-6, atol=1e-6):
                    draws[r] = solution[j, 0]
            lo, hi, n = interval(draws)
            results.append({"scale_km": scale, "analysis": f"SES_gradient_{outcome}",
                            "estimate": value, "ci95_low": lo, "ci95_high": hi,
                            "n_grids": len(struct), "n_cities": struct.city_id.nunique(),
                            "n_valid_bootstrap": n})
        pooled, lo, hi, nc = city_meta(thermal, ctr_t)
        results.append({"scale_km": scale, "analysis": "city_UC12_random_effects_meta",
                        "estimate": pooled, "ci95_low": lo, "ci95_high": hi,
                        "n_grids": len(thermal), "n_cities": nc})
    return pd.DataFrame(results)


def main():
    for path in (SCREENING_CSV, STRUCTURE_CSV, THERMAL_CSV, GRID_SHP):
        if not path.is_file():
            raise FileNotFoundError(path)
    df, controls = cf10.prepare_data()
    for h in HEIGHTS:
        for prefix in ("UpperCover", "TallShare"):
            field = f"{prefix}{h}"
            if field not in df:
                raise ValueError(f"缺少树冠阈值字段：{field}")
    cities = np.sort(df.city_id.unique())
    multiplicities = city_bootstrap(cities)
    screen, primary = screening_sensitivity(df, multiplicities, cities)
    scenarios = counterfactual_sensitivity(df, controls, primary, multiplicities, cities)
    coarse = coarse_samples()
    structure = read_data(STRUCTURE_CSV)
    thermal = read_data(THERMAL_CSV)
    # 保持与主分析完全一致的研究城市集合。
    structure = structure.loc[structure.city_id.isin(cities)].copy()
    thermal = thermal.loc[thermal.city_id.isin(cities)].copy()
    for s in coarse:
        coarse[s] = coarse[s].loc[coarse[s].city_id.isin(cities)].copy()
    spatial = spatial_sensitivity(structure, thermal, coarse, multiplicities, cities)
    save(screen, "screening_sensitivity.csv")
    save(scenarios, "counterfactual_sensitivity.csv")
    save(spatial, "spatial_scale_sensitivity.csv")


if __name__ == "__main__":
    main()
