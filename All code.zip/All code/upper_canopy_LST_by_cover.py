
# -*- coding: utf-8 -*-


from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator
import numpy as np
import pandas as pd



INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_thermal.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\upper_canopy_models_submission"
)



OUTPUT_NAME = "upper_canopy_LST_by_cover"

N_BOOTSTRAP = 2000
RANDOM_SEED = 20261023
DPI = 600

COVER_EDGES = (
    0, 5, 10, 15, 20, 30, 40, np.inf
)

BIN_KEYS = (
    "0-5", "5-10", "10-15", "15-20",
    "20-30", "30-40", "40+"
)

BIN_LABELS = (
    "5", "10", "15", "20", "30", "40", ">40"
)

GROUPS = (
    "Lower upper-canopy",
    "Higher upper-canopy"
)

COLORS = {
    "lower": "#D95F02",
    "higher": "#0066B3"
}

FIG_WIDTH_MM = 89.0
FIG_HEIGHT_MM = 70.0



def load_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(
            f"找不到03生成的热分析样本：{INPUT_CSV}"
        )

    df = pd.read_csv(
        INPUT_CSV,
        dtype={
            "grid_id": str,
            "city_id": str
        },
        encoding="utf-8-sig"
    )

    required = (
        "grid_id",
        "city_id",
        "lst",
        "Cover",
        "UpperCover12",
        "grdi",
        "population",
        "built_density",
        "built_height",
        "distance_to_center_km"
    )

    missing = set(required) - set(df.columns)

    if missing:
        raise ValueError(
            f"sample_thermal.csv缺少字段：{sorted(missing)}"
        )

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError(
            "grid_id/city_id缺失或grid_id重复"
        )

    numeric = list(required[2:])

    if "smod" in df.columns:
        numeric.append("smod")

    df[numeric] = df[numeric].apply(
        pd.to_numeric,
        errors="coerce"
    )

    if not np.isfinite(
        df[numeric].to_numpy(float)
    ).all():
        raise ValueError(
            "样本数值字段存在缺失或非有限值"
        )

    valid = (
        df.lst.between(-50, 90)
        & df.Cover.between(0, 100)
        & df.UpperCover12.between(0, 100)
        & df.UpperCover12.le(df.Cover + 1e-6)
        & df.grdi.between(0, 100)
        & df.population.ge(0)
        & df.built_density.between(0, 1)
        & df.built_height.ge(0)
        & df.distance_to_center_km.ge(0)
    )

    if not valid.all():
        raise ValueError(
            "样本包含超出有效范围的数据"
        )

    if df.city_id.nunique() < 3:
        raise ValueError(
            "整城市Bootstrap至少需要3座城市"
        )

    df = df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)

    df["ses_affluence"] = 100 - df.grdi

    df["log_population"] = np.log1p(
        df.population
    )

    df["log_built_height"] = np.log1p(
        df.built_height
    )


    by_city = df.groupby(
        "city_id",
        sort=True
    )

    y = (
        df.lst
        - by_city.lst.transform("mean")
    ).to_numpy(float)

    control_columns = []

    for col in (
        "ses_affluence",
        "log_population",
        "built_density",
        "log_built_height",
        "distance_to_center_km"
    ):

        grouped = by_city[col]

        mean = grouped.transform("mean")

        sd = grouped.transform(
            lambda values: values.std(ddof=0)
        )

        z = (
            (df[col] - mean)
            / sd.where(sd > 0)
        ).fillna(0.0)

        control_columns.append(
            z.to_numpy(float)
        )

    if "smod" in df.columns:

        centre = df.smod.eq(30).astype(float)

        centre -= centre.groupby(
            df.city_id
        ).transform("mean")

        control_columns.append(
            centre.to_numpy(float)
        )

    X = np.column_stack(
        control_columns
    )

    beta = np.linalg.lstsq(
        X,
        y,
        rcond=None
    )[0]

    df["adjusted_lst_anomaly_C"] = (
        y - X @ beta
    )


    df["cover_bin"] = pd.cut(
        df.Cover,
        COVER_EDGES,
        labels=BIN_KEYS,
        right=False,
        include_lowest=True
    )

    if df.cover_bin.isna().any():
        raise ValueError(
            "有Cover值未能分组"
        )


    df["uppercover_residual"] = np.nan
    df["structure_group"] = ""

    for key in BIN_KEYS:

        idx = df.index[
            df.cover_bin.eq(key)
        ]

        if len(idx) == 0:
            continue

        cover = df.loc[
            idx, "Cover"
        ].to_numpy(float)

        upper = df.loc[
            idx, "UpperCover12"
        ].to_numpy(float)

        design = np.column_stack([
            np.ones(len(idx)),
            cover
        ])

        coef = np.linalg.lstsq(
            design,
            upper,
            rcond=None
        )[0]

        residual = upper - design @ coef

        df.loc[
            idx, "uppercover_residual"
        ] = residual

        df.loc[
            idx, "structure_group"
        ] = np.where(
            residual >= np.median(residual),
            GROUPS[1],
            GROUPS[0]
        )

    return df



def summarize(df):

    cities, city_code = np.unique(
        df.city_id.to_numpy(str),
        return_inverse=True
    )

    g = len(cities)
    n_groups = len(GROUPS)
    n_keys = len(BIN_KEYS) * n_groups

    sums = np.zeros(
        (g, n_keys), float
    )

    counts = np.zeros(
        (g, n_keys), float
    )

    cover_sums = np.zeros(
        (g, n_keys), float
    )

    upper_sums = np.zeros(
        (g, n_keys), float
    )

    bin_code = (
        df.cover_bin.cat.codes.to_numpy()
    )

    group_code = df.structure_group.map({
        GROUPS[0]: 0,
        GROUPS[1]: 1
    })

    valid = group_code.notna().to_numpy()

    indices = (
        bin_code[valid] * n_groups
        + group_code[valid].to_numpy(int)
    )

    city_indices = city_code[valid]

    np.add.at(
        sums,
        (city_indices, indices),
        df.adjusted_lst_anomaly_C.to_numpy()[valid]
    )

    np.add.at(
        counts,
        (city_indices, indices),
        1
    )

    np.add.at(
        cover_sums,
        (city_indices, indices),
        df.Cover.to_numpy()[valid]
    )

    np.add.at(
        upper_sums,
        (city_indices, indices),
        df.UpperCover12.to_numpy()[valid]
    )

    total_n = counts.sum(axis=0)

    point = np.divide(
        sums.sum(axis=0),
        total_n,
        out=np.full(n_keys, np.nan),
        where=total_n > 0
    )


    rng = np.random.default_rng(
        RANDOM_SEED
    )

    resampled_cities = rng.integers(
        0,
        g,
        size=(N_BOOTSTRAP, g)
    )

    sampled_n = (
        counts[resampled_cities].sum(axis=1)
    )

    sampled_sum = (
        sums[resampled_cities].sum(axis=1)
    )

    draws = np.divide(
        sampled_sum,
        sampled_n,
        out=np.full_like(
            sampled_sum,
            np.nan
        ),
        where=sampled_n > 0
    )


    rows = []

    for bi, key in enumerate(BIN_KEYS):

        for gi, group in enumerate(GROUPS):

            k = bi * n_groups + gi

            valid_draws = draws[:, k][
                np.isfinite(draws[:, k])
            ]

            if len(valid_draws) >= max(
                100,
                int(0.8 * N_BOOTSTRAP)
            ):

                low, high = np.percentile(
                    valid_draws,
                    (2.5, 97.5)
                )

            else:
                low, high = np.nan, np.nan

            subset = df.loc[
                df.cover_bin.eq(key)
                & df.structure_group.eq(group)
            ]

            rows.append({
                "cover_bin": key,
                "cover_bin_index": bi,
                "structure_group": group,
                "n_grids": int(total_n[k]),

                "n_cities": int(
                    np.count_nonzero(
                        counts[:, k]
                    )
                ),

                "mean_cover_pct": (
                    float(
                        cover_sums[:, k].sum()
                        / total_n[k]
                    )
                    if total_n[k]
                    else np.nan
                ),

                "mean_uppercover12_pct": (
                    float(
                        upper_sums[:, k].sum()
                        / total_n[k]
                    )
                    if total_n[k]
                    else np.nan
                ),

                "mean_structure_residual_pct": (
                    float(
                        subset.uppercover_residual.mean()
                    )
                    if len(subset)
                    else np.nan
                ),

                "adjusted_lst_anomaly_C": float(
                    point[k]
                ),

                "ci95_low_C": float(low),
                "ci95_high_C": float(high),

                "n_valid_bootstrap": len(valid_draws)
            })

    return pd.DataFrame(rows)



def draw_figure(source):

    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],
        "font.size": 9.0,
        "axes.labelsize": 9.0,
        "xtick.labelsize": 8.0,
        "ytick.labelsize": 8.0,
        "axes.linewidth": 0.75,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })

    fig = plt.figure(
        figsize=(
            FIG_WIDTH_MM / 25.4,
            FIG_HEIGHT_MM / 25.4
        )
    )

    ax = fig.add_axes([
        0.17,
        0.17,
        0.79,
        0.77
    ])


    ax.axhline(
        0,
        color="#9A9A9A",
        linewidth=0.75,
        linestyle=(0, (4, 3)),
        zorder=1
    )


    for group, color, shift in (
        (
            GROUPS[0],
            COLORS["lower"],
            -0.08
        ),
        (
            GROUPS[1],
            COLORS["higher"],
            0.08
        )
    ):

        part = source.loc[
            source.structure_group.eq(group)
        ].sort_values(
            "cover_bin_index"
        )

        index = part.cover_bin_index.to_numpy(int)

        x = index.astype(float) + shift

        y = (
            part.adjusted_lst_anomaly_C
            .to_numpy(float)
        )

        low = part.ci95_low_C.to_numpy(float)

        high = part.ci95_high_C.to_numpy(float)

        valid = (
            np.isfinite(y)
            & np.isfinite(low)
            & np.isfinite(high)
        )

        main = valid & (index < 6)

        tail = valid & (index == 6)

        if main.any():

            ax.plot(
                x[main],
                y[main],
                color=color,
                linewidth=1.55,
                zorder=3
            )


        for mask, alpha, hollow in (
            (main, 1.0, False),
            (tail, 0.58, True)
        ):

            if not mask.any():
                continue

            ax.vlines(
                x[mask],
                low[mask],
                high[mask],
                color=color,
                linewidth=0.95,
                alpha=alpha,
                zorder=3
            )

            ax.hlines(
                low[mask],
                x[mask] - 0.045,
                x[mask] + 0.045,
                color=color,
                linewidth=0.95,
                alpha=alpha,
                zorder=3
            )

            ax.hlines(
                high[mask],
                x[mask] - 0.045,
                x[mask] + 0.045,
                color=color,
                linewidth=0.95,
                alpha=alpha,
                zorder=3
            )

            ax.scatter(
                x[mask],
                y[mask],
                s=30,
                facecolor=(
                    "white"
                    if hollow
                    else color
                ),
                edgecolor=(
                    color
                    if hollow
                    else "white"
                ),
                linewidth=(
                    0.85
                    if hollow
                    else 0.5
                ),
                alpha=alpha,
                zorder=5
            )


    ax.set_xlim(
        -0.45,
        6.45
    )

    ax.set_xticks(
        np.arange(7),
        BIN_LABELS
    )

    ax.set_ylim(
        min(
            -0.8,
            float(source.ci95_low_C.min()) - 0.08
        ),
        max(
            0.3,
            float(source.ci95_high_C.max()) + 0.08
        )
    )

    ax.yaxis.set_major_locator(
        MultipleLocator(0.2)
    )

    ax.set_xlabel(
        "Canopy cover (%)",
        labelpad=4
    )

    ax.set_ylabel(
        "LST anomaly (°C)",
        labelpad=4
    )

    ax.tick_params(
        axis="both",
        direction="out",
        length=3,
        width=0.7,
        color="#303030",
        pad=3
    )

    for spine in ax.spines.values():

        spine.set_visible(True)
        spine.set_color("#444444")
        spine.set_linewidth(0.75)

    ax.grid(False)


    ax.legend(
        handles=[
            Line2D(
                [], [],
                color=COLORS["lower"],
                lw=1.55,
                marker="o",
                markersize=5,
                label=r"Lower UC$_{12}$"
            ),

            Line2D(
                [], [],
                color=COLORS["higher"],
                lw=1.55,
                marker="o",
                markersize=5,
                label=r"Higher UC$_{12}$"
            )
        ],

        loc="lower left",
        bbox_to_anchor=(0.025, 0.015),

        frameon=False,
        fontsize=8.0,

        handlelength=1.5,
        handletextpad=0.45,
        labelspacing=0.28,
        borderaxespad=0
    )

    return fig



def main():

    df = load_data()

    source = summarize(df)

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    source.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_source_data.csv",
        index=False,
        encoding="utf-8-sig"
    )

    fig = draw_figure(source)

    try:

        for suffix in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none",
                "bbox_inches": None
            }

            if suffix in ("png", "tiff"):
                options["dpi"] = DPI

            if suffix == "tiff":
                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{suffix}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
