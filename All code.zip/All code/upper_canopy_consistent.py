
# -*- coding: utf-8 -*-


from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

import numpy as np
import pandas as pd
from scipy.stats import t



INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_thermal.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\upper_canopy_models_submission"
)



N_BOOTSTRAP = 2000
RANDOM_SEED = 20261023
DPI = 600

THRESHOLDS = (11, 12, 13, 14, 15)

COVER_EDGES = (
    0, 5, 10, 15, 20, 30, 40, np.inf
)

BIN_KEYS = (
    "0-5", "5-10", "10-15", "15-20",
    "20-30", "30-40", "40+"
)

BIN_LABELS = (
    "0–5", "5–10", "10–15", "15–20",
    "20–30", "30–40", ">40"
)

GROUPS = (
    "Lower upper-canopy",
    "Higher upper-canopy"
)


AX_W_PT = 142.1988
AX_H_PT = 111.8428

AX_W_MM = AX_W_PT * 25.4 / 72
AX_H_MM = AX_H_PT * 25.4 / 72

AX_LEFT_MM = 19.0
AX_BOTTOM_MM = 16.0

CANVAS_A_MM = (106.0, 66.0)
CANVAS_B_MM = (93.0, 65.0)

FRAME_PT = 0.75

MARKER_PT = 5.8
MARKER_EDGE_PT = 0.75

ERROR_PT = 1.2
CAP_PT = 2.6
TREND_PT = 1.9

ORANGE_A = "#D95F02"
BLUE_A = "#0066B3"

ORANGE_B = "#C96629"
BLUE_B = "#005A94"



def read_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(INPUT_CSV)

    df = pd.read_csv(
        INPUT_CSV,
        dtype={
            "grid_id": str,
            "city_id": str
        },
        encoding="utf-8-sig"
    )

    required = {
        "grid_id",
        "city_id",
        "lst",
        "Cover",
        "UpperCover12",
        "grdi",
        "population",
        "built_density",
        "built_height",
        "distance_to_center_km",
        "Hmean",
        "climate"
    }

    missing = required - set(df.columns)

    if missing:
        raise ValueError(
            f"热环境样本缺少字段：{sorted(missing)}"
        )

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError(
            "网格或城市ID缺失、重复"
        )

    for h in THRESHOLDS:

        upper = f"UpperCover{h}"
        tall = f"TallShare{h}"

        if upper not in df and tall in df:

            df[upper] = (
                pd.to_numeric(
                    df["Cover"],
                    errors="coerce"
                )
                *
                pd.to_numeric(
                    df[tall],
                    errors="coerce"
                ) / 100
            )

    numeric = [
        "lst",
        "Cover",
        "UpperCover12",
        "grdi",
        "population",
        "built_density",
        "built_height",
        "distance_to_center_km",
        "Hmean",
        "climate"
    ]

    if "smod" in df:
        numeric.append("smod")

    numeric.extend(
        f"UpperCover{h}"
        for h in THRESHOLDS
        if (
            f"UpperCover{h}" in df
            and h != 12
        )
    )

    df[numeric] = df[numeric].apply(
        pd.to_numeric,
        errors="coerce"
    )

    if not np.isfinite(
        df[numeric].to_numpy(float)
    ).all():
        raise ValueError(
            "样本包含无效数值"
        )

    valid = (
        df.lst.between(-50, 90)
        & df.Cover.between(0, 100)
        & df.UpperCover12.between(0, 100)
        & df.UpperCover12.le(df.Cover + 1e-6)
        & df.grdi.between(0, 100)
        & df.population.ge(0)
        & df.built_density.between(0, 1)
        & df.built_height.ge(0)
        & df.distance_to_center_km.ge(0)
        & df.Hmean.gt(2)
        & df.climate.between(1, 30)
        & np.isclose(
            df.climate,
            np.round(df.climate)
        )
    )

    if not valid.all():
        raise ValueError(
            "样本存在超出有效范围的变量"
        )

    for h in THRESHOLDS:

        col = f"UpperCover{h}"

        if col in df:

            if not (
                df[col].between(0, 100).all()
                and df[col].le(
                    df.Cover + 1e-6
                ).all()
            ):
                raise ValueError(
                    f"{col}与Cover不一致"
                )

    if df.city_id.nunique() < 3:
        raise ValueError(
            "有效城市数不足3座"
        )

    return df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)


def city_standardize(df, column):

    group = df.groupby("city_id")[column]

    mean = group.transform("mean")

    sd = group.transform(
        lambda values: values.std(ddof=0)
    )

    return (
        (df[column] - mean)
        / sd.where(sd > 0)
    ).fillna(0.0)


def prepare_controls(df):

    df = df.copy()

    df["affluence"] = (
        100 - df.grdi
    )

    df["log_population"] = np.log1p(
        df.population
    )

    df["log_building"] = np.log1p(
        df.built_height
    )

    terms = []

    for source, target in (
        ("affluence", "ses_z"),
        ("log_population", "population_z"),
        ("built_density", "density_z"),
        ("log_building", "building_z"),
        ("distance_to_center_km", "distance_z")
    ):

        df[target] = city_standardize(
            df, source
        )

        terms.append(target)

    df["LST_anomaly_C"] = (
        df.lst
        - df.groupby("city_id").lst.transform("mean")
    )

    climate = df.climate.astype(int)

    counts = climate.value_counts()

    reference = min(
        counts[counts.eq(counts.max())].index
    )

    dummy = pd.get_dummies(
        climate,
        prefix="climate",
        dtype=float
    )

    dummy = dummy.drop(
        columns=f"climate_{reference}"
    )

    df = pd.concat(
        [df, dummy],
        axis=1
    )

    return df, [
        *terms,
        *dummy.columns
    ]



def cover_bin_summary(df):

    df = df.copy()

    controls = [
        "ses_z",
        "population_z",
        "density_z",
        "building_z",
        "distance_z"
    ]

    if "smod" in df:

        smod = df.smod.eq(30).astype(float)

        df["urban_centre_within"] = (
            smod
            - smod.groupby(
                df.city_id
            ).transform("mean")
        )

        controls.append(
            "urban_centre_within"
        )

    X = df[controls].to_numpy(float)

    y = df.LST_anomaly_C.to_numpy(float)

    beta = np.linalg.lstsq(
        X, y, rcond=None
    )[0]

    df["adjusted_lst_anomaly_C"] = (
        y - X @ beta
    )


    df["cover_bin"] = pd.cut(
        df.Cover,
        COVER_EDGES,
        labels=BIN_KEYS,
        right=False,
        include_lowest=True
    )

    if df.cover_bin.isna().any():
        raise ValueError(
            "Cover分组存在缺失"
        )


    residual = np.empty(
        len(df),
        dtype=float
    )

    group_code = np.zeros(
        len(df),
        dtype=int
    )

    for key in BIN_KEYS:

        idx = df.index[
            df.cover_bin.eq(key)
        ].to_numpy()

        if len(idx) == 0:
            continue

        cover = df.loc[
            idx, "Cover"
        ].to_numpy(float)

        upper = df.loc[
            idx, "UpperCover12"
        ].to_numpy(float)

        design = np.column_stack([
            np.ones(len(idx)),
            cover
        ])

        fitted = np.linalg.lstsq(
            design,
            upper,
            rcond=None
        )[0]

        r = upper - design @ fitted

        residual[idx] = r

        group_code[idx] = (
            r >= np.median(r)
        ).astype(int)

    df["uppercover_residual"] = residual

    df["structure_group"] = (
        np.asarray(GROUPS)[group_code]
    )


    codes, cities = pd.factorize(
        df.city_id,
        sort=True
    )

    bins = (
        df.cover_bin.cat.codes.to_numpy()
    )

    keys = bins * 2 + group_code

    g = len(cities)
    nkeys = 14

    sums = np.zeros(
        (g, nkeys)
    )

    counts = np.zeros(
        (g, nkeys),
        dtype=int
    )

    np.add.at(
        sums,
        (codes, keys),
        df.adjusted_lst_anomaly_C
    )

    np.add.at(
        counts,
        (codes, keys),
        1
    )

    total_sum = sums.sum(axis=0)
    total_count = counts.sum(axis=0)

    point = np.divide(
        total_sum,
        total_count,
        out=np.full(nkeys, np.nan),
        where=total_count > 0
    )

    rng = np.random.default_rng(
        RANDOM_SEED
    )

    draws = np.empty(
        (N_BOOTSTRAP, nkeys)
    )

    for i in range(N_BOOTSTRAP):

        multiplicity = rng.multinomial(
            g,
            np.full(g, 1 / g)
        )

        s = multiplicity @ sums
        n = multiplicity @ counts

        draws[i] = np.divide(
            s,
            n,
            out=np.full(nkeys, np.nan),
            where=n > 0
        )


    rows = []

    for bi, (key, label) in enumerate(
        zip(BIN_KEYS, BIN_LABELS)
    ):

        for gi, group in enumerate(GROUPS):

            k = bi * 2 + gi

            subset = df.loc[
                df.cover_bin.eq(key)
                & df.structure_group.eq(group)
            ]

            valid = draws[:, k][
                np.isfinite(draws[:, k])
            ]

            if len(valid) >= (
                N_BOOTSTRAP * 0.8
            ):

                low, high = np.percentile(
                    valid,
                    [2.5, 97.5]
                )

            else:

                low = np.nan
                high = np.nan

            rows.append({
                "cover_bin_internal": key,
                "cover_bin": label,
                "structure_group": group,
                "adjusted_lst_anomaly_C": point[k],
                "ci95_low_C": low,
                "ci95_high_C": high,
                "n_grids": int(total_count[k]),
                "n_cities": int(
                    (counts[:, k] > 0).sum()
                ),
                "mean_cover_pct": (
                    float(subset.Cover.mean())
                    if len(subset)
                    else np.nan
                ),
                "mean_uppercover12_pct": (
                    float(subset.UpperCover12.mean())
                    if len(subset)
                    else np.nan
                ),
                "n_valid_bootstrap": len(valid)
            })

    return pd.DataFrame(rows)


def independent_columns(x):

    keep = []
    basis = []

    for j in range(x.shape[1]):

        v = x[:, j].copy()

        original = np.linalg.norm(v)

        if original <= 1e-10:
            continue

        for _ in range(2):

            for q in basis:
                v -= (q @ v) * q

        norm = np.linalg.norm(v)

        if norm > 1e-10 * original:

            keep.append(j)

            basis.append(v / norm)

    return keep


def fit_city_fe(
    df,
    controls,
    target,
    adjust_height
):

    terms = [
        *controls,
        "Cover",
        *(["Hmean"] if adjust_height else []),
        target
    ]

    codes, cities = pd.factorize(
        df.city_id,
        sort=True
    )

    n = len(df)
    g = len(cities)

    counts = np.bincount(codes)

    x = df[terms].to_numpy(float)

    y = (
        df.LST_anomaly_C
        .to_numpy(float)
        .copy()
    )

    means = np.zeros(
        (g, len(terms))
    )

    np.add.at(
        means,
        codes,
        x
    )

    x = x - (
        means / counts[:, None]
    )[codes]

    y -= (
        np.bincount(
            codes,
            weights=y
        ) / counts
    )[codes]

    selected = independent_columns(x)

    kept = [
        terms[i]
        for i in selected
    ]

    if target not in kept:
        raise ValueError(
            f"{target}无法独立估计"
        )

    x = x[:, selected]

    p = x.shape[1]

    if n - g - p <= 0:
        raise ValueError(
            "模型残差自由度不足"
        )

    beta = np.linalg.lstsq(
        x, y, rcond=None
    )[0]

    residual = y - x @ beta

    _, r = np.linalg.qr(
        x,
        mode="reduced"
    )

    inv_r = np.linalg.solve(
        r,
        np.eye(p)
    )

    bread = inv_r @ inv_r.T

    scores = np.zeros(
        (g, p)
    )

    np.add.at(
        scores,
        codes,
        x * residual[:, None]
    )

    correction = (
        g / (g - 1)
        * (n - 1) / (n - g - p)
    )

    covariance = (
        correction
        * bread
        @ (scores.T @ scores)
        @ bread
    )

    pos = kept.index(target)

    se = float(np.sqrt(
        max(covariance[pos, pos], 0)
    ))

    if (
        se <= 0
        or not np.isfinite(se)
    ):
        raise ValueError(
            f"{target}标准误无效"
        )

    estimate = float(beta[pos])

    critical = t.ppf(
        0.975, g - 1
    )

    return (
        estimate,
        se,
        estimate - critical * se,
        estimate + critical * se
    )


def threshold_summary(df, controls):

    rows = []

    for h in THRESHOLDS:

        for group, extra_height in (
            ("base", False),
            ("height", True)
        ):

            estimate, se, low, high = fit_city_fe(
                df,
                controls,
                f"UpperCover{h}",
                extra_height
            )

            rows.append({
                "threshold_m": h,
                "model_group": group,
                "coef": estimate,
                "se_city_cluster": se,
                "ci95_low": low,
                "ci95_high": high,
                "n_grids": len(df),
                "n_cities": df.city_id.nunique(),
                "adjustment": (
                    "Cover + Hmean"
                    if extra_height
                    else "Cover"
                )
            })

    return pd.DataFrame(rows)


def set_style(font=8.0):

    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],
        "font.size": font,
        "axes.labelsize": 8,
        "xtick.labelsize": 7,
        "ytick.labelsize": 7,
        "axes.linewidth": FRAME_PT,
        "axes.edgecolor": "#111111",
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.facecolor": "white"
    })


def new_axes(canvas_mm):

    width, height = canvas_mm

    fig = plt.figure(
        figsize=(
            width / 25.4,
            height / 25.4
        )
    )

    ax = fig.add_axes([
        AX_LEFT_MM / width,
        AX_BOTTOM_MM / height,
        AX_W_MM / width,
        AX_H_MM / height
    ])

    for spine in ax.spines.values():

        spine.set_visible(True)
        spine.set_color("#111111")
        spine.set_linewidth(FRAME_PT)

    ax.grid(False)

    ax.tick_params(
        direction="out",
        length=2.5,
        width=0.65,
        pad=2.5
    )

    return fig, ax



def plot_cover_bins(source):

    set_style(7.2)

    fig, ax = new_axes(
        CANVAS_A_MM
    )

    centers = {
        "0-5": 2.5,
        "5-10": 7.5,
        "10-15": 12.5,
        "15-20": 17.5,
        "20-30": 25.0,
        "30-40": 35.0,
        "40+": 45.0
    }

    handles = []

    for group, color, offset in (
        (GROUPS[0], ORANGE_A, -0.6),
        (GROUPS[1], BLUE_A, 0.6)
    ):

        data = (
            source.loc[
                source.structure_group.eq(group)
            ]
            .set_index("cover_bin_internal")
            .loc[list(centers)]
        )

        x = (
            np.array(
                list(centers.values())
            ) + offset
        )

        y = data[
            "adjusted_lst_anomaly_C"
        ].to_numpy(float)

        low = data[
            "ci95_low_C"
        ].to_numpy(float)

        high = data[
            "ci95_high_C"
        ].to_numpy(float)

        valid = (
            np.isfinite(y)
            & np.isfinite(low)
            & np.isfinite(high)
        )

        main = (
            valid
            & (np.arange(len(x)) < 6)
        )

        tail = valid & ~main

        if main.any():

            ax.plot(
                x[main],
                y[main],
                color=color,
                linewidth=TREND_PT,
                zorder=3
            )

        for mask, alpha, face in (
            (main, 1.0, color),
            (tail, 0.55, "white")
        ):

            if not mask.any():
                continue

            ax.vlines(
                x[mask],
                low[mask],
                high[mask],
                color=color,
                linewidth=ERROR_PT,
                alpha=alpha,
                zorder=4
            )

            for values in (low, high):

                ax.hlines(
                    values[mask],
                    x[mask] - 0.16,
                    x[mask] + 0.16,
                    color=color,
                    linewidth=ERROR_PT,
                    alpha=alpha,
                    zorder=4
                )

            ax.scatter(
                x[mask],
                y[mask],
                s=MARKER_PT ** 2,
                facecolor=face,
                edgecolor=(
                    "white"
                    if face != "white"
                    else color
                ),
                linewidth=MARKER_EDGE_PT,
                alpha=alpha,
                zorder=5
            )

        handles.append(
            Line2D(
                [], [],
                color=color,
                linewidth=TREND_PT,
                marker="o",
                markersize=MARKER_PT,
                label=group
            )
        )

    ax.axhline(
        0,
        color="#5A5A5A",
        linewidth=0.85,
        linestyle=(0, (4, 3)),
        zorder=1
    )

    ax.set_xlim(-0.5, 48.5)

    ax.set_xticks(
        list(centers.values()),
        BIN_LABELS
    )

    plt.setp(
        ax.get_xticklabels(),
        rotation=28,
        ha="right",
        fontsize=6.5
    )

    ax.set_xlabel(
        "Canopy cover (%)",
        labelpad=4
    )

    ax.set_ylabel(
        "Adjusted LST anomaly (°C)",
        labelpad=5
    )

    values = source[
        [
            "adjusted_lst_anomaly_C",
            "ci95_low_C",
            "ci95_high_C"
        ]
    ].to_numpy(float)

    valid = values[
        np.isfinite(values)
    ]

    if len(valid):

        ax.set_ylim(
            min(
                -0.8,
                float(valid.min()) - 0.06
            ),
            max(
                0.3,
                float(valid.max()) + 0.06
            )
        )

    else:
        ax.set_ylim(-0.8, 0.3)

    ax.legend(
        handles=handles,
        loc="lower left",
        fontsize=6.8,
        handlelength=2.0,
        frameon=False
    )

    return fig



def plot_threshold(source):

    set_style(7.0)

    fig, ax = new_axes(
        CANVAS_B_MM
    )

    for group, color, label, offset in (
        (
            "base",
            ORANGE_B,
            "Control total cover",
            -0.12
        ),
        (
            "height",
            BLUE_B,
            "Further control mean height",
            0.12
        )
    ):

        data = source.loc[
            source.model_group.eq(group)
        ].sort_values("threshold_m")

        x = (
            data.threshold_m.to_numpy(float)
            + offset
        )

        y = data.coef.to_numpy(float)

        low = data.ci95_low.to_numpy(float)
        high = data.ci95_high.to_numpy(float)

        ax.vlines(
            x, low, high,
            color=color,
            linewidth=ERROR_PT,
            zorder=3
        )

        for values in (low, high):

            ax.hlines(
                values,
                x - 0.07,
                x + 0.07,
                color=color,
                linewidth=ERROR_PT,
                zorder=3
            )

        ax.scatter(
            x,
            y,
            s=MARKER_PT ** 2,
            color=color,
            edgecolor="white",
            linewidth=MARKER_EDGE_PT,
            zorder=4,
            label=label
        )

    ax.axhline(
        0,
        color="#B8B8B8",
        linewidth=0.85,
        linestyle=(0, (3, 2)),
        zorder=1
    )

    ax.set_xlim(10.55, 15.45)

    ax.set_xticks(THRESHOLDS)

    ax.set_xlabel(
        "Height threshold (m)",
        labelpad=4
    )

    ax.set_ylabel(
        "Coefficient (°C per %)",
        labelpad=4
    )

    values = source[
        ["coef", "ci95_low", "ci95_high"]
    ].to_numpy(float)

    valid = values[
        np.isfinite(values)
    ]

    ax.set_ylim(
        min(-0.30, float(valid.min()) - 0.025),
        max(0.10, float(valid.max()) + 0.025)
    )

    ax.legend(
        loc="upper right",
        fontsize=6.5,
        frameon=False,
        handletextpad=0.55
    )

    return fig



def save_figure(fig, name):

    fig.canvas.draw()

    ax = fig.axes[0]

    bounds = (
        ax.get_window_extent()
        .transformed(
            fig.dpi_scale_trans.inverted()
        )
    )

    actual = [
        bounds.width * 72,
        bounds.height * 72
    ]

    expected = [
        AX_W_PT,
        AX_H_PT
    ]

    if not np.allclose(
        actual,
        expected,
        atol=1e-7,
        rtol=0
    ):
        raise ValueError(
            "主坐标框尺寸不一致"
        )

    for ext in (
        "pdf",
        "svg",
        "png",
        "tiff"
    ):

        options = {
            "facecolor": "white",
            "edgecolor": "none",
            "bbox_inches": None
        }

        if ext in ("png", "tiff"):
            options["dpi"] = DPI

        if ext == "tiff":
            options["pil_kwargs"] = {
                "compression": "tiff_lzw"
            }

        fig.savefig(
            OUTPUT_DIR / f"{name}.{ext}",
            **options
        )

    plt.close(fig)


def main():

    df = read_data()

    df, controls = prepare_controls(df)

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    cover = cover_bin_summary(df)

    cover.to_csv(
        OUTPUT_DIR
        / "upper_canopy_LST_by_cover_source_data.csv",
        index=False,
        encoding="utf-8-sig"
    )

    save_figure(
        plot_cover_bins(cover),
        "upper_canopy_LST_by_cover"
    )

    required = [
        f"UpperCover{h}"
        for h in THRESHOLDS
    ]

    if all(
        col in df.columns
        for col in required
    ):

        threshold = threshold_summary(
            df, controls
        )

        threshold.to_csv(
            OUTPUT_DIR
            / "upper_canopy_threshold_coefficients_source_data.csv",
            index=False,
            encoding="utf-8-sig"
        )

        save_figure(
            plot_threshold(threshold),
            "upper_canopy_threshold_coefficients"
        )


if __name__ == "__main__":
    main()
