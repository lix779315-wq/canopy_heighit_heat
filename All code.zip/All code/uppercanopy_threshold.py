
# -*- coding: utf-8 -*-


from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from scipy.stats import chi2, f, norm, t



INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_thermal.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\upper_canopy_models_submission"
)

THRESHOLDS = range(6, 26)
SENSITIVITY = range(11, 16)

N_BOOT = 2000
SEED = 20261023

MIN_CITY_GRIDS = 30
MIN_CITY_DF = 10

MAX_ZERO_FRACTION = 0.50
MIN_VARYING_CITIES = 0.90
MAX_VIF = 10.0




def prepare():
    df = pd.read_csv(
        INPUT_CSV,
        dtype={"grid_id": str, "city_id": str}
    )

    threshold_cols = [
        f"{prefix}{h}"
        for h in THRESHOLDS
        for prefix in ("TallShare", "UpperCover")
    ]

    required = [
        "grid_id", "city_id", "lst", "grdi",
        "population", "built_density", "built_height",
        "distance_to_center_km", "climate",
        "Cover", "Hmean", "HP90",
        *threshold_cols
    ]

    missing = set(required) - set(df.columns)

    if missing:
        raise ValueError(f"缺少字段：{sorted(missing)}")

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError("grid_id或city_id缺失、重复")

    df[required[2:]] = df[required[2:]].apply(
        pd.to_numeric, errors="coerce"
    )

    if not np.isfinite(
        df[required[2:]].to_numpy(float)
    ).all():
        raise ValueError("分析样本含缺失或非有限值")

    valid = (
        df.lst.between(-50, 90)
        & df.grdi.between(0, 100)
        & df.population.ge(0)
        & df.built_density.between(0, 1)
        & df.built_height.ge(0)
        & df.distance_to_center_km.ge(0)
        & df.climate.isin(range(1, 31))
        & df.Cover.gt(0)
        & df.Cover.le(100)
        & df.Hmean.gt(2)
        & df.HP90.gt(2)
    )

    if not valid.all():
        raise ValueError("部分变量超出有效范围")

    for h in THRESHOLDS:
        share = df[f"TallShare{h}"]
        upper = df[f"UpperCover{h}"]

        if (
            not share.between(0, 100).all()
            or not upper.between(0, 100).all()
            or not np.allclose(
                upper,
                df.Cover * share / 100,
                atol=1e-6
            )
        ):
            raise ValueError(f"{h} m指标不一致")

    df = df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)

    df["ses"] = 100 - df.grdi
    df["log_population"] = np.log1p(df.population)
    df["log_building"] = np.log1p(df.built_height)

    standardize = {
        "ses": "ses_z",
        "log_population": "population_z",
        "built_density": "density_z",
        "log_building": "building_z",
        "distance_to_center_km": "distance_z"
    }

    for source, result in standardize.items():
        group = df.groupby("city_id")[source]
        mean = group.transform("mean")
        sd = group.transform(
            lambda x: x.std(ddof=0)
        )

        df[result] = (
            (df[source] - mean)
            / sd.where(sd > 0)
        ).fillna(0.0)

    df["LST_anomaly_C"] = (
        df.lst
        - df.groupby("city_id").lst.transform("mean")
    )

    climate = df.climate.astype(int)

    counts = climate.value_counts()
    reference = sorted(
        counts[counts == counts.max()].index
    )[0]

    dummies = pd.get_dummies(
        climate,
        prefix="climate",
        dtype=float
    )

    dummies = dummies.drop(
        columns=f"climate_{reference}"
    )

    df = pd.concat([df, dummies], axis=1)

    controls = [
        "ses_z",
        "population_z",
        "density_z",
        "building_z",
        "distance_z",
        *dummies.columns
    ]

    return df, controls



def independent_columns(x):
    keep = []
    basis = []

    for j in range(x.shape[1]):
        v = x[:, j].copy()
        size = np.linalg.norm(v)

        if size <= 1e-10:
            continue

        for _ in range(2):
            for q in basis:
                v -= q * (q @ v)

        remaining = np.linalg.norm(v)

        if remaining > 1e-10 * size:
            keep.append(j)
            basis.append(v / remaining)

    return keep



def fit_fe(df, terms, target=None):
    codes, cities = pd.factorize(
        df.city_id, sort=True
    )

    g, n = len(cities), len(df)

    if g < 3:
        raise ValueError("城市数量不足")

    counts = np.bincount(codes)

    x = df[terms].to_numpy(float)
    y = df.LST_anomaly_C.to_numpy(float)

    if len(terms):
        means = np.zeros((g, len(terms)))
        np.add.at(means, codes, x)

        x = x - (
            means / counts[:, None]
        )[codes]

    y = y - (
        np.bincount(codes, weights=y)[codes]
        / counts[codes]
    )

    selected = independent_columns(x)
    kept = [terms[j] for j in selected]

    if target is not None and target not in kept:
        return None

    x = x[:, selected]
    p = len(kept)
    df_resid = n - g - p

    if df_resid <= 0:
        raise ValueError("模型残差自由度不足")

    if p:
        beta = np.linalg.lstsq(
            x, y, rcond=None
        )[0]

        resid = y - x @ beta

        _, r = np.linalg.qr(
            x, mode="reduced"
        )

        inv_r = np.linalg.solve(
            r, np.eye(p)
        )

        bread = inv_r @ inv_r.T

        scores = np.zeros((g, p))

        np.add.at(
            scores,
            codes,
            x * resid[:, None]
        )

        correction = (
            g / (g - 1)
            * (n - 1) / df_resid
        )

        covariance = (
            correction
            * bread
            @ (scores.T @ scores)
            @ bread
        )

    else:
        beta = np.empty(0)
        resid = y
        covariance = np.empty((0, 0))

    rss = float(resid @ resid)
    tss = float(y @ y)

    if rss <= 0 or tss <= 0:
        raise ValueError("LST缺少有效变异")

    bic = (
        n * (
            np.log(2 * np.pi)
            + 1
            + np.log(rss / n)
        )
        + (g + p) * np.log(n)
    )

    result = {
        "terms": kept,
        "beta": beta,
        "covariance": covariance,
        "n": n,
        "g": g,
        "p": p,
        "df": df_resid,
        "rss": rss,
        "r2": 1 - rss / tss,
        "bic": bic
    }

    if target is not None:
        j = kept.index(target)
        se = np.sqrt(
            max(covariance[j, j], 0)
        )

        estimate = float(beta[j])
        critical = t.ppf(0.975, g - 1)

        result.update({
            "estimate": estimate,
            "se": float(se),
            "position": j,
            "p_value": (
                2 * t.sf(abs(estimate / se), g - 1)
                if se > 0 else np.nan
            ),
            "ci95_low": estimate - critical * se,
            "ci95_high": estimate + critical * se,
            "vif": float(
                (x[:, j] @ x[:, j]) * bread[j, j]
            )
        })

        a = np.zeros((g, p, p))
        b = np.zeros((g, p))

        ends = np.r_[
            0, np.cumsum(counts)
        ]

        for c in range(g):
            start, stop = ends[c:c + 2]
            xx = x[start:stop]

            a[c] = xx.T @ xx
            b[c] = xx.T @ y[start:stop]

        result.update({
            "a": a,
            "b": b,
            "counts": counts
        })

    return result



def result_row(model, reduced=None):
    if model is None:
        return {
            "status": "target_not_identifiable"
        }

    row = {
        "status": "ok",
        "estimate": model["estimate"],
        "se_city_cluster": model["se"],
        "ci95_low": model["ci95_low"],
        "ci95_high": model["ci95_high"],
        "p_value": model["p_value"],
        "VIF_within": model["vif"],
        "R2_within": model["r2"],
        "BIC": model["bic"],
        "n_grids": model["n"],
        "n_cities": model["g"]
    }

    if reduced is not None:
        q = model["p"] - reduced["p"]

        gain = max(
            0.0,
            reduced["rss"] - model["rss"]
        )

        row.update({
            "incremental_R2": (
                model["r2"] - reduced["r2"]
            ),
            "partial_R2": (
                gain / reduced["rss"]
            ),
            "BIC_improvement": (
                reduced["bic"] - model["bic"]
            ),
            "classical_F": (
                (gain / q)
                / (model["rss"] / model["df"])
                if q > 0 else np.nan
            ),
            "classical_F_p": (
                f.sf(
                    (gain / q)
                    / (model["rss"] / model["df"]),
                    q, model["df"]
                )
                if q > 0 else np.nan
            )
        })

    return row



def bootstrap_target(model, draws):
    a = np.einsum(
        "g,gij->ij",
        draws,
        model["a"]
    )

    b = np.einsum(
        "g,gi->i",
        draws,
        model["b"]
    )

    unit = np.zeros(model["p"])
    unit[model["position"]] = 1.0

    rhs = np.column_stack([b, unit])

    solution, _, rank, _ = np.linalg.lstsq(
        a, rhs, rcond=None
    )

    beta = solution[:, 0]
    bread_col = solution[:, 1]

    if not np.allclose(
        a @ bread_col,
        unit,
        rtol=1e-6,
        atol=1e-6
    ):
        return np.nan, np.nan

    n = int(draws @ model["counts"])
    g = model["g"]

    if n - g - rank <= 0:
        return np.nan, np.nan

    scores = (
        model["b"]
        - np.einsum(
            "gij,j->gi",
            model["a"],
            beta
        )
    )

    influence = scores @ bread_col

    correction = (
        g / (g - 1)
        * (n - 1) / (n - g - rank)
    )

    variance = (
        correction
        * np.sum(
            draws * influence ** 2
        )
    )

    if (
        variance <= 0
        or not np.isfinite(variance)
    ):
        return np.nan, np.nan

    return (
        float(beta[model["position"]]),
        float(np.sqrt(variance))
    )


def bootstrap_summary(models):
    models = {
        name: model
        for name, model in models.items()
        if model is not None
    }

    g = next(iter(models.values()))["g"]
    rng = np.random.default_rng(SEED)

    draws = {
        name: np.full(N_BOOT, np.nan)
        for name in models
    }

    errors = {
        name: np.full(N_BOOT, np.nan)
        for name in models
    }

    for i in range(N_BOOT):
        sampled = rng.multinomial(
            g,
            np.full(g, 1 / g)
        )

        for name, model in models.items():
            draws[name][i], errors[name][i] = (
                bootstrap_target(model, sampled)
            )

    summaries = {}

    for name in models:
        valid = draws[name][
            np.isfinite(draws[name])
        ]

        bounds = (
            np.percentile(valid, [2.5, 97.5])
            if len(valid)
            else [np.nan, np.nan]
        )

        summaries[name] = {
            "bootstrap_ci95_low": bounds[0],
            "bootstrap_ci95_high": bounds[1],
            "bootstrap_n_valid": len(valid)
        }

    families = [
        [
            f"TallShare_{h}"
            for h in THRESHOLDS
        ],
        [
            f"UpperCover_{h}_cover"
            for h in SENSITIVITY
        ],
        [
            f"UpperCover_{h}_cover_Hmean"
            for h in SENSITIVITY
        ]
    ]

    for family in families:
        if not all(
            name in models for name in family
        ):
            continue

        test = np.column_stack([
            (
                draws[name]
                - models[name]["estimate"]
            ) / errors[name]
            for name in family
        ])

        test = test[
            np.isfinite(test).all(axis=1)
        ]

        if len(test) < max(
            100, int(0.8 * N_BOOT)
        ):
            continue

        max_t = np.max(
            np.abs(test), axis=1
        )

        critical = float(
            np.quantile(max_t, 0.95)
        )

        for name in family:
            m = models[name]

            summaries[name].update({
                "simultaneous_ci95_low": (
                    m["estimate"] - critical * m["se"]
                ),
                "simultaneous_ci95_high": (
                    m["estimate"] + critical * m["se"]
                ),
                "p_max_t": (
                    1 + np.sum(
                        max_t >= abs(
                            m["estimate"] / m["se"]
                        )
                    )
                ) / (len(max_t) + 1),
                "simultaneous_n_valid": len(test)
            })

    return summaries



def city_coefficients(df, controls):
    target = "UpperCover12"
    terms = [*controls, "Cover", target]

    rows = []

    for city_id, city in df.groupby("city_id"):
        row = {
            "city_id": city_id,
            "n_grids": len(city),
            "eligible": False,
            "estimate": np.nan,
            "se_HC3": np.nan,
            "variance": np.nan
        }

        if (
            len(city) < MIN_CITY_GRIDS
            or city[target].nunique() < 3
            or city.Cover.nunique() < 3
        ):
            rows.append(row)
            continue

        x = np.column_stack([
            np.ones(len(city)),
            city[terms].to_numpy(float)
        ])

        labels = ["intercept", *terms]
        keep = independent_columns(x)

        labels = [labels[i] for i in keep]
        x = x[:, keep]

        if (
            target not in labels
            or len(city) - x.shape[1] < MIN_CITY_DF
        ):
            rows.append(row)
            continue

        y = city.LST_anomaly_C.to_numpy(float)

        beta = np.linalg.lstsq(
            x, y, rcond=None
        )[0]

        residual = y - x @ beta

        q, r = np.linalg.qr(
            x, mode="reduced"
        )

        inv = np.linalg.solve(
            r, np.eye(x.shape[1])
        )

        bread = inv @ inv.T
        leverage = (q ** 2).sum(axis=1)

        if np.any(1 - leverage <= 1e-10):
            rows.append(row)
            continue

        adjusted = residual / (1 - leverage)

        covariance = (
            bread
            @ (
                x.T
                @ (x * adjusted[:, None] ** 2)
            )
            @ bread
        )

        j = labels.index(target)
        variance = float(covariance[j, j])

        if (
            not np.isfinite(variance)
            or variance <= 0
        ):
            rows.append(row)
            continue

        estimate = float(beta[j])
        se = float(np.sqrt(variance))

        critical = t.ppf(
            0.975,
            len(city) - x.shape[1]
        )

        row.update({
            "eligible": True,
            "estimate": estimate,
            "se_HC3": se,
            "variance": variance,
            "ci95_low": estimate - critical * se,
            "ci95_high": estimate + critical * se
        })

        rows.append(row)

    return pd.DataFrame(rows)


def meta_analysis(cities):
    data = cities.loc[
        cities.eligible
    ]

    y = data.estimate.to_numpy(float)
    var = data.variance.to_numpy(float)
    k = len(y)

    if k < 3:
        raise ValueError(
            "可用于Meta分析的城市少于3个"
        )

    scale = max(
        np.var(y, ddof=1),
        np.mean(var),
        np.finfo(float).eps
    )

    def objective(u):
        v = var + u * scale
        w = 1 / v

        mu = np.sum(w * y) / w.sum()

        return 0.5 * (
            np.log(v).sum()
            + np.log(w.sum())
            + np.sum(
                w * (y - mu) ** 2
            )
        )

    bound = 10.0

    for _ in range(8):
        opt = minimize_scalar(
            objective,
            bounds=(0, bound),
            method="bounded"
        )

        if not opt.success:
            raise RuntimeError("REML优化失败")

        if opt.x < bound * 0.95:
            break

        bound *= 10

    tau2 = float(
        min(
            (0, opt.x),
            key=objective
        ) * scale
    )

    weight = 1 / (var + tau2)

    estimate = np.sum(
        weight * y
    ) / weight.sum()

    q_random = np.sum(
        weight * (y - estimate) ** 2
    )

    hk_se = np.sqrt(
        max(
            1.0,
            q_random / (k - 1)
        ) / weight.sum()
    )

    fixed = 1 / var

    mu_fixed = np.sum(
        fixed * y
    ) / fixed.sum()

    q_fixed = np.sum(
        fixed * (y - mu_fixed) ** 2
    )

    critical = t.ppf(0.975, k - 1)

    return pd.DataFrame([{
        "n_cities": k,
        "pooled_UC12_coefficient": estimate,
        "ci95_low": estimate - critical * hk_se,
        "ci95_high": estimate + critical * hk_se,
        "p_value": (
            2 * t.sf(
                abs(estimate / hk_se),
                k - 1
            )
        ),
        "tau2_REML": tau2,
        "I2_pct": (
            max(
                0.0,
                (q_fixed - (k - 1)) / q_fixed
            ) * 100
            if q_fixed > 0 else 0.0
        ),
        "Cochran_Q": q_fixed,
        "Q_p": chi2.sf(q_fixed, k - 1),
        "normal_ci95_low": (
            estimate
            - norm.ppf(0.975) / np.sqrt(weight.sum())
        ),
        "normal_ci95_high": (
            estimate
            + norm.ppf(0.975) / np.sqrt(weight.sum())
        )
    }])

def main():
    df, controls = prepare()

    models = {}
    scan = []
    sensitivity = []
    u_models = []

    base_cover = fit_fe(
        df, [*controls, "Cover"]
    )

    base_hmean = fit_fe(
        df, [*controls, "Cover", "Hmean"]
    )


    for h in THRESHOLDS:
        target = f"TallShare{h}"
        name = f"TallShare_{h}"

        model = fit_fe(
            df,
            [*controls, "Cover", target],
            target
        )

        models[name] = model

        zero = float(
            df[target].eq(0).mean()
        )

        varying = float(
            df.groupby("city_id")[target]
            .var(ddof=0)
            .gt(1e-12)
            .mean()
        )

        scan.append({
            "model": name,
            "threshold_m": h,
            "zero_grid_fraction": zero,
            "varying_city_fraction": varying,
            "passes_support_rules": (
                model is not None
                and zero <= MAX_ZERO_FRACTION
                and varying >= MIN_VARYING_CITIES
                and model["vif"] <= MAX_VIF
            ),
            **result_row(model, base_cover)
        })

    for h in SENSITIVITY:
        target = f"UpperCover{h}"

        specifications = [
            (
                "cover",
                [*controls, "Cover"],
                base_cover
            ),
            (
                "cover_Hmean",
                [*controls, "Cover", "Hmean"],
                base_hmean
            )
        ]

        for label, terms, reduced in specifications:
            name = f"UpperCover_{h}_{label}"

            model = fit_fe(
                df,
                [*terms, target],
                target
            )

            models[name] = model

            sensitivity.append({
                "model": name,
                "threshold_m": h,
                "adjustment": label,
                **result_row(model, reduced)
            })

    specs = {
        "U0": [],
        "U1": ["Cover"],
        "U2": [*controls, "Cover"],
        "U3": [
            *controls, "Cover", "Hmean"
        ],
        "U4": [
            *controls, "Cover", "Hmean", "HP90"
        ]
    }

    for name, terms in specs.items():
        reduced = fit_fe(df, terms)

        model = fit_fe(
            df,
            [*terms, "UpperCover12"],
            "UpperCover12"
        )

        models[name] = model

        u_models.append({
            "model": name,
            "primary_model": name == "U2",
            **result_row(model, reduced)
        })

    boot = bootstrap_summary(models)

    for rows in (scan, sensitivity, u_models):
        for row in rows:
            row.update(
                boot.get(row["model"], {})
            )

    cities = city_coefficients(df, controls)
    meta = meta_analysis(cities)

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    pd.DataFrame(scan).to_csv(
        OUTPUT_DIR / "threshold_scan.csv",
        index=False,
        encoding="utf-8-sig"
    )

    pd.DataFrame(sensitivity).to_csv(
        OUTPUT_DIR / "threshold_sensitivity.csv",
        index=False,
        encoding="utf-8-sig"
    )

    pd.DataFrame(u_models).to_csv(
        OUTPUT_DIR / "uppercover12_models.csv",
        index=False,
        encoding="utf-8-sig"
    )

    cities.to_csv(
        OUTPUT_DIR / "city_uppercover12.csv",
        index=False,
        encoding="utf-8-sig"
    )

    meta.to_csv(
        OUTPUT_DIR / "uppercover12_meta.csv",
        index=False,
        encoding="utf-8-sig"
    )


if __name__ == "__main__":
    main()
