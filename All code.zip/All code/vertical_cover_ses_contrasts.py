
# -*- coding: utf-8 -*-



from pathlib import Path

import matplotlib
matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from scipy.linalg import qr
from scipy.stats import chi2



INPUT_CSV = Path(
    r"E:\李鑫论文\analysis_samples\submission_preprocessing\sample_structure_ses.csv"
)

OUTPUT_DIR = Path(
    r"E:\李鑫论文\result summary\cover_adjusted_height_index"
)



OUTPUT_NAME = "vertical_minus_cover_ses_contrasts"

N_BOOTSTRAP = 2000
RANDOM_SEED = 20261023
DPI = 600

OUTCOMES = (
    "Cover",
    "Hmean",
    "HSD",
    "HP90"
)

SERIES = (
    (
        "Hmean_minus_Cover",
        "Mean height",
        "#2A7F62"
    ),
    (
        "HSD_minus_Cover",
        "Height SD",
        "#D65244"
    ),
    (
        "HP90_minus_Cover",
        "P90 height",
        "#E49B20"
    )
)

CONTRAST = np.array([
    [-1., 1., 0., 0.],
    [-1., 0., 1., 0.],
    [-1., 0., 0., 1.]
])



AX_W_MM = 80.439
AX_H_MM = 62.226

FIG_W_MM = 115.0
FIG_H_MM = 85.0

AX_LEFT_MM = 27.0
AX_BOTTOM_MM = 13.0



def prepare_data():

    if not INPUT_CSV.is_file():
        raise FileNotFoundError(INPUT_CSV)

    fields = [
        "grid_id",
        "city_id",
        "grdi",
        "population",
        "built_density",
        "built_height",
        "distance_to_center_km",
        "climate",
        *OUTCOMES
    ]

    df = pd.read_csv(
        INPUT_CSV,
        dtype={
            "grid_id": str,
            "city_id": str
        },
        encoding="utf-8-sig"
    )

    missing = set(fields) - set(df.columns)

    if missing:
        raise ValueError(
            f"输入CSV缺少字段：{sorted(missing)}"
        )

    if (
        df[["grid_id", "city_id"]].isna().any().any()
        or df.grid_id.duplicated().any()
    ):
        raise ValueError(
            "grid_id/city_id存在缺失或重复"
        )

    numeric = fields[2:]

    df[numeric] = df[numeric].apply(
        pd.to_numeric,
        errors="coerce"
    )

    if not np.isfinite(
        df[numeric].to_numpy(float)
    ).all():
        raise ValueError(
            "分析变量存在无效数值"
        )

    valid = (
        df.grdi.between(0, 100).all()
        and df.population.ge(0).all()
        and df.built_density.between(0, 1).all()
        and df.built_height.ge(0).all()
        and df.distance_to_center_km.ge(0).all()
        and df.Cover.between(0, 100).all()
        and df.Hmean.gt(2).all()
        and df.HSD.ge(0).all()
        and df.HP90.gt(2).all()
    )

    if not valid:
        raise ValueError(
            "部分变量超出有效范围"
        )

    if not np.allclose(
        df.climate,
        np.round(df.climate)
    ):
        raise ValueError(
            "气候类别必须为整数"
        )

    df = df.sort_values(
        ["city_id", "grid_id"]
    ).reset_index(drop=True)

    df["affluence"] = 100 - df.grdi

    df["log_population"] = np.log1p(
        df.population
    )

    df["log_building_height"] = np.log1p(
        df.built_height
    )

    standardize = {
        "affluence": "ses_z",
        "log_population": "population_z",
        "built_density": "density_z",
        "log_building_height": "building_z",
        "distance_to_center_km": "distance_z",

        **{
            name: f"{name}_z"
            for name in OUTCOMES
        }
    }

    for source, target in standardize.items():

        group = df.groupby("city_id")[source]

        mean = group.transform("mean")

        sd = group.transform(
            lambda values: values.std(ddof=0)
        )

        df[target] = (
            (df[source] - mean)
            / sd.where(sd > 0)
        ).fillna(0)

    climate = df.climate.astype(int)

    reference = climate.value_counts().idxmax()

    dummies = pd.get_dummies(
        climate,
        prefix="climate",
        dtype=float
    )

    dummies = dummies.drop(
        columns=f"climate_{reference}"
    )

    df = pd.concat(
        [df, dummies],
        axis=1
    )

    controls = [
        "population_z",
        "density_z",
        "building_z",
        "distance_z",
        *dummies.columns
    ]

    return df, ["ses_z", *controls]



def fit_common_model(df, predictors):

    codes, cities = pd.factorize(
        df.city_id,
        sort=True
    )

    n = len(df)
    g = len(cities)

    if g < 3:
        raise ValueError(
            "可用城市数不足3座"
        )

    counts = np.bincount(
        codes,
        minlength=g
    )

    x = df[predictors].to_numpy(float).copy()

    y = df[
        [f"{name}_z" for name in OUTCOMES]
    ].to_numpy(float).copy()

    x -= (
        pd.DataFrame(x)
        .groupby(codes)
        .transform("mean")
        .to_numpy()
    )

    y -= (
        pd.DataFrame(y)
        .groupby(codes)
        .transform("mean")
        .to_numpy()
    )

    _, r, pivot = qr(
        x,
        mode="economic",
        pivoting=True
    )

    diagonal = np.abs(np.diag(r))

    tolerance = (
        max(x.shape)
        * np.finfo(float).eps
        * diagonal.max(initial=0)
    )

    rank = int(
        np.count_nonzero(
            diagonal > tolerance
        )
    )

    if rank == 0:
        raise ValueError(
            "固定效应模型没有可识别变量"
        )

    selected = np.sort(
        pivot[:rank]
    )

    kept = [
        predictors[i]
        for i in selected
    ]

    if "ses_z" not in kept:
        raise ValueError(
            "SES系数无法独立估计"
        )

    x = x[:, selected]

    p = x.shape[1]

    if n - g - p <= 0:
        raise ValueError(
            "模型残差自由度不足"
        )

    a = np.zeros((g, p, p))
    b = np.zeros((g, p, 4))

    for i in range(g):

        mask = codes == i

        xx = x[mask]
        yy = y[mask]

        a[i] = xx.T @ xx
        b[i] = xx.T @ yy

    aa = a.sum(axis=0)

    beta = np.linalg.solve(
        aa,
        b.sum(axis=0)
    )

    bread = np.linalg.inv(aa)

    scores = (
        b
        - np.einsum(
            "gij,jk->gik",
            a,
            beta
        )
    )

    influence = np.einsum(
        "ij,gjk->gik",
        bread,
        scores
    )

    correction = (
        g / (g - 1)
        * (n - 1) / (n - g - p)
    )

    return {
        "a": a,
        "b": b,
        "beta": beta,
        "influence": influence,
        "correction": correction,
        "counts": counts,
        "ses_i": kept.index("ses_z"),
        "n": n,
        "g": g,
        "p": p
    }



def calculate_contrasts(fit):

    i = fit["ses_i"]

    theta = (
        CONTRAST
        @ fit["beta"][i, :]
    )

    influence = (
        fit["influence"][:, i, :]
        @ CONTRAST.T
    )

    covariance = (
        fit["correction"]
        * (influence.T @ influence)
    )

    se = np.sqrt(
        np.diag(covariance)
    )

    if (
        np.any(se <= 0)
        or not np.isfinite(covariance).all()
        or np.linalg.matrix_rank(covariance) < 3
    ):
        raise ValueError(
            "SES系数差异的协方差矩阵不可识别"
        )

    wald = float(
        theta
        @ np.linalg.solve(
            covariance,
            theta
        )
    )

    wald_p = float(
        chi2.sf(wald, 3)
    )

    a = fit["a"]

    b = np.einsum(
        "gpk,dk->gpd",
        fit["b"],
        CONTRAST
    )

    g = fit["g"]
    p = fit["p"]
    counts = fit["counts"]


    seed = np.random.SeedSequence(
        RANDOM_SEED
    ).spawn(2)[0]

    rng = np.random.default_rng(
        seed
    )

    estimates = []
    errors = []

    attempts = 0

    while (
        len(estimates) < N_BOOTSTRAP
        and attempts < 3 * N_BOOTSTRAP
    ):

        attempts += 1

        sampled = np.bincount(
            rng.integers(
                g,
                size=g
            ),
            minlength=g
        )

        aa = np.einsum(
            "g,gij->ij",
            sampled,
            a
        )

        if np.linalg.matrix_rank(aa) < p:
            continue

        n_boot = int(
            sampled @ counts
        )

        if n_boot <= g + p:
            continue

        bb = np.einsum(
            "g,gpd->pd",
            sampled,
            b
        )

        beta = np.linalg.solve(
            aa,
            bb
        )

        scores = (
            b
            - np.einsum(
                "gij,jd->gid",
                a,
                beta
            )
        )

        ses_influence = np.einsum(
            "p,gpd->gd",
            np.linalg.inv(aa)[i],
            scores
        )

        correction = (
            g / (g - 1)
            * (n_boot - 1)
            / (n_boot - g - p)
        )

        variance = (
            correction
            * np.einsum(
                "g,gd,gd->d",
                sampled,
                ses_influence,
                ses_influence
            )
        )

        boot_se = np.sqrt(
            np.maximum(
                variance,
                0
            )
        )

        if (
            np.isfinite(beta[i]).all()
            and np.all(boot_se > 0)
        ):

            estimates.append(
                beta[i].copy()
            )

            errors.append(
                boot_se
            )

    if len(estimates) != N_BOOTSTRAP:
        raise RuntimeError(
            "有效Bootstrap次数不足"
        )

    draws = np.asarray(
        estimates
    )

    boot_errors = np.asarray(
        errors
    )


    max_t = np.max(
        np.abs(
            (draws - theta)
            / boot_errors
        ),
        axis=1
    )

    critical = float(
        np.quantile(
            max_t,
            0.95
        )
    )


    rows = []

    for j, (name, label, color) in enumerate(
        SERIES
    ):

        rows.append({
            "contrast": name,
            "metric": OUTCOMES[j + 1],
            "label": label,

            "estimate": float(
                theta[j]
            ),

            "se_CR1": float(
                se[j]
            ),

            "simultaneous_ci95_low": float(
                theta[j] - critical * se[j]
            ),

            "simultaneous_ci95_high": float(
                theta[j] + critical * se[j]
            ),

            "p_max_t": float(
                (
                    1
                    + np.sum(
                        max_t >= abs(
                            theta[j] / se[j]
                        )
                    )
                )
                / (N_BOOTSTRAP + 1)
            ),

            "joint_wald_chi2": wald,
            "joint_wald_df": 3,
            "joint_wald_p": wald_p,

            "max_t_critical": critical,
            "n_grids": fit["n"],
            "n_cities": fit["g"],
            "n_bootstrap": N_BOOTSTRAP,

            "weighting": "grid_equal",
            "model": "common_specification",
            "color": color
        })

    return pd.DataFrame(rows)



def draw_figure(rows):

    plt.rcParams.update({
        "font.family": "sans-serif",

        "font.sans-serif": [
            "Arial",
            "Helvetica",
            "DejaVu Sans"
        ],

        "font.size": 10,
        "axes.labelsize": 10,
        "xtick.labelsize": 10,
        "ytick.labelsize": 10,

        "axes.linewidth": 0.7,

        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",

        "figure.facecolor": "white",
        "savefig.facecolor": "white"
    })

    fig = plt.figure(
        figsize=(
            FIG_W_MM / 25.4,
            FIG_H_MM / 25.4
        )
    )

    ax = fig.add_axes([
        AX_LEFT_MM / FIG_W_MM,
        AX_BOTTOM_MM / FIG_H_MM,
        AX_W_MM / FIG_W_MM,
        AX_H_MM / FIG_H_MM
    ])

    y = np.array([
        2.0,
        1.0,
        0.0
    ])

    estimates = rows.estimate.to_numpy(float)

    lows = rows.simultaneous_ci95_low.to_numpy(float)

    highs = rows.simultaneous_ci95_high.to_numpy(float)


    ax.axvline(
        0,
        color="#B7B7B7",
        linestyle=(0, (3, 3)),
        linewidth=0.7,
        zorder=1
    )


    for i, (_, _, color) in enumerate(
        SERIES
    ):

        ax.hlines(
            y[i],
            lows[i],
            highs[i],
            color=color,
            linewidth=1.15,
            zorder=3
        )

        ax.vlines(
            [lows[i], highs[i]],
            y[i] - 0.07,
            y[i] + 0.07,
            color=color,
            linewidth=1.0,
            zorder=3
        )

        ax.plot(
            estimates[i],
            y[i],
            marker="D",
            markersize=5.8,
            markerfacecolor=color,
            markeredgecolor=color,
            markeredgewidth=0.4,
            linestyle="none",
            zorder=4
        )


    lower = min(
        -0.005,
        float(lows.min()) - 0.008
    )

    upper = max(
        0.105,
        float(highs.max()) + 0.008
    )

    ax.set_xlim(
        lower,
        upper
    )

    ax.set_ylim(
        -0.5,
        2.5
    )

    ax.set_yticks(
        y,
        [
            r"$H_{\mathrm{mean}}$",
            r"$H_{\mathrm{SD}}$",
            r"$H_{\mathrm{P90}}$"
        ]
    )

    ticks = [
        0.0,
        0.05,
        0.10
    ]

    visible_ticks = [
        value
        for value in ticks
        if lower <= value <= upper
    ]

    ax.set_xticks(
        visible_ticks
    )

    ax.set_xticklabels([
        f"{value:.2f}" if value else "0"
        for value in visible_ticks
    ])

    ax.tick_params(
        axis="y",
        length=0,
        width=0,
        pad=6
    )

    ax.tick_params(
        axis="x",
        direction="out",
        length=3,
        width=0.7,
        pad=3
    )

    for spine in ax.spines.values():

        spine.set_visible(True)
        spine.set_color("#5B5B5B")
        spine.set_linewidth(0.7)

    ax.grid(False)

    return fig



def main():

    df, predictors = prepare_data()

    model = fit_common_model(
        df,
        predictors
    )

    results = calculate_contrasts(
        model
    )

    OUTPUT_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    results.to_csv(
        OUTPUT_DIR
        / f"{OUTPUT_NAME}_source_data.csv",
        index=False,
        encoding="utf-8-sig"
    )

    fig = draw_figure(
        results
    )

    try:

        for ext in (
            "png",
            "pdf",
            "svg",
            "tiff"
        ):

            options = {
                "facecolor": "white",
                "edgecolor": "none"
            }

            if ext in ("png", "tiff"):
                options["dpi"] = DPI

            if ext == "tiff":
                options["pil_kwargs"] = {
                    "compression": "tiff_lzw"
                }

            fig.savefig(
                OUTPUT_DIR
                / f"{OUTPUT_NAME}.{ext}",
                **options
            )

    finally:
        plt.close(fig)


if __name__ == "__main__":
    main()
